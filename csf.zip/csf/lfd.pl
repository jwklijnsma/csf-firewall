#!/usr/bin/perl
# #
#   @app                ConfigServer Security & Firewall (CSF)
#                       Login Failure Daemon (LFD)
#   @website            https://configserver.dev
#   @docs               https://docs.configserver.dev
#   @download           https://download.configserver.dev
#   @repo               https://github.com/Aetherinox/csf-firewall
#   @copyright          Copyright (C) 2025-2026 Aetherinox
#                       Copyright (C) 2006-2025 Jonathan Michaelson
#                       Copyright (C) 2006-2025 Way to the Web Ltd.
#   @license            GPLv3
#   @updated            08.06.2026
#   
#   This program is free software; you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation; either version 3 of the License, or (at
#   your option) any later version.
#   
#   This program is distributed in the hope that it will be useful, but
#   WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
#   General Public License for more details.
#   
#   You should have received a copy of the GNU General Public License
#   along with this program; if not, see <https://www.gnu.org/licenses>.
# #

# #
#	CSF v15.10				Removed use of @EXPORT; functions must now be explicitly imported.
#							hex2ip migrated to GetIPs.pm
#							ipv4in6 migrated to GetIPs.pm
# #

## no critic (RequireUseWarnings, ProhibitExplicitReturnUndef, ProhibitMixedBooleanOperators, RequireBriefOpen, RequireLocalizedPunctuationVars)

# #
#   Declare › Use
# #

use strict;
use lib '/usr/local/csf/lib';
use Fcntl qw(:DEFAULT :flock);
use IO::Handle;
# use URI::Escape;
use IPC::Open3;
use Net::CIDR::Lite;
use POSIX qw(:sys_wait_h sysconf strftime setsid);
use Socket;
use ConfigServer::Config;
use ConfigServer::Slurp qw(slurp);
use ConfigServer::CheckIP qw(checkip cccheckip);
use ConfigServer::URLGet;
use ConfigServer::GetIPs;
use ConfigServer::Service;
use ConfigServer::AbuseIP qw(abuseip);
use ConfigServer::GetEthDev;
use ConfigServer::Sendmail;
use ConfigServer::Logger qw(logfile);
use ConfigServer::KillSSH;
use ConfigServer::LookUpIP qw(iplookup);
use ConfigServer::Sanitize qw(html_safe html_escape);

# #
#   Declare › Constants
#	
#   PACKAGE_NAME
#       Package name used to identify LFD code in logs.
#       Use PACKAGE_NAME instead of __PACKAGE__; avoids changing
#       current package and breaking fully qualified sub names.
#           main:subroutine() => lfd:subroutine()
#   
#   FORKS_LIMIT
#       Max number of tracked child processes allowed before cleanup.
#       Restart LFD if active process count stays above this limit.
#   
#   IPTABLES_ARGS_MAX
#       Max number of args allowed in one complete iptables command.
#       'iptables' executable itself counts as one arg:
#           Eg: [
#               "iptables",     # Arg 1
#               "--wait",       # Arg 2
#               "-A",           # Arg 3
#           ]
#   
#   IPTABLES_ARGS_EACH_LEN_MAX
#       Max number of chars allowed in each single iptables arg. Each
#       arg in array is checked separately:
#           Eg: [
#               "iptables",     # 8 chars
#               "--wait",       # 6 chars
#               "-A",           # 2 chars
#           ]
#   
#   @todo       Migrate to fully qualified sub names later.
# #

use constant
{
	PACKAGE_NAME                => 'main',
	FORKS_LIMIT                 => 200,
	IPTABLES_ARGS_MAX           => 128,
	IPTABLES_ARGS_EACH_LEN_MAX  => 4_096,
};

# #
#	Restrict new files and folders to the owner only (0600)
# #

umask( 0177 );

our (
	$LISTLOCK, $IPTABLESLOCK, $PIDFILE
);

our (
    $abuseip,         		$accept,        		$apache401timeout, 		$apache403timeout,	$apache404timeout,
    $attimeout,       		$blocklisttimeout,		$ccltimeout,    		$cctimeout,       	$childcnt,
    $childpid,        		$childproc,     		$cidr,            		$cidr6,           	$cleanreg,
    $clock_ticks,     		$clusterip,     		$count,           		$csftimeout,      	$cttimeout,
    $cxsreputation,   		$dirwatchfiletimeout, 	$dirwatchtimeout, 		$dyndnstimeout, 	$eth6devin,
    $eth6devout,      		$ethdevin,      		$ethdevout,       		$exploittimeout,  	$faststart,
    $gcidr,           		$gcidr6,        		$gdyndnstimeout,  		$globaltimeout,   	$hostname,
    $hostshort,       		$integritytimeout, 		$ipscidr,      			$ipscidr6,        	$ipv4reg,
    $ipv6reg,         		$loadtimeout,   		$locktimeout,     		$loginterval,     	$masterpid,
    $modsecipdbchecktimeout, $pid,     				$pidfile,        		$pidino,          	$pstimeout,
    $ptchildpid,      		$pttimeout,     		$queuetimeout,    		$relaytimeout,    	$scripttimeout,
    $slurpreg,        		$smtptimeout,   		$sys_syslog,      		$syslogcheckcode, 	$syslogchecktimeout,
    $sysloggid,       		$syslogpid,     		$systemstatstimeout, 	$tar,           	$toomanymatches,
    $tz,              		$uidtimeout,    		$uiip,            		$urlget,          	$version,
    $messenger1,      		$messenger2,    		$messenger3
);

our (
    %accounttracking,		%adb,          			%adf,          			%ads,           	%apache401,
    %apache403,         	%apache404,       		%blockedips,       		%blocklists,       	%cfblocks,
    %config,            	%cpanelalert,     		%cpanelalertusers, 		%cpconfig,         	%cxsports,
    %db,                	%dirwatchfile,    		%forks,            		%gignoreips,       	%globlogs,
    %ifaces,            	%ignoreips,       		%ips,              		%logfiles,         	%loginproto,
    %logins,            	%logintimeout,    		%logscannerfiles,		%messengerips,     	%messengerports,
    %newaccounttracking,	%nofiles,         		%ports,            		%portscans,        	%psips,
    %pskip,             	%relayip,         		%relays,           		%rtignore,         	%scripts,
    %sfile,             	%skip,            		%skipfile,         		%skipscript,       	%skipuser,
    %suignore,          	%uidignore,       		%uidscans
);

our (
	@cccidrs, 				@cidrs, 				@faststart4, 			@faststart4nat,		@faststart6,
	@faststart6nat, 		@faststartipset, 		@gcidrs, 				@ipset, 			@lfbuf,
	@lffd,					@lfino,					@lfsize,				@logignore,			@matchfile,
	@rdns,					@suspicious
);

# #
#	lfd.pl › CSF › Disabled
#	
#	If csf is disabled by the user; the file /etc/csf/csf.disable will be created
#	as a way to keep track of CSF's status.
# #

if ( -e "/etc/csf/csf.disable" )
{
	print "csf and lfd have been disabled\n";
	exit 1;
}

# #
#	lfd.pl › CSF › Errors
#	
#	Check the csf error file for any issues before starting lfd.
# #

if ( -e "/etc/csf/csf.error" )
{
	print "\nError: You have an unresolved error when starting csf. You need to restart csf successfully before starting lfd (see /etc/csf/csf.error)\n";
	exit 1;
}

# #
#	Load configs
# #

my $config 			= ConfigServer::Config->loadconfig();
%config 			= $config->config();
my %configsetting 	= $config->configsetting();
$ipv4reg 			= $config->ipv4reg;
$ipv6reg			= $config->ipv6reg;
$slurpreg 			= ConfigServer::Slurp->slurpreg;
$cleanreg 			= ConfigServer::Slurp->cleanreg;
my $codename 		= ConfigServer::Config->getCodename();

# #
#	Helper › Clean
#	
#	URL percent-encoding (escaping):
#		CSF Firewall 		=> CSF%20Firewall
#		csf/firewall		=> csf%2Ffirewall
#		name=value&test=1	=> name%3Dvalue%26test%3D1
# #

sub uriClean
{
    my ( $str ) = @_;
    $str =~ s/([^A-Za-z0-9\-_.!~*'()])/sprintf("%%%02X", ord($1))/eg;
    return $str;
}


# #
#   Enable login failure detection daemon (lfd). If set to 0 none of the
#   following settings will have any effect as the daemon won't start.
# #

if ( !$config{LF_DAEMON} )
{
    &shutdown( __LINE__, "*Error* LF_DAEMON not enabled in /etc/csf/csf.conf" )
}
else
{    
    logfile( "all", "info", "[STARTUP] LF_DAEMON enabled; starting LFD service" );
}

# #
#   Testing flag.
#	
#	Enables a cron job to clear iptables if CSF has startup configuration 
#	issues, preventing server lockout.
#	
#   Keep enabled until firewall operation is confirmed. Then set to 0 and
#   restart CSF. Stopping CSF removes the cron job from /etc/crontab.
#	
#   Note: LFD will not start while this flag is enabled.
# #

if ( $config{TESTING} )
{
	&shutdown( __LINE__, "*Error* lfd will not run with TESTING enabled in /etc/csf/csf.conf" )
}

# #
#   Integrated HTML UI for CSF/LFD without a control panel or web server.
#   Runs as a subprocess of lfd under root; successful login grants root access.
#	
#   Use caution when enabling. Additional security restrictions apply.
#   Refer to readme.txt before enabling.
#	
#   "1"     Enable
#   "0"     Disable
# #

if ( $config{UI} )
{
	require ConfigServer::DisplayUI;
	import ConfigServer::DisplayUI;
	require ConfigServer::cseUI;
	import ConfigServer::cseUI;

	eval
	{
		local $SIG{__DIE__} = undef;
		require IO::Socket::SSL;
		import IO::Socket::SSL;
	};
}

# #
#   LF_DIRWATCH		    Enable Dir Watching. Enables lfd to check /tmp and
#                       /dev/shm dirs for suspicious files such as script
#                       exploits. If suspicious files are found; send one
#                       email alert per file when LF_FLUSH expires.
#	
#   				    "300"   Recommended
#                       "0"     Disable
# #

if ( $config{LF_DIRWATCH} )
{
	require File::Find;
	import File::Find;
}

# #
#   UI					Integrated User Interface. HTML UI to csf and lfd,
#   					without requiring web server. UI runs as a sub process
#   					of the lfd daemon
#	
#	LF_DIRWATCH_FILE	Allows you to have lfd watch a particular file or dir for
#   					changes if they change, send email alert using
#                       watchalert.txt
# #

if ( $config{UI} or $config{LF_DIRWATCH_FILE} )
{
	require Digest::MD5;
	import Digest::MD5;
}

# #
#   SYSLOG        		Log LFD messages to SYSLOG as well as /var/log/lfd.log.
#                 		Requires the Perl module Sys::Syslog.
#	
#   SYSLOG_CHECK  		Verify syslog running. Send coded message every SYSLOG_CHECK
#                 		seconds, checks if it appears in SYSLOG_LOG. If not,
#                       send alert.
#                 		"3600"  Recommended
#                       "0"     Disable
# #


if ( $config{SYSLOG} or $config{SYSLOG_CHECK} )
{
	eval( 'use Sys::Syslog;' ); ##no critic
	unless ( $@ ) { $sys_syslog = 1 }
}

# # 
#   DEBUG   			For internal use only.
# # 

if ( $config{DEBUG} )
{
	require Time::HiRes;
	import Time::HiRes;
}

# #
#   CLUSTER_SENDTO   	Comma separated list of cluster member IP addresses to
#                       send requests to. Can also be set to the full path of a
#                       file that will read in one IP per line:
#                           Eg: "/etc/csf/cluster_sendto.txt"
#	
#   CLUSTER_RECVFROM 	Comma separated list of cluster member IP addresses to
#                       receive requests from. Can also be set to the full path
#                       of a file that will read in one IP per line:
#                           Eg: "/etc/csf/cluster_sendto.txt"
# #


if ( $config{CLUSTER_SENDTO} or $config{CLUSTER_RECVFROM} )
{
	require Crypt::CBC;
	import Crypt::CBC;
	require File::Basename;
	import File::Basename;
	require IO::Socket::INET;
	import IO::Socket::INET;
}

# #
#   MESSENGER			Messenger service. This feature allows the display of a message to a blocked
#   					connecting IP address to inform the user that they are blocked in the
#   					firewall. This can help when users get themselves blocked, e.g. due to
#   					multiple login failures. The service is provided by two daemons running on
#   					ports providing either an HTML or TEXT message
#	
#						1 = enable, 0 = disable
# #

if ( $config{MESSENGER} )
{
	require ConfigServer::Messenger;
	import ConfigServer::Messenger;
}

# #
#   CF_ENABLE			CloudFlare acts as a reverse proxy, so attacking IPs appear as CloudFlare
#   					IPs in iptables. Modules like mod_cloudflare (or equivalents) can obtain
#   					the true attacker IP from HTTP headers, but iptables cannot block it directly.
#	
#   					This feature uses the CloudFlare API to add/remove attacking IPs from the
#   					CloudFlare firewall and provides CLI/UI commands for management.
#	
#   					See /etc/csf/readme.txt for usage details and restrictions BEFORE enabling.
# #

if ( $config{CF_ENABLE} )
{
	require ConfigServer::CloudFlare;
	import ConfigServer::CloudFlare;
}

# #
#	This requires the user to have the files:
#		/etc/cxs/cxs.reputation
#		/usr/local/csf/lib/ConfigServer/cxs.pm
# #

if ( -e "/etc/cxs/cxs.reputation" and -e "/usr/local/csf/lib/ConfigServer/cxs.pm" )
{
	require ConfigServer::cxs;
	import ConfigServer::cxs;
	$cxsreputation 	= 1;
	%cxsports 		= ConfigServer::cxs::Rports();
}

# #
#	Fork into a child process and terminate the parent. The child continues
#	running in the background and stores its own PID in $pid. Abort if the
#	fork operation fails.
#	
#   Parent: 	child created, exit immediately.
#   Child:		continue execution and store child process PID.
#   Error:		abort if fork() fails
# #

$SIG{CHLD} = 'IGNORE'; # Ignore child process

my $pid = fork // die "*Error* Unable to fork: $!";

if ( $pid )
{
    exit 0;    # parent exits
}

$pid = $$;     # child stores its own PID

logfile( "all", "info", "[STARTUP] Registering Process ID (PID) $pid" );

# #
#	Set fixed working directory for the daemon process.
# #

chdir( "/etc/csf" );

# #
#	Detach from terminal I/O handles.
# #

close( STDIN );
close( STDOUT );
close( STDERR );

# #
#	Redirect STDIN/STDOUT/STDERR to /dev/null.
# #

open STDIN, "<", "/dev/null";
open STDOUT, ">", "/dev/null";
open STDERR, ">", "/dev/null";

# #
#	Isolate background process by creating a new session; detach from controlling terminal (TTY)
#	@note		v15.10 add session id check
# #

my $session_id = setsid();

if ( !defined( $session_id ) || $session_id == -1 )
{
    my $err = $! || 'unknown error';
    logfile( "all", "error", "[STARTUP] Cannot start new session: [ $err ]" );
    exit 1;
}
else
{
    logfile( "all", "info", "[STARTUP] Session ID (SID): [ $session_id ], Process ID (PID): [ $$ ]" );
}

# #
#	Define › App Variables
# #

my $app_github_url = "https://github.com/Aetherinox/csf-firewall";
my $app_svg_logo_raw = <<'SVG';
<svg class="login-logo" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="120" height="auto" preserveAspectRatio="xMidYMid meet">
	<g id="transformGroup" transform="scale(1) translate(0 0) rotate(0)">
		<path d="M 153.171 309.301 C 148.062 327.815, 138.987 342.266, 119.133 363.500 C 109.551 373.749, 107.194 376.959, 102.985 385.500 C 100.275 391, 97.535 397.965, 96.897 400.979 C 95.424 407.931, 96.292 425.010, 98.416 430.876 C 100.650 437.047, 100.462 439.887, 97.750 440.926 C 95.766 441.686, 96.504 442.273, 104 445.893 C 132.088 459.458, 175.989 459.768, 204.481 446.604 C 210.886 443.645, 212.098 442.722, 211.493 441.263 C 210.463 438.780, 210.501 438.470, 212.999 429.045 C 214.880 421.949, 215.157 418.895, 214.727 410.045 C 213.852 392.089, 209.622 383.465, 192.358 364.444 C 173.286 343.430, 166.546 332.810, 160.138 313.672 C 157.960 307.167, 156.010 301.677, 155.806 301.472 C 155.601 301.268, 154.415 304.791, 153.171 309.301" stroke="none" fill="#ffffff" fill-rule="evenodd"/>
		<path d="M 120.443 42.092 C 120.072 42.692, 120.334 48.892, 121.025 55.868 C 122.734 73.123, 121.834 101.029, 119.098 115.650 C 113.658 144.719, 102.901 172.578, 86.723 199.500 C 79.301 211.850, 71.923 222.169, 58.657 238.756 C 46.630 253.794, 40.414 263.476, 35.702 274.509 C 28.692 290.924, 26 305.061, 26 325.455 C 26 359.052, 35.782 385.759, 56.918 409.867 C 67.788 422.265, 88.355 438.659, 95.136 440.331 C 99.522 441.412, 100.624 438.988, 98.594 432.724 C 93.944 418.376, 94.445 403.998, 100.066 390.496 C 104.313 380.295, 107.276 376.029, 119.039 363.175 C 133.842 347.001, 139.451 339.666, 144.411 330 C 148.769 321.509, 153.300 309.246, 154.557 302.548 C 154.923 300.597, 155.510 299.003, 155.861 299.007 C 156.213 299.011, 157.235 302.048, 158.133 305.757 C 163.479 327.837, 171.047 340.053, 198.553 371 C 206.162 379.561, 211.611 389.038, 214.079 398 C 216.152 405.531, 215.660 421.296, 213.056 430.746 C 209.570 443.393, 211.350 444.796, 222.095 437.873 C 244.494 423.441, 262.315 404.262, 272.925 383.171 C 277.465 374.146, 282.641 358.067, 284.570 347 C 286.561 335.581, 286.034 313.718, 283.487 302 C 278.365 278.442, 267.866 256.933, 252.003 237.500 C 225.216 204.685, 206.613 159.041, 204.156 120.105 C 203.619 111.600, 203.171 109.510, 201.691 108.605 C 199.052 106.992, 197.527 109.581, 196.129 118.050 C 195.486 121.940, 191.811 133.439, 187.961 143.602 C 184.112 153.765, 179.940 165.620, 178.691 169.947 L 176.420 177.814 173.725 163.521 C 168.619 136.444, 157.730 102.947, 146.074 78.467 C 140.130 65.984, 128.918 45.801, 126.231 42.750 C 124.499 40.784, 121.465 40.439, 120.443 42.092" stroke="none" fill="#cc1414" fill-rule="evenodd"/>
		<path d="M 255.366 195.488 C 254.607 197.466, 258.183 203.384, 267.458 215.500 C 285.451 239.004, 288.248 242.987, 293.242 252.222 L 298.500 261.943 317.782 261.972 C 340.632 262.005, 343.009 261.400, 346.010 254.788 C 347.749 250.956, 347.958 248.130, 347.978 228.218 C 348.002 203.832, 347.410 200.562, 342.199 196.286 C 339.510 194.080, 339.342 194.072, 297.719 194.036 C 261.634 194.005, 255.859 194.203, 255.366 195.488 M 378.164 195.689 C 371.640 198.904, 371.500 199.581, 371.500 228 C 371.500 256.524, 371.638 257.177, 378.326 260.351 C 381.406 261.812, 387.258 262, 429.651 261.996 C 475.880 261.993, 477.612 261.924, 480.810 259.974 C 486.469 256.524, 487 253.781, 487 228 C 487 202.219, 486.469 199.476, 480.810 196.026 C 477.610 194.075, 475.902 194.008, 429.500 194.027 C 387.011 194.043, 381.117 194.234, 378.164 195.689 M 307.499 284.001 C 307.159 284.552, 307.902 289.615, 309.151 295.251 C 311.112 304.102, 311.444 308.638, 311.579 328.500 L 311.735 351.500 394.784 351.756 L 477.833 352.011 481.052 349.302 C 486.590 344.643, 487 342.435, 486.998 317.282 C 486.997 291.276, 486.516 289.226, 479.500 285.282 L 475.500 283.033 391.809 283.016 C 336.993 283.006, 307.904 283.346, 307.499 284.001 M 124.437 357.250 L 121.500 360.500 124.750 357.563 C 126.537 355.948, 128 354.485, 128 354.313 C 128 353.540, 127.175 354.221, 124.437 357.250 M 191 363.313 C 191 363.485, 192.463 364.948, 194.250 366.563 L 197.500 369.500 194.563 366.250 C 191.825 363.221, 191 362.540, 191 363.313 M 306.233 374.250 C 305.676 374.938, 303.326 380, 301.011 385.500 C 293.737 402.778, 283.812 418.621, 270.668 433.940 C 268.101 436.932, 266 440.004, 266 440.767 C 266 441.929, 271.858 442.100, 302.250 441.827 C 334.949 441.532, 338.860 441.321, 342.173 439.673 C 348.608 436.471, 349 434.525, 349 405.802 L 349 380.406 345.208 376.703 L 341.416 373 324.330 373 C 311.868  373, 306.971 373.338, 306.233 374.250 M 376.697 376.798 L 372.905 380.682 373.203 407.262 L 373.500 433.842 376 436.516 C 381.224 442.103, 380.227 442, 429.200 441.994 C 457.195 441.991, 475.917 441.595, 478.209 440.959 C 480.248 440.392, 483.286 438.560, 484.959 436.887 L 488 433.846 488 408.324 C 488 387.712, 487.712 382.194, 486.500 379.642 C 483.497 373.312, 485.379 373.529, 430.495 373.207 L 380.489 372.915 376.697 376.798 M 95.286 412.500 C 95.294 415.250, 95.488 416.256, 95.718 414.736 C  95.947 413.216, 95.941  410.966, 95.704 409.736 C 95.467 408.506, 95.279 409.750, 95.286 412.500 M 215.286 412.500 C 215.294 415.250, 215.488 416.256, 215.718 414.736 C 215.947 413.216, 215.941 410.966, 215.704 409.736 C 215.467 408.506, 215.279 409.750, 215.286 412.500" stroke="none" fill="#b3b3b3" fill-rule="evenodd"/>
	</g>
</svg>
SVG
my $svg_logo 	= "data:image/svg+xml," . uriClean( $app_svg_logo_raw );

# #
#   Temporarily select STDERR, enable autoflush ($|=1) so writes are pushed
#	immediately without a buffer. Then restore previously selected filehandle.
# #

my $oldfh = select STDERR; ##no critic
$| = 1;
select $oldfh; ##no critic

# #
#	DEBUG enabled; redirect STDERR to the LFD log file.
# #

if ( $config{DEBUG} )
{
	open ( STDERR, ">>", "/var/log/lfd.log" );
}

# #
#	Read system hostname from Linux kernel. Store in $hostname.
# #

$hostname = do {
    if ( open my $in, '<', '/proc/sys/kernel/hostname' )
	{
        flock( $in, LOCK_SH );
        my $h = <$in>;
        chomp $h if defined $h;
        defined( $h ) && length( $h ) ? $h : 'unknown'
    }
	else
	{
        'unknown';
    }
};

my ( $hostshort ) = split /\./, $hostname, 2;

my $hostip = do {
    my $packed = gethostbyname( $hostname );
    defined( $packed ) ? inet_ntoa( $packed ) : '127.0.0.1';
};

logfile( "all", "info", "[STARTUP] Fetching hostname $hostname [ $hostshort ] ( $hostip )" );

# #
#	Get system clock tick rate (used for CPU/process timing) when reading
#	/proc/$pid/stat.
# #

$clock_ticks 	= sysconf( &POSIX::_SC_CLK_TCK ) || 100;

# #
#	Timezone
#		UTC		$tz = "+0000";
# #

$tz 			= strftime( "%z", localtime );

# #
#	Build and lock PID file for the daemon; record process ID.
# #

$pidfile = "/var/run/lfd.pid";
sysopen ( $PIDFILE, $pidfile, O_RDWR | O_CREAT ) or &shutdown_child( __LINE__, "*Error* unable to create lfd PID file [$pidfile] $!" );
flock ( $PIDFILE, LOCK_EX | LOCK_NB ) or &shutdown_child( __LINE__, "*Error* attempt to start lfd when it is already running" );
autoflush $PIDFILE 1;
seek ( $PIDFILE, 0, 0 );
truncate ( $PIDFILE, 0 );
print $PIDFILE "$pid\n";
$pidino 	= ( stat( $pidfile ) )[1];
$masterpid 	= $pid;

# #
#	Set process name
#	Shows in system tools (ps/top).
# #

$0 = "LFD Service";

# #
#	INT   		Interrupt signal (CTRL+C)
#	TERM 		Normal termination request (kill command default)
#	HUP			Hangup (terminal closed / daemon reload request)
#	__DIE__		Catch fatal Perl errors and route through shutdown()
#	CHLD 		Ignore child process exit signals (prevent zombies / avoids wait handling)
#	PIPE 		Ignore broken pipe errors (prevent crash when writing to dead pipe / socket)
# #

$SIG{INT} 		= \&shutdown;
$SIG{TERM} 		= \&shutdown;
$SIG{HUP} 		= \&shutdown;
$SIG{__DIE__} 	= sub { &shutdown( @_ ); };
$SIG{CHLD} 		= 'IGNORE';
$SIG{PIPE} 		= 'IGNORE';

$ipscidr 		= Net::CIDR::Lite->new;
$ipscidr6 		= Net::CIDR::Lite->new;
$cidr 			= Net::CIDR::Lite->new;
$cidr6 			= Net::CIDR::Lite->new;
$gcidr 			= Net::CIDR::Lite->new;
$gcidr6 		= Net::CIDR::Lite->new;

eval { local $SIG{__DIE__} = undef; $ipscidr6->add( "::1/128" ) };
eval { local $SIG{__DIE__} = undef; $ipscidr->add( "127.0.0.0/8" ) };

# #
#	Content Security Policy
#	
#	Inserts csp headers into csf page. Increases security to ensure that no external assets can be loaded.
# #

my $csp_rule;
if ( $config{UI_CSP_ENABLED} == 1 ) 
{
	# #
    #	User defined CSP rule
	# #

    if ( $config{UI_CSP_ADVANCED_ENABLED} == 1 && $config{UI_CSP_ADVANCED_RULE} ne '' ) 
    {
        $csp_rule = $config{UI_CSP_ADVANCED_RULE};
    } 

	# #
    #	Default CSP rule
	# #

    else 
    {
		$csp_rule = "default-src 'none'; img-src 'self' data: https://*.[HOSTNAME] https://*.[HOSTIP]; script-src 'self' 'unsafe-inline' https://*.[HOSTNAME] https://*.[HOSTIP]; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com https://*.[HOSTNAME] https://*.[HOSTIP]; form-action 'self'; font-src 'self' https://fonts.gstatic.com;";
    }

	$csp_rule =~ s/\[HOSTNAME\]/$hostname/g;	# Replace [HOSTNAME] template var with real host name
	$csp_rule =~ s/\[HOSTIP\]/$hostip/g;		# Replace [HOSTIP] template var with real host ip address
    $csp_rule =~ s/"/&quot;/g;					# Escape any quotes to prevent breaking HTML
}

$faststart = 0;

# #
#   URLGET				"1" = HTTP::Tiny
#   					"2" = LWP::UserAgent
#   					"3" = CURL/WGET (set location at the bottom of csf.conf)
# #

eval
{
	local $SIG{__DIE__} = undef;
	$urlget = ConfigServer::URLGet->new( $config{URLGET}, "csf/$version", $config{URLPROXY} );
};

unless ( defined $urlget )
{
	if ( -e $config{CURL} or -e $config{WGET} )
	{
		$config{URLGET} 	= 3;
		$urlget 			= ConfigServer::URLGet->new( $config{URLGET}, "csf/$version", $config{URLPROXY} );

		logfile( "*WARNING* URLGet set to use LWP but perl module is not installed - fallback to use CURL/WGET" );
	}
	else
	{
		$config{URLGET} 	= 1;
		$urlget 			= ConfigServer::URLGet->new( $config{URLGET}, "csf/$version", $config{URLPROXY} );

		logfile( "*WARNING* URLGet set to use LWP but perl module is not installed, CURL and WGET not installed - reverting to HTTP::Tiny" );
	}
}

# #
#	lfd.pl › cPanel › wwwacct.conf
#	
#	The "/etc/wwwacct.conf" file contains the basic setup information for
#   cPanel & WHM. After you install cPanel & WHM, you can find and edit this
#   information in WHM's Basic WebHost Manager Setup interface:
#       WHM » Home » Server Configuration » Basic WebHost Manager Setup
#	
#	@ref			https://docs.cpanel.net/installation-guide/customize-your-installation/
# #

if ( -e "/etc/wwwacct.conf" )
{
	foreach my $line ( slurp( "/etc/wwwacct.conf" ) )
	{
		$line =~ s/$cleanreg//g;
		if ( $line =~ /^(\s|\#|$)/ ) 	{ next }
		my ( $name, $value ) 			= split ( / /, $line, 2 );
		$cpconfig{$name} 				= $value;
	}
}

# #
#	lfd.pl › cPanel › Version
#	
#	Read the installed cPanel version from /usr/local/cpanel/version
#	and store the version number in $cpconfig{version}.
# #

if ( -e "/usr/local/cpanel/version" )
{
	foreach my $line ( slurp( "/usr/local/cpanel/version" ) )
	{
		$line =~ s/$cleanreg//g;
		if ( $line =~ /\d/ ) { $cpconfig{version} = $line }
	}
}

# #
#	lfd.pl › Cleanup
#	
#	Remove temporary config file from a previous run, if present.
# #

if ( -e "/var/lib/csf/csf.tempconf" )	{ unlink ( "/var/lib/csf/csf.tempconf" ) }
if ( -e "/var/lib/csf/lfd.enable" ) 	{ unlink ( "/var/lib/csf/lfd.enable" ) }
if ( -e "/var/lib/csf/lfd.start" ) 		{ unlink ( "/var/lib/csf/lfd.start" ) }
if ( -e "/var/lib/csf/lfd.restart" ) 	{ unlink ( "/var/lib/csf/lfd.restart" ) }
if ( -e "/var/lib/csf/csf.4.saved" ) 	{ unlink ( "/var/lib/csf/csf.4.saved" ) }
if ( -e "/var/lib/csf/csf.4.ipsets" ) 	{ unlink ( "/var/lib/csf/csf.4.ipsets" ) }
if ( -e "/var/lib/csf/csf.6.saved" ) 	{ unlink ( "/var/lib/csf/csf.6.saved" ) }
if ( -e "/var/lib/csf/csf.dnscache" ) 	{ unlink ( "/var/lib/csf/csf.dnscache" ) }
if ( -e "/var/lib/csf/csf.gignore" ) 	{ unlink ( "/var/lib/csf/csf.gignore" ) }

# #
#	
# #

&getethdev;

# #
#	Open version.txt
# #

open ( my $IN, "<", "/etc/csf/version.txt" ) or &shutdown( __LINE__, "Unable to open version.txt: $!" );
flock ( $IN, LOCK_SH );
$version = <$IN>;
close ($IN);
chomp $version;

# #
#	Imports
# #

require ConfigServer::RegexMain;
import ConfigServer::RegexMain;

# #
#	Logs › Start Daemon
# #

logfile( "all", "ok", "[STARTUP] Daemon started on $hostname - v$version ($codename)" );

if ( $config{DEBUG} >= 1 )
{
	logfile( "Clock Ticks: $clock_ticks" );
	logfile( "debug: **** DEBUG LEVEL $config{DEBUG} ENABLED ****" );
}

# #
#	Logs › Sendmail Not Found
# #

if ( ! -e $config{SENDMAIL} )
{
    logfile( "*WARNING* Unable to send email reports - [$config{SENDMAIL}] not found" );
}

# #
#	Exit › Firewalld Found & Running
# #

if ( ConfigServer::Service::type() eq "systemd" )
{
	my @reply = &syscommand( __LINE__, $config{SYSTEMCTL}, "is-active", "firewalld" );
	chomp @reply;
	if ( $reply[ 0 ] eq "active" or $reply[ 0 ] eq "activating" )
	{
		&shutdown( __LINE__, "*Error* firewalld found to be running. You must stop and disable firewalld when using csf" );
		exit 1;
	}
}

# #
#	Logs › General Settings
# #

logfile( "all", "info", "[STARTUP] SSH Tracking [" . ( $config{LF_SSH_EMAIL_ALERT} ? "Enabled" : "Disabled" ) . "]" );
logfile( "all", "info", "[STARTUP] Webmin Tracking [" . ( $config{LF_WEBMIN_EMAIL_ALERT} ? "Enabled" : "Disabled" ) . "]" );
logfile( "all", "info", "[STARTUP] SU Tracking [" . ( $config{LF_SU_EMAIL_ALERT} ? "Enabled" : "Disabled" ) . "]" );
logfile( "all", "info", "[STARTUP] SUDO Tracking [" . ( $config{LF_SUDO_EMAIL_ALERT} ? "Enabled" : "Disabled" ) . "]" );
logfile( "all", "info", "[STARTUP] Console Tracking [" . ( $config{LF_CONSOLE_EMAIL_ALERT} ? "Enabled" : "Disabled" ) . "]" );
logfile( "all", "info", "[STARTUP] POP3 Authentication Watch [" . ( $config{LF_POP3D} ? "Enabled" : "Disabled" ) . "]" );
logfile( "all", "info", "[STARTUP] IAMP Authentication Watch [" . ( $config{LF_IMAPD} ? "Enabled" : "Disabled" ) . "]" );

# #
#   The option RESTRICT_SYSLOG disables all these features that rely on affected
#   logs. These options are:
#       LF_SSHD
#       LF_FTPD
#       LF_IMAPD
#       LF_POP3D
#       LF_BIND
#       LF_SUHOSIN
#       LF_SSH_EMAIL_ALERT
#       LF_SU_EMAIL_ALERT
#       LF_CONSOLE_EMAIL_ALERT
#       LF_DISTATTACK LF_DISTFTP
#       LT_POP3D
#       LT_IMAPD
#       PS_INTERVAL
#       UID_INTERVAL
#       WEBMIN_LOG
#       LF_WEBMIN_EMAIL_ALERT
#       PORTKNOCKING_ALERT
#       LF_SUDO_EMAIL_ALERT
#   
#   The following use the logs but are not disabled by RESTRICT_SYSLOG:
#       ST_ENABLE
#       SYSLOG_CHECK
#       LOGSCANNER
#       CUSTOM*_LOG
#   
#   The following are still enabled by default on new installations so
#   that, on balance, csf/lfd still provides expected levels of security:
#       LF_SSHD
#       LF_FTPD
#       LF_POP3D
#       LF_IMAPD
#       LF_SSH_EMAIL_ALERT
#       LF_SU_EMAIL_ALERT
#   
#   If you set RESTRICT_SYSLOG to "0" or "2" and enable any of the options listed
#   above, it should be done with the knowledge that any of the those options
#   that are enabled could be triggered by spoofed log lines and lead to the
#   server being inaccessible in the worst case. If you do not want to take that
#   risk you should set RESTRICT_SYSLOG to "1" and those features will not work
#   but you will not be protected from the exploits that they normally help block
#   
#   The recommended setting for RESTRICT_SYSLOG is "3" to restrict who can access
#   the syslog/rsyslog unix socket.
#   
#   For further advice on how to help mitigate these issues, see
#   etc/csf/readme.txt
#   
#   0 = Allow those options listed above to be used and configured
#   1 = Disable all the options listed above and prevent them from being used
#   2 = Disable only alerts about this feature and do nothing else
#   3 = Restrict syslog/rsyslog access to RESTRICT_SYSLOG_GROUP ** RECOMMENDED **
# #

# #
#	RESTRICT_SYSLOG		(1)	Disable all the options listed above and prevent them from being used
# #

if ( $config{RESTRICT_SYSLOG} == 1 )
{
	logfile( "Restricted log file access (RESTRICT_SYSLOG)" );
	foreach (qw{LF_SSHD LF_FTPD LF_IMAPD LF_POP3D LF_BIND LF_SUHOSIN
				LF_SSH_EMAIL_ALERT LF_SU_EMAIL_ALERT LF_CONSOLE_EMAIL_ALERT
				LF_DISTATTACK LF_DISTFTP LT_POP3D LT_IMAPD PS_INTERVAL
				UID_INTERVAL WEBMIN_LOG LF_WEBMIN_EMAIL_ALERT
				PORTKNOCKING_ALERT LF_SUDO_EMAIL_ALERT}) {
		if ( $config{$_} != 0 )
		{
			$config{$_} = 0;
			logfile( "RESTRICT_SYSLOG: Option $_ *Disabled*" );
		}
	}
}

# #
#	RESTRICT_SYSLOG		(3)	Restrict syslog/rsyslog access to RESTRICT_SYSLOG_GROUP
#							** RECOMMENDED **
# #

elsif ( $config{RESTRICT_SYSLOG} == 3 )
{
	logfile( "Restricting syslog/rsyslog socket access to group [$config{RESTRICT_SYSLOG_GROUP}]..." );
	&syslog_init;
}

# #
#   SYSLOG				Log lfd messages to SYSLOG in addition to /var/log/lfd.log.
#   					You must have the perl module Sys::Syslog installed to use this feature.
#	
#	SYSLOG_CHECK		Check whether syslog is running. Many of the lfd checks require syslog to
#						be running correctly. This test will send a coded message to syslog every
#						SYSLOG_CHECK seconds. lfd will check SYSLOG_LOG log lines for the coded
#						message. If it fails to do so within SYSLOG_CHECK seconds an alert using
#						syslogalert.txt is sent
# #

if ( $config{SYSLOG} or $config{SYSLOG_CHECK} )
{
	unless ( $sys_syslog )
	{
		logfile( "*Error* Cannot log to SYSLOG - Perl module Sys::Syslog required" );
	}
}

# #
#	lfd.pl › Blocklists
# #

logfile( "normal", "info", "[STARTUP] Blocklists: Scanning" );

# #
#	lfd.pl › Blocklists › /etc/csf/csf.blocklists
#	
#	Populates the list of IPs found in the multiple blocklists for CSF.
#		/etc/csf/csf.blocklists
#		/etc/cxs/cxs.blocklists
# #

if ( -e "/etc/csf/csf.blocklists" )
{
	my $count 		= 0;
	my @entries 	= slurp( "/etc/csf/csf.blocklists" );

	foreach my $line ( @entries )
	{
		if ( $line =~ /^Include\s*(.*)$/ )
		{
			my @incfile = slurp( $1 );
			push @entries, @incfile;
		}
	}

	foreach my $line ( @entries )
	{
		$line =~ s/$cleanreg//g;
		if ( $line eq "" ) { next }
		if ( $line =~ /^\s*\#|Include/ ) { next }

		my ( $name, $interval, $max, $url ) = split( /\|/, $line );

		if ( $name =~ /^\w+$/ )
		{
			$name 							= substr( uc $name, 0, 25 );
			if ( $name =~ /^CXS_/ ) 		{ $name =~ s/^CXS_/X_CXS_/ }
			if ( $interval < 3600 ) 		{ $interval = 3600 }
			if ( $max eq "" ) 				{ $max = 0 }
			$blocklists{$name}{interval} 	= $interval;
			$blocklists{$name}{max} 		= $max;
			$blocklists{$name}{url} 		= $url;

			$count++;
		}
	}

	logfile( "(csf.blocklists): " . ( $count > 0 ? $count : "0" ) . " entries" );
}
else
{
	logfile( "(csf.blocklists): Skipping" );
}

# #
#	lfd.pl › Blocklists › /etc/cxs/cxs.blocklists
#	
#	Populates the list of IPs found in the multiple blocklists for CSF.
#		/etc/csf/csf.blocklists
#		/etc/cxs/cxs.blocklists
# #

if ( $cxsreputation and -e "/etc/cxs/cxs.blocklists" )
{
	my $count 		= 0;
	my $all 		= 0;
	my @lines 		= slurp( "/etc/cxs/cxs.blocklists" );

	if ( grep { $_ =~ /^CXS_ALL/} @lines ) { $all = 1 }

	foreach my $line ( @lines )
	{
		$line =~ s/$cleanreg//g;
		if ( $line =~ /^(\s|\#|$)/ ) { next }
		my ( $name, $interval, $max, $url )	= split( /\|/, $line );
		$url =~ s/download\.configserver\.com/$config{DOWNLOADSERVER}/g;
		if ( $all and $name ne "CXS_ALL" ) 	{ next }

		if ( $name =~ /^\w+$/ )
		{
			$name 							= substr( uc $name, 0, 25 );
			if ( $max eq "" ) 				{ $max = 0 }
			$blocklists{$name}{interval} 	= $interval;
			$blocklists{$name}{max} 		= $max;
			$blocklists{$name}{url} 		= $url;

			$count++;
		}
	}

	logfile( "(cxs.blocklists): " . ( $count > 0 ? $count : "0" ) . " entries" );
}
else
{
	logfile( "(cxs.blocklists): Skipping" );
}

# #
#	lfd.pl › Blocklists › Total
# #

my $blocklist_count = scalar( keys %blocklists );
if ( $blocklist_count > 0 )
{
    logfile( "normal", "info", "[STARTUP] Blocklists: Importing $blocklist_count entries from /etc/csf/csf.blocklists and /etc/cxs/cxs.blocklists" );
	&blocklist;
	$blocklisttimeout = 0;
}

# #
#	lfd.pl › Ignore List › /etc/csf/csf.ignore
#	
#   The following IP addresses will be ignored by all lfd checks
#   One IP address per line
#   
#   CIDR addressing allowed with a quaded IP (e.g. 192.168.254.0/24)
#   
#   Only list IP addresses, not domain names (they will be ignored)
# #

logfile( "normal", "info", "[STARTUP] csf.ignore: Scanning" );

if ( -e "/etc/csf/csf.ignore" )
{
	my $count 		= 0;
	my @ignore 		= slurp( "/etc/csf/csf.ignore" );

	# Ignore Directive
	foreach my $line ( @ignore )
	{
		if ( $line =~ /^Include\s*(.*)$/ )
		{
			my @incfile = slurp( $1 );
			push @ignore, @incfile;
		}
	}

	foreach my $line ( @ignore )
	{
		$line =~ s/$cleanreg//g;
		if ( $line eq "" ) { next }
		if ( $line =~ /^\s*\#|Include/ ) { next }
		my ( $first, undef ) = split( /\s/, $line );
		my ( $ip, $iscidr )	= split( /\//, $first );

		if ( checkip( \$first ) )
		{
			if ( $iscidr )
			{
				push @cidrs, $first
			}
			else
			{
				$ignoreips{$ip} = 1;
				$count++;

				logfile( "(csf.ignore): + $ip" );
			}
		}
		elsif ( $ip ne "127.0.0.1" )
		{
			logfile( "(csf.ignore): ! [$first] ( Invalid entry )" );
		}
	}

	foreach my $entry ( @cidrs )
	{
		if ( checkip( \$entry ) == 6 )
		{
			eval { local $SIG{__DIE__} = undef; $cidr6->add( $entry ) };
		}
		else
		{
			eval { local $SIG{__DIE__} = undef; $cidr->add( $entry ) };
		}

		if ( $@ )
		{
			logfile( "(csf.ignore): ! $entry ( Invalid entry )" )
		}
	}

	logfile( "(csf.ignore): " . ( $count > 0 ? $count : "0" ) . " entries" );
}
else
{
	logfile( "(csf.ignore): Skipping" );
}

# #
#	lfd.pl › Ignore List › /etc/csf/csf.rignore
#	
#   The following is a list of domains and partial domain that lfd process
#   tracking will ignore based on reverse and forward DNS lookups. An example of
#   its use is to prevent web crawlers from being blocked by lfd, e.g.
#   .googlebot.com and .crawl.yahoo.net
#   
#   You must use either a Fully Qualified Domain Name (FQDN) or a unique ending
#   subset of the domain name which must begin with a dot (wildcards are NOT
#   otherwise permitted)
#   
#   For example, the following are all valid entries:
#       www.configserver.dev
#       .configserver.dev
#       .googlebot.com
#       .crawl.yahoo.net
#       .search.msn.com
#   
#   The following are NOT valid entries:
#       *.configserver.dev
#       *google.com
#       google.com (unless the lookup is EXACTLY google.com with no subdomain
#   
#   When a candidate IP address is inspected a reverse DNS lookup is performed on
#   the IP address. A forward DNS lookup is then performed on the result from the
#   reverse DNS lookup. The IP address will only be ignored if:
#   
#   1 		The results of the final lookup match original IP address       AND
#   2(a) 	The results of the rDNS lookup match FQDN                  		OR
#   2(b) 	The results of the rDNS lookup match partial subset of
#			the domain
#   
#   Note:   If the DNS lookups are too slow or do not return the expected results
#           the IP address will be counted towards the blocking trigger as normal
# #

logfile( "normal", "info", "[STARTUP] csf.rignore: Scanning" );

if ( -e "/etc/csf/csf.rignore" )
{
	my $count 		= 0;
	my @entries 	= slurp( "/etc/csf/csf.rignore" );

	foreach my $line ( @entries )
	{
		if ( $line =~ /^Include\s*(.*)$/ )
		{
			my @incfile = slurp( $1 );
			push @entries, @incfile;
		}
	}

	foreach my $line ( @entries )
	{
		$line =~ s/$cleanreg//g;
		if ( $line eq "" ) { next }
		if ( $line =~ /^\s*\#|Include/ ) { next }
		if ( $line =~ /^(\.|\w)/ )
		{
			my ( $host, undef ) = split ( /\s/, $line );
			if ( $host ne "" ) { push @rdns, $host }
		}
	}

	logfile( "(csf.rignore): " . ( scalar( @rdns ) ? scalar( @rdns ) : "0" ) . " entries" );
}
else
{
	logfile( "(csf.rignore): Skipping" );
}

# #
#	lfd.pl › Allow List › /etc/csf/csf.allow
#	
#   The following IP addresses will be allowed through iptables.
#   One IP address per line.
#   
#   CIDR addressing allowed with a quaded IP (e.g. 192.168.254.0/24).
#   Only list IP addresses, not domain names (they will be ignored)
#   
#   Advanced port+ip filtering allowed with the following format
#       tcp/udp|in/out|s/d=port,port,...|s/d=ip
#   
#   See readme.txt for more information
#   
#   Note:   IP addresses listed in this file will NOT be ignored by
#           lfd, so they can still be blocked. If you do not want lfd
#           to block an IP address you must add it to csf.ignore
# #

logfile( "normal", "info", "[STARTUP] Ignore Allow [" . ( $config{IGNORE_ALLOW} ? "Enabled" : "Disabled" ) . "]" );

if ( $config{IGNORE_ALLOW} and -e "/etc/csf/csf.allow" )
{
	my @ignore = slurp( "/etc/csf/csf.allow" );
	foreach my $line ( @ignore )
	{
		if ( $line =~ /^Include\s*(.*)$/ )
		{
			my @incfile = slurp( $1 );
			push @ignore, @incfile;
		}
	}

	foreach my $line ( @ignore )
	{
        $line =~ s/$cleanreg//g;
		if ( $line eq "" ) { next }
		if ( $line =~ /^\s*\#|Include/ ) { next }
		my ( $first, undef ) = split( /\s/, $line );
		my ( $ip, $iscidr ) = split( /\//, $first );
		if ( checkip( \$first ) )
		{
			if ( $iscidr )
			{
				push @cidrs, $first
			}
			else
			{
				$ignoreips{$ip} = 1
			}
		}
	}

	foreach my $entry ( @cidrs )
	{
		if ( checkip( \$entry ) == 6 )
		{
			eval { local $SIG{__DIE__} = undef; $cidr6->add( $entry ) };
		}
		else
		{
			eval { local $SIG{__DIE__} = undef; $cidr->add( $entry ) };
		}

		if ( $@ )
		{
			logfile( "Invalid CIDR in csf.allow: $entry" )
		}
	}
}

# #
#	lfd.pl › Globs › Register
#	
#   Register a log with globlog() when any related csf.conf flag is enabled.
#	
#   Usage:				_globlog_register( "LOG_KEY", qw( FLAG_KEY_1 FLAG_KEY_2 ... ) );
#	
#   Args:				LOG_KEY   		csf.conf log setting name (not a file path), e.g. HTACCESS_LOG
#						FLAG_KEYs 		one or more csf.conf option names tied to that log
#	
#   Example:			_globlog_register( "HTACCESS_LOG", qw( LF_HTACCESS LF_APACHE_404 ) );
#       				# HTACCESS_LOG="/usr/local/apache/logs/error_log"
#       				# LF_HTACCESS="5"   	enabled, so HTACCESS_LOG is registered
#       				# LF_APACHE_404="0" 	disabled by itself
# #

sub _globlog_register
{
    my ( $log, @flags ) = @_;

    foreach my $flag ( @flags )
    {
        if ( $config{$flag} )
        {
			logfile( "[GLOBS]: Registering flag + $flag with file $log" );
            &globlog( $log );

            return;
        }
    }
}

# #
#	lfd.pl › Globs › Dictionary
# #

_globlog_register( "HTACCESS_LOG",      qw( LF_HTACCESS LF_APACHE_404 LF_APACHE_403 LF_APACHE_401 LF_QOS LF_SYMLINK ) );
_globlog_register( "DIRECTADMIN_LOG",   qw( LF_DIRECTADMIN ) );
_globlog_register( "DIRECTADMIN_LOG_R", qw( LF_DIRECTADMIN ) );
_globlog_register( "DIRECTADMIN_LOG_S", qw( LF_DIRECTADMIN ) );
_globlog_register( "DIRECTADMIN_LOG_P", qw( LF_DIRECTADMIN ) );
_globlog_register( "MODSEC_LOG",        qw( LF_MODSEC LF_CXS ) );
_globlog_register( "SUHOSIN_LOG",       qw( LF_SUHOSIN ) );
_globlog_register( "SMTPAUTH_LOG",      qw( LF_SMTPAUTH LF_EXIMSYNTAX ) );
_globlog_register( "POP3D_LOG",         qw( LF_POP3D LT_POP3D ) );
_globlog_register( "IMAPD_LOG",         qw( LF_IMAPD LT_IMAPD ) );
_globlog_register( "CPANEL_LOG",        qw( LF_CPANEL ) );
_globlog_register( "INTERWORX_LOG",     qw( LF_INTERWORX ) );
_globlog_register( "CYBERPANEL_LOG",    qw( LF_CYBERPANEL ) );
_globlog_register( "CWP_LOG",           qw( LF_CWP ) );
_globlog_register( "VESTA_LOG",         qw( LF_VESTA ) );
_globlog_register( "WEBMIN_LOG",        qw( LF_WEBMIN LF_WEBMIN_EMAIL_ALERT ) );
_globlog_register( "SSHD_LOG",          qw( LF_SSHD LF_SSH_EMAIL_ALERT LF_CONSOLE_EMAIL_ALERT ) );
_globlog_register( "FTPD_LOG",          qw( LF_FTPD ) );
_globlog_register( "BIND_LOG",          qw( LF_BIND ) );
_globlog_register( "CPANEL_ACCESSLOG",  qw( LF_CPANEL_ALERT ) );
_globlog_register( "IPTABLES_LOG",      qw( PS_INTERVAL ST_ENABLE UID_INTERVAL ) );
_globlog_register( "SU_LOG",            qw( LF_SU_EMAIL_ALERT ) );
_globlog_register( "SUDO_LOG",          qw( LF_SUDO_EMAIL_ALERT ) );
_globlog_register( "SCRIPT_LOG",        qw( LF_SCRIPT_ALERT ) );
_globlog_register( "SMTPRELAY_LOG",     qw( RT_RELAY_ALERT RT_AUTHRELAY_ALERT RT_POPRELAY_ALERT ) );

# #
#	lfd.pl › Globs › Custom
#	
#	Register globs that cannot be added to above list.
#	
#	SYSLOG_CHECK		Check whether syslog is running. Many of the lfd checks require syslog to
#						be running correctly. This test will send a coded message to syslog every
#						SYSLOG_CHECK seconds. lfd will check SYSLOG_LOG log lines for the coded
#						message. If it fails to do so within SYSLOG_CHECK seconds an alert using
#						syslogalert.txt is sent
# #

if ( $config{SYSLOG_CHECK} and $sys_syslog )
{
    &globlog( "SYSLOG_LOG" );
}

# #
#	LT_IMAPD			Login Tracking › IMAP
#						Block IMAP logins if greater than LT_IMAPD times per hour per account per IP
#   					address (0=disabled) - not recommended for IMAP logins due to the ethos
#   					within which IMAP works. If you want to use this, setting it quite high is
#   					probably a good idea
#   
#   					This is a temporary block for the rest of the hour, afterwhich the IP is
#   					unblocked
#   
#   					SECURITY NOTE: This option is affected by the RESTRICT_SYSLOG option. Read
#   					this file about RESTRICT_SYSLOG before enabling this option.
# #

if ( $config{LT_IMAPD} )
{
	$loginproto{imapd} = $config{LT_IMAPD}
}

# #
#	LT_POP3D			Login Tracking › POP3
#   					Block POP3 logins if greater than LT_POP3D times per hour per account per IP
#   					address (0=disabled)
#   
#   					This is a temporary block for the rest of the hour, afterwhich the IP is
#   					unblocked
#   
#   					SECURITY NOTE: This option is affected by the RESTRICT_SYSLOG option. Read
#   					this file about RESTRICT_SYSLOG before enabling this option.
# #

if ( $config{LT_POP3D} )
{
	$loginproto{pop3d} = $config{LT_POP3D}
}

# #
#	lfd.pl › Globs › Custom Logs
#	
#	Counts from 1 to 10 for custom logs:
#		&globlog( "CUSTOM1_LOG" );
#		&globlog( "CUSTOM2_LOG" );
#		&globlog( "CUSTOM10_LOG" );
# #

for ( my $x = 1;$x < 10;$x++ )
{
	&globlog( "CUSTOM${x}_LOG" )
}

# #
#	lfd.pl › cPanel › EasyApache (HTACCESS_LOG & MODSEC_LOG)
#	
#   If cPanel EasyApache4 is installed, read ea4/paths.conf and find dir_logs.
#	
#   For enabled Apache/HTACCESS/ModSecurity features, replace the configured
#   log file paths with EA4's "$dir_logs/error_log" in the log tracking hashes,
#   then log that the EA4 path override is being used.
# #

if ( -e "/usr/local/cpanel/version" and -e "/etc/cpanel/ea4/is_ea4" and -e "/etc/cpanel/ea4/paths.conf" )
{
	my @file = slurp( "/etc/cpanel/ea4/paths.conf" );
	foreach my $line ( @file )
	{
		$line =~ s/$cleanreg//g;
		if ( $line =~ /^(\s|\#|$)/ ) { next }
		if ( $line !~ /=/ ) { next }
		my ( $name, $value ) = split ( /=/, $line, 2 );
		$value =~ s/^\s+//g;
		$value =~ s/\s+$//g;

		if ( $name eq "dir_logs" )
		{
			if ( $config{LF_HTACCESS} or $config{LF_APACHE_404} or $config{LF_APACHE_403} or $config{LF_APACHE_401} or $config{LF_QOS} or $config{LF_SYMLINK} )
			{
				delete $globlogs{HTACCESS_LOG}{$config{HTACCESS_LOG}};
				delete $logfiles{$config{HTACCESS_LOG}};
				$globlogs{HTACCESS_LOG}{"$value/error_log"} 	= 1;
				$logfiles{"$value/error_log"} 					= 1;

				logfile( "[CPANEL] EasyApache4: Using $value/error_log instead of $config{HTACCESS_LOG} (Web Server)" );
			}

			if ( $config{LF_MODSEC} or $config{LF_CXS} )
			{
				delete $globlogs{MODSEC_LOG}{$config{MODSEC_LOG}};
				delete $logfiles{$config{MODSEC_LOG}};
				$globlogs{MODSEC_LOG}{"$value/error_log"} 	= 1;
				$logfiles{"$value/error_log"} 				= 1;

				logfile( "[CPANEL] EasyApache4: Using $value/error_log instead of $config{MODSEC_LOG} {ModSecurity}" );
			}
		}
	}
}

# #
#	lfd.pl › Log Scanner
#	
#   This feature will send out an email summary of the log lines of
#   each log listed in /etc/csf/csf.logfiles. All lines will be reported unless
#   they match a regular expression in /etc/csf/csf.logignore
#   
#   File globbing is supported for logs listed in /etc/csf/csf.logfiles. However,
#   be aware that the more files lfd has to track, the greater the performance
#   hit.
#	
#	Note: File globs are only evaluated when lfd is started.
#   
#   Note: lfd builds the report continuously from lines logged after lfd has
#   started, so any lines logged when lfd is not running will not be reported
#   (e.g. during reboot). If lfd is restarted, then the report will include any
#   lines logged during the previous lfd logging period that weren't reported.
#   
#   1 to enable, 0 to disable
# #

if ( $config{LOGSCANNER} )
{
	# #
	#	Read /etc/csf/csf.logfiles
	# #

	my @entries = slurp( "/etc/csf/csf.logfiles" );
	foreach my $line ( @entries )
	{
		if ( $line =~ /^Include\s*(.*)$/ )
		{
			my @incfile = slurp( $1 );
			push @entries, @incfile;
		}
	}

	# #
	#	Read /etc/csf/csf.logfiles.
	#	Register with %logfiles.
	#	Register with %logscannerfiles.
	# #

	foreach my $file ( @entries )
	{
        $file =~ s/$cleanreg//g;									# clean each line using $cleanreg
		if ( $file eq "" ) { next }									# skip blanks/comments.
		if ( $file =~ /^\s*\#|Include/ ) { next }					# skip Include lines.
		if ( $file =~ /\*|\?|\[/ )									# if entry has wildcards (*, ?, [), expand with glob.
		{
			foreach my $log ( glob $file )
			{
				if ( -e $log )
				{
					$logfiles{$log} 		= 1;
					$logscannerfiles{$log} 	= 1;
				}
			}
		}
		else
		{
			if ( -e $file )
			{
				$logfiles{$file} 			= 1;
				$logscannerfiles{$file} 	= 1;
			}
		}
	}

	# #
	#	Read /etc/csf/csf.logignore
	# #

	my @entries2 = slurp( "/etc/csf/csf.logignore" );
	foreach my $line ( @entries2 )
	{
		if ( $line =~ /^Include\s*(.*)$/ )
		{
			my @incfile = slurp( $1 );
			push @entries2, @incfile;
		}
	}

	foreach my $line ( @entries2 )
	{
		$line =~ s/$cleanreg//g;
		if ( $line eq "" ) { next }
		if ( $line =~ /^\s*\#|Include/ ) { next }
		if ( &testregex( $line ) )
		{
			push @logignore, $line
		}
		else
		{
			logfile( "*Error* Invalid regex [$line] in csf.logignore" )
		}
	}

	logfile( "Log Scanner..." );
}

# #
#	lfd.pl › Exim Pool
#	
#   Disable Exim queue alerts when Exim is not present.
#   If /var/spool/exim does not exist, there is no Exim mail queue to check.
#	
#	LF_QUEUE_ALERT		Checks the length of the exim queue and sends an alert email if the value of
#   					settings is exceeded. If the ConfigServer MailScanner configuration is used
#   					then both the pending and delivery queues will be checked.
#   
#   					Note: If there are problems sending out email, this alert may not be received
#   					To disable set to "0".
# #

unless ( -d "/var/spool/exim" )
{
    $config{LF_QUEUE_ALERT} = 0;
}

# #
#	lfd.pl › Watch Mode (Deprecated)
#	
#	NOTE				As of csf v11.00; WATCH_MODE in csf.conf and --w, --watch CLI commands
#						removed in favour of the new --trace [add/remove] [ip] CLI command.
#						Ref: 			csf.pl (sub dotrace)
# #

$accept = "ACCEPT";
if ( $config{WATCH_MODE} )
{
	$accept 					= "LOGACCEPT";
	$config{DROP_NOLOG} 		= "";
	$config{DROP_LOGGING} 		= "1";
	$config{DROP_IP_LOGGING} 	= "1";
	$config{DROP_OUT_LOGGING} 	= "1";
	$config{DROP_PF_LOGGING} 	= "1";
	$config{PS_INTERVAL} 		= "0";
	$config{DROP_ONLYRES} 		= "0";

	logfile( "WATCH_MODE enabled..." );
}

# #
#	lfd.pl › csf.restart
# #

if ( -e "/var/lib/csf/csf.restart" )
{
	unlink ( "/var/lib/csf/csf.restart" );
	&csfrestart;
}

# #
#	lfd.pl › CSF Restart Tracking
#	
#	Periodic CSF health check; unless `TESTING` is enabled.
#	
#	Verify LOCALINPUT iptables state, restores CSF if rules were flushed, 
#	applies InterWorx APF stub updates, and on cPanel upgrades forks a child to
#	restart related services and trigger an lfd restart with lock/skip safety.
#	
#	Check ran every 300 seconds
# #

logfile( "normal", "info", "[STARTUP] CSF maintenance tracking [" . ( $config{LF_CSF} ? "Enabled" : "Disabled" ) . "] (300 seconds)" );

if ( $config{LF_CSF} ) 
{
	if ( -e "/var/lib/csf/cpanel.new" )
	{
		unlink ( "/var/lib/csf/cpanel.new" );
	}

	&csfcheck;
	$csftimeout = 0;
}

# #
#	lfd.pl › IPv6
#	
#	Enables IPv6 support (ip6tables)
# #

logfile( "normal", "info", "[STARTUP] IPv6 [" . ( $config{IPV6} ? "Enabled" : "Disabled" ) . "]" );

# #
#	lfd.pl › CXS Reputation
#	
#	This requires the user to have the files:
#		/etc/cxs/cxs.reputation
#		/usr/local/csf/lib/ConfigServer/cxs.pm
# #

logfile( "normal", "info", "[STARTUP] CXS Reputation [" . ( $cxsreputation ? "Enabled" : "Disabled" ) . "]" );

# #
#	lfd.pl › Load Tracking
#	
#	Monitor system load and send a diagnostic alert when the configured
#	load threshold is exceeded, while preventing duplicate notifications.
# #

logfile( "normal", "info", "[STARTUP] LOAD Tracking [" . ( $config{PT_LOAD} ? "Enabled" : "Disabled" ) . "]" );

if ( $config{PT_LOAD} )
{
    &loadcheck;
    $loadtimeout = 0;
}

# #
#	lfd.pl › Cloudflare Integration
#	
#   This features provides interaction with the CloudFlare Firewall
#   
#   As CloudFlare is a reverse proxy, any attacking IP addresses (so far as 
#   iptables is concerned) come from the CloudFlare IP's. To counter this, an
#   Apache module (mod_cloudflare) is available that obtains the true attackers
#   IP from a custom HTTP header record (similar functionality is available
#   for other HTTP daemons
# #

logfile( "normal", "info", "[STARTUP] Cloudflare Integration [" . ( $config{CF_ENABLE} ? "Enabled" : "Disabled" ) . "]" );

if ( $config{CF_ENABLE} and -e "/etc/csf/csf.cloudflare" )
{
	$cfblocks{LF_MODSEC} 		= 1;
	$cfblocks{LF_CXS} 			= 1;
#	$cfblocks{LF_CPANEL} 		= 1;
#	$cfblocks{LF_DIRECTADMIN} 	= 1;
#	$cfblocks{LF_WEBMIN} 		= 1;
}

# # 
#   SECTION:Messenger service
# # 
#   Messenger service. This feature allows the display of a message to a blocked
#   connecting IP address to inform the user that they are blocked in the
#   firewall. This can help when users get themselves blocked, e.g. due to
#   multiple login failures. The service is provided by two daemons running on
#   ports providing either an HTML or TEXT message
#   
#   This feature does not work on servers that do not have the iptables module
#   ipt_REDIRECT loaded. Typically, this will be with MONOLITHIC kernels. VPS
#   server admins should check with their VPS host provider that the iptables
#   module is included
#   
#   IPv6 will need the IO::Socket::INET6 perl module
#       Test Package:
#           perl -MIO::Socket::INET6 -e 'print "IO::Socket::INET6 OK\n"'
#   
#       Install Package:
#           RHEL / CentOS / Rocky / AlmaLinux / Fedora
#               sudo dnf install perl-IO-Socket-INET6 perl-Socket6
#           Debian / Ubuntu
#               sudo apt install libio-socket-inet6-perl libsocket6-perl -y
#   
#   For further information on features and limitations refer to the csf
#   readme.txt
#   
#   Note: Run /etc/csf/csftest.pl to check whether this option will function on
#   this server
#   
#   1 to enable, 0 to disable
# # 

if ( $config{MESSENGER} )
{
    my ( undef, undef, $uid, $gid ) = getpwnam( $config{MESSENGER_USER} );

    logfile( "normal", "ok", "[Messenger] Service enabled" );

    my ( $log_ready, $log_error ) = ConfigServer::Logger::msngr_log_prepare( $uid, $gid );
    if ( !$log_ready )
    {
        logfile( "normal", "error", "[Messenger] Failed to prepare Messenger log: $log_error" );
    }
    else
    {
        my $messenger_log = ConfigServer::Logger::LOGFILE_DIR( ) . '/' . ConfigServer::Logger::LOGFILE_MESSENGER( );
        logfile( "normal", "ok", "[Messenger] Log prepared and validated [$messenger_log]" );
    }

	# #
	#   Messenger System Summary
	#	
	#	This is an outline of the different MESSENGER modes. 
	#	
	#	MESSENGER modes source defined within csf/ConfigServer/Messenger.pm
	#	
	#	Mode settings available in /etc/csf/csf.conf. Should only enable one mode at a time.
	#	
	#   MESSENGER	(v1)	[x] lfd built-in daemon mode
	#						[x] Uses internal Perl listeners (IO::Socket::INET / INET6 / SSL) in lfd.
	#	
	#   MESSENGERV2	(v2)	[x] cPanel EA4 Apache mode
	#  						[x] Use on cPanel + EA4 Apache deployments.
	#	
	#   MESSENGERV3	(v3)	[x] Generic web-server mode
	#   					[x] Use for Apache/LiteSpeed/OpenLiteSpeed or custom non-cPanel setups.
	# #

	if ( !$config{MESSENGERV2} )
	{
		&messengerstop( 2 );
	}

	if ( !$config{MESSENGERV3} )
	{
		&messengerstop( 3 );
	}

	my ( undef, undef, $uid, $gid ) = getpwnam( $config{MESSENGER_USER} );

	# #
	#	Messenger › Configured Account
	#	
	#	Disallow proceeding if the configured MESSENGER user:
	#		- Does not exist
	#		- Set to 'root'
	#		- Empty value
	#		- Has a UID of 0 or less
	#		- Has a GID of 0 or less
	# #

    my $messenger_user = $config{MESSENGER_USER} eq "" ? "none" : $config{MESSENGER_USER};
    if ( ( $config{MESSENGER_USER} eq "" ) or ( $config{MESSENGER_USER} eq "root" ) or ( $uid <= 0 ) or ( $gid <= 0 ) )
    {
        logfile( "normal", "error", "[Messenger] Disabled Service - Configured account [$messenger_user] is invalid. Must create a dedicated user!" );
        $config{MESSENGER} = 0;
    }
	else
	{

        # #
        #   Messenger (All)
        #   
        #   csf.conf MESSENGER_USER config valid
        # #

        logfile( "normal", "ok", "[Messenger] Starting Service - Configured account [$messenger_user] is valid." );

		# #
		#	Messenger (All) › Internal Setting › HTTPS Disabled
		#	
		#	Log the runtime warning if HTTPS Messenger has been disabled.
		#	This setting is populated internally when HTTPS cannot be used.
		# #

		if ( $config{MESSENGER_HTTPS_DISABLED} ne "" )
		{
			logfile( $config{MESSENGER_HTTPS_DISABLED} );
		}
	
		# #
		#	Messenger (v3) › Setup
		#	
		#	Initialize MESSENGERV3 service.
		#	Disallow cPanel accounts from running the service.
		#	Configure HTTPS and HTML redirect ports, then start service.
		# #

		if ( $config{MESSENGERV3} )
		{
			$messenger3 = ConfigServer::Messenger->init( 3 );
			if ( -e "/var/cpanel/users/$config{MESSENGER_USER}" )
			{
                logfile( "normal", "error", "[MessengerV3] Disabling Service - Cannot run service using a cPanel account:[$config{MESSENGER_USER}]." );
				$config{MESSENGER} 		= 0;
				$config{MESSENGERV3} 	= 0;

				&messengerstop( 3 );
			}
			else
			{
				if ( $config{MESSENGER_HTTPS_IN} ne "" )
				{
					foreach my $port ( split( /\,/, $config{MESSENGER_HTTPS_IN})) { $messengerports{$port} = 1 }
                    logfile( "normal", "ok", "[MessengerV3] HTTPS Service: Starting" );
				}

				if ( $config{MESSENGER_HTML_IN} ne "" )
				{
					foreach my $port ( split( /\,/, $config{MESSENGER_HTML_IN})) { $messengerports{$port} = 1 }
                    logfile( "normal", "ok", "[MessengerV3] HTML Service: Starting" );
				}

				&messengerv3;
			}
		}

		# #
		#	Messenger (v2) › Setup
		#	
		#	Initialize MESSENGERV2 service.
		#	Disallow cPanel accounts from running the service.
		#	Configure HTTPS and HTML redirect ports, then start service.
		# #

		elsif ( $config{MESSENGERV2} )
		{
			$messenger2 = ConfigServer::Messenger->init( 2 );
			if ( -e "/var/cpanel/users/$config{MESSENGER_USER}" )
			{
                logfile( "normal", "ok", "[MessengerV2] Service Disabled - Cannot run service using a cPanel account: [$config{MESSENGER_USER}]" );

				$config{MESSENGER} 		= 0;
				$config{MESSENGERV2} 	= 0;

				&messengerstop( 2 );
			}
			else
			{
				if ( $config{MESSENGER_HTTPS_IN} ne "" )
				{
					foreach my $port ( split( /\,/, $config{MESSENGER_HTTPS_IN} ) )
					{
						$messengerports{$port} = 1
					}
					logfile( "normal", "ok", "[MessengerV2] HTTPS Service: Starting" );
				}

				if ( $config{MESSENGER_HTML_IN} ne "" )
				{
					foreach my $port ( split( /\,/, $config{MESSENGER_HTML_IN} ) )
					{
						$messengerports{$port} = 1
					}
					logfile( "normal", "ok", "[MessengerV2] HTML Service: Starting" );
				}

				&messengerv2;
			}
		}

		# #
		#	Messenger (v1) › Setup
		#	
		#	Initialize MESSENGERV1 service.
		#	Configure HTTPS and HTML redirect ports, then start services.
		# #

		else
		{
			$messenger1 = ConfigServer::Messenger->init(1);
			if ( $config{MESSENGER_HTTPS_IN} ne "" )
			{
				foreach my $port ( split( /\,/, $config{MESSENGER_HTTPS_IN} ) )
				{
					$messengerports{$port} = 1
				}
				logfile( "normal", "ok", "[MessengerV1] HTTPS Service: Starting" );
				&messenger( $config{MESSENGER_HTTPS}, $config{MESSENGER_USER}, "HTTPS" );
			}

			if ( $config{MESSENGER_HTML_IN} ne "" )
			{
				foreach my $port ( split( /\,/, $config{MESSENGER_HTML_IN} ) )
				{
					$messengerports{$port} = 1
				}
                logfile( "normal", "ok", "[MessengerV1] HTML Service: Starting" );
				&messenger( $config{MESSENGER_HTML}, $config{MESSENGER_USER}, "HTML" );
			}
		}

		if ( $config{MESSENGER_TEXT_IN} ne "" )
		{
			if ( !defined $messenger1 )
			{
				$messenger1 = ConfigServer::Messenger->init( 1 );
			}

			foreach my $port ( split( /\,/, $config{MESSENGER_TEXT_IN} ) )
			{
				$messengerports{$port} = 1
			}

            logfile( "normal", "ok", "[Messenger] TEXT Service: Starting" );
			&messenger( $config{MESSENGER_TEXT}, $config{MESSENGER_USER}, "TEXT" );
		}
	}
}
else
{

	# #
	#	Messenger › Disabled
	#	
	#	$config{MESSENGER} = "0" | ""
	#	
	#	Stop and remove any previously configured webserver for Messenger services.
	#	- 	MESSENGERv1 returns with nothing to do; built-in lfd/Perl listener.
	#	-	MESSENGERV2 removes Apache Messenger configuration and restarts Apache.
	#	-	MESSENGERV3 removes Messenger configuration from the configured location
	#		and restarts the web server.
	# #

	&messengerstop( 2 );
	&messengerstop( 3 );
}

# #
#	lfd.pl › Web Interface
#	
#   Integrated User Interface. This feature provides a HTML UI to csf and lfd,
#   without requiring a control panel or web server. The UI runs as a sub process
#   to the lfd daemon
#   
#   As it runs under the root account and successful login provides root access
#   to the server, great care should be taken when configuring and using this
#   feature. There are additional restrictions to enhance secure access to the UI
#   
#   See readme.txt for more information about using this feature BEFORE enabling
#   it for security and access reasons
#   
#   1 to enable, 0 to disable
# #

if ( $config{UI} )
{
	if ( $config{UI_CXS} )
	{
		use lib '/etc/cxs';
		require ConfigServer::cxsUI;
	}

	# #
	#	Disable lfd web ui if configured username is too generic.
	# #

	if ( $config{UI_USER} eq "" or $config{UI_USER} =~ /^(?:admin(?:istrator)?|user(?:name)?|csf|configserver|guest|root)$/i )
	{
        logfile( "normal", "error", "[WebUI] Disabling! Cannot enable LFD web UI - UI_USER must be set to a unique, non-generic username. Current value: '$config{UI_USER}'." );
		$config{UI} = 0;
	}

	# #
	#	Disable lfd web ui if configured password is too generic.
	# #

	if ( $config{UI_PASS} eq "" or $config{UI_PASS} =~ /^(?:p[a@4][s\$][s\$]w[o0]rd|p[a@4][s\$][s\$]wd|admin(?:istrator)?|user|csf|configserver)$/i )
	{
        logfile( "normal", "error", "[WebUI] Disabling! Cannot enable LFD web UI - UI_PASS must be set to a unique, non-generic password." );
		$config{UI} = 0;
	}

	# #
	#	Warn if configured password is less than 5 characters.
	# #

	if ( length( $config{UI_PASS} ) < 5 )
	{
        logfile( "normal", "warn", "[WebUI] Warning! UI_PASS is less than 5 characters long and should be changed to a longer password." );
	}

	# #
	#	Enable lfd web ui if configuration is valid.
	# #

	if ( $config{UI} )
	{
        logfile( "normal", "ok", "[WebUI] Success! Web Interface enabled on port [$config{UI_PORT}]" );
		&ui;
	}
}

# #
#	lfd.pl › Cluster › Receive From
#	
#   Set this to a comma separated list of cluster member IP addresses to receive
#   requests from. Alternatively, it can be set to the full path of a file that
#   will read in one IP per line
#		e.g: "/etc/csf/cluster_recvfrom.txt"
# #

if ( $config{CLUSTER_RECVFROM} )
{
    logfile( "normal", "ok", "[Cluster] Service Starting" );
	if (length $config{CLUSTER_KEY} < 8) {
		logfile("Failed: Cluster Service - CLUSTER_KEY too short");
		$config{CLUSTER_RECVFROM} = 0;
	} else {
		if (length $config{CLUSTER_KEY} < 20) {logfile("Cluster Service - CLUSTER_KEY should really be longer than 20 characters")}
		&lfdserver;
	}
}

# #
#	lfd.pl › Dynamic DNS
#	
#   If you wish to allow access from dynamic DNS records (for example if your IP
#   address changes whenever you connect to the internet but you have a dedicated
#   dynamic DNS record from the likes of dyndns.org) then you can list the FQDN
#   records in csf.dyndns and then set the following to the number of seconds to
#   poll for a change in the IP address. If the IP address has changed iptables
#   will be updated.
#   
#   If the FQDN has multiple A records then all of the IP addresses will be
#   processed. If IPV6 is enabled, then all IPv6 AAAA IP address records will
#   also be allowed.
#   
#   A setting of 600 would check for IP updates every 10 minutes. Set the value
#   to 0 to disable the feature
# #

logfile( "normal", "info", "[STARTUP] DynDNS Tracking [" . ( $config{DYNDNS} ? "Enabled" : "Disabled" ) . "]" );

if ( $config{DYNDNS} )
{
	&dyndns;
	$dyndnstimeout = 0;

	if ( $config{DYNDNS} < 60 )
	{
		logfile( "DYNDNS refresh increased to 300 to prevent looping (csf.conf setting: $config{DYNDNS})" );
		$config{DYNDNS} = 300;
	}
}

# #
#	lfd.pl › Global Lists
#	
#   The setting LF_GLOBAL allows you to specify automatic list refresh 
#   interval (in seconds) for all settings starting with GLOBAL_*.
#   
#   When enabled; you can download a centralized copy of an IP ALLOW, DENY, or 
#   IGNORE list from a URL instead of managing these files locally.
#   
#   This is useful if you wish to use the same lists across multiple machines
#   running CSF with the LFD service enabled.
#   
#   LFD will download these lists at the specified interval when the timer
#   expires. 
#   
#   A decent value for LF_GLOBAL is 3600 seconds (1 hour).
#   
#   A minimum value of 300 is enforced for LF_GLOBAL if enabled.
# #

logfile( "normal", "info", "[STARTUP] Global Tracking [" . ( $config{LF_GLOBAL} ? "Enabled" : "Disabled" ) . "]" );

if ( $config{LF_GLOBAL} )
{
	logfile( "normal", "info", "[STARTUP] Global Tracking (Ignore List) [" . ( $config{GLOBAL_IGNORE} ? $config{GLOBAL_IGNORE} : "Unset" ) . "]" );
	logfile( "normal", "info", "[STARTUP] Global Tracking (Allow List) ["  . ( $config{GLOBAL_ALLOW}  ? $config{GLOBAL_ALLOW}  : "Unset" ) . "]" );
	logfile( "normal", "info", "[STARTUP] Global Tracking (Deny List) ["   . ( $config{GLOBAL_DENY}   ? $config{GLOBAL_DENY}   : "Unset" ) . "]" );
	logfile( "normal", "info", "[STARTUP] Global Tracking (DynDNS List) [" . ( $config{GLOBAL_DYNDNS} ? $config{GLOBAL_DYNDNS} : "Unset" ) . "]" );

	&global;
	$globaltimeout = 0;

	if ( $config{LF_GLOBAL} < 300 )
	{
		logfile( "LF_GLOBAL refresh increased to 300 to prevent looping (csf.conf setting: $config{LF_GLOBAL})" );
		$config{LF_GLOBAL} = 300;
	}

	if ( $config{GLOBAL_DYNDNS_INTERVAL} < 300 )
	{
		logfile( "GLOBAL_DYNDNS_INTERVAL refresh increased to 300 to prevent looping (csf.conf setting: $config{GLOBAL_DYNDNS_INTERVAL})" );
		$config{GLOBAL_DYNDNS_INTERVAL} = 300;
	}
}

# #
#	CC_LOOKUPS			Displays geographical information about a reported IP address. 
#   					This option can be configured to use the databases defined in CC_SRC.
#   
#   					"0" - disable
#   					"1" - Reports: Country Code and Country
#   					"2" - Reports: Country Code and Country and Region and City
#   					"3" - Reports: Country Code and Country and Region and City and ASN
#   					"4" - Reports: Country Code and Country and Region and City (db-ip.com)
# #

# CC_IGNORE
my $cc_ignore 		= defined( $config{CC_IGNORE} ) ? $config{CC_IGNORE} : '';
$cc_ignore 			=~ s/^\s+|\s+$//g; # trim spaces

# CC_LOOKUP
my $cc_lookup_mode 	= defined( $config{CC_LOOKUPS} ) ? "$config{CC_LOOKUPS}" : "0";
my %cc_lookup_desc = (
	"0" => "Disabled",
	"1" => "Country Code + Country",
	"2" => "Country Code + Country + Region + City",
	"3" => "Country Code + Country + Region + City + ASN",
	"4" => "Country Code + Country + Region + City (db-ip.com)",
);

# #
#	lfd.pl › Country Codes
#	
#   Display Country Code and Country for reported IP addresses. This option can
#   be configured to use the databases enabled at the top of this section. An
#   additional option is also available if you cannot use those databases:
#   
#   "0" - disable
#   "1" - Reports: Country Code and Country
#   "2" - Reports: Country Code and Country and Region and City
#   "3" - Reports: Country Code and Country and Region and City and ASN
#   "4" - Reports: Country Code and Country and Region and City (db-ip.com)
# #

logfile( "normal", "info", "[STARTUP] CC Lookups [" . ( $config{CC_LOOKUPS} ? "Enabled" : "Disabled" ) . "]" );

if ( $config{CC_LOOKUPS} )
{
	if ( $config{CC_LOOKUPS} != 4 and $config{MM_LICENSE_KEY} eq "" and $config{CC_SRC} eq "1" )
	{
        logfile( "normal", "error", "[CC] Error! Country Code Lookups setting MM_LICENSE_KEY must be set in /etc/csf/csf.conf to continue updating the MaxMind databases" );
	}

	&countrycodelookups;
	$ccltimeout = 0;
}

# #
#	lfd.pl › Country Codes
#	
#	CC_DENY				Deny incoming connections from the listed countries on all ports.
#						Use two-letter ISO country codes, e.g. "US,GB,DE".
#	
#	CC_ALLOW			Allow incoming connections from the listed countries on all ports.
#						Use two-letter ISO country codes, e.g. "US,GB,DE".
#	
#	CC_ALLOW_FILTER		Only allow connections from the listed countries, while still applying
#						port and packet filtering rules. All other connections are dropped.
#						Use two-letter ISO country codes, e.g. "US,GB,DE".
#	
#	CC_ALLOW_PORTS		Allow the listed countries access only to the ports defined in
#						CC_ALLOW_PORTS_TCP and CC_ALLOW_PORTS_UDP.
#						Use two-letter ISO country codes, e.g. "US,GB,DE".
#	
#	CC_DENY_PORTS		Deny the listed countries access to the ports defined in
#						CC_DENY_PORTS_TCP and CC_DENY_PORTS_UDP.
#						Use two-letter ISO country codes, e.g. "US,GB,DE".
#	
#	CC_ALLOW_SMTPAUTH	Only advertise SMTP AUTH in Exim to the listed countries to help
#						reduce distributed SMTP AUTH attacks.
#						Use two-letter ISO country codes, e.g. "US,GB,DE".
# #

my $cc_enabled = grep { $config{$_} } qw(
    CC_DENY
    CC_ALLOW
    CC_ALLOW_FILTER
    CC_ALLOW_PORTS
    CC_DENY_PORTS
    CC_ALLOW_SMTPAUTH
);

logfile( "normal", "info", "[STARTUP] CC Initialize [" . ( $cc_enabled ? "Enabled" : "Disabled" ) . "]" );

if ( $cc_enabled )
{
	if ( $config{MM_LICENSE_KEY} eq "" and $config{CC_SRC} eq "1" )
	{
        logfile( "normal", "error", "[CC] Error! Country Code Filters setting MM_LICENSE_KEY must be set in /etc/csf/csf.conf to continue updating the MaxMind databases" );
	}

	&countrycode;
	$cctimeout = 0;
}

# #
#   CC_IGNORE			Any countries defined in CC_IGNORE will tell lfd to skip auto-blocking for
#   					IPs from these specified countries/ASNs.
#   
#   					Does NOT override CC_DENY or any other firewall block rules.
#   
#   					This setting requires CC_LOOKUPS to be enabled, or CC_IGNORE is ignored.
#   
#   					Each option is a comma separated list of CC's, e.g. "US,GB,DE,AS15169"
# #

logfile( "normal", "info", "[STARTUP] CC Ignore Countries [" . ( $cc_ignore ne '' ? $cc_ignore : "Disabled" ) . "]" );

if ( $cc_ignore )
{
	logfile( "(CC_IGNORE) Lookup Database [Option $cc_lookup_mode: " . ( $cc_lookup_desc{$cc_lookup_mode} // "Unknown" ) . "]" );

	# if CC_LOOKUPS mode is "0" (disabled), clear CC_IGNORE.
	$config{CC_IGNORE} = "" if $cc_lookup_mode eq "0";
}

# # 
#   System Integrity Checking. This enables lfd to compare md5sums of the
#   servers OS binary application files from the time when lfd starts. If the
#   md5sum of a monitored file changes an alert is sent. This option is intended
#   as an IDS (Intrusion Detection System) and is the last line of detection for
#   a possible root compromise.
#   
#   There will be constant false-positives as the servers OS is updated or
#   monitored application binaries are updated. However, unexpected changes
#   should be carefully inspected.
#   
#   Modified files will only be reported via email once.
#   
#   To enable this feature set the following to the checking interval in seconds
#   (a value of 3600 would seem sensible). This option may increase server I/O
#   load onto the server as it checks system binaries.
#   
#   If set lower than 120 seconds; will revert back to 300 seconds.
#   
#   To disable set to "0"
# # 

logfile( "normal", "info", "[STARTUP] Integrity Tracking [" . ( $config{LF_INTEGRITY} ? "Enabled" : "Disabled" ) . "]" );

my $MIN_INTEGRITY_INTERVAL = 120;
if ( $config{LF_INTEGRITY} )
{
    &integrity;
    $integritytimeout = 0;

    if ( $config{LF_INTEGRITY} < $MIN_INTEGRITY_INTERVAL )
    {
        logfile( "(LF_INTEGRITY): Setting lower than $MIN_INTEGRITY_INTERVAL seconds. Reverting back to 300 to prevent looping (csf.conf setting: $config{LF_INTEGRITY})" );
        $config{LF_INTEGRITY} = 300;
    }
}

# # 
#   System Exploit Checking. This option is designed to perform a series of tests
#   to send an alert in case a possible server compromise is detected
#   
#   To enable this feature set the following to the checking interval in seconds
#   (a value of 300 would seem sensible).
#   
#   If set lower than 60 seconds; will revert back to 60 seconds.
#   
#   To disable set to "0"
# # 

logfile( "normal", "info", "[STARTUP] Exploit Tracking [" . ( $config{LF_EXPLOIT} ? "Enabled" : "Disabled" ) . "]" );

if ( $config{LF_EXPLOIT} )
{
	if ( -e "/var/lib/csf/csf.tempexploit" )
	{
		unlink ( "/var/lib/csf/csf.tempexploit" );
	}

	if ( -e "/etc/csf/csf.suignore" )
	{
		my $count 		= 0;
		my @entries 	= slurp( "/etc/csf/csf.suignore" );

		foreach my $line ( @entries )
		{
			if ( $line =~ /^Include\s*(.*)$/ )
			{
				my @incfile = slurp( $1 );
				push @entries, @incfile;
			}
		}
	
		foreach my $line ( @entries )
		{
			$line =~ s/$cleanreg//g;
			if ( $line eq "" ) { next }
			if ( $line =~ /^\s*\#|Include/ ) { next }

			$suignore{$line} = 1;
			$count++;
		}

		logfile( "(csf.suignore): " . ( $count > 0 ? $count : "0" ) . " entries" );
	}

	&exploit;
	$exploittimeout = 0;

	if ( $config{LF_EXPLOIT} < 60 )
	{
		logfile( "(LF_EXPLOIT): Value set lower than 60 seconds. Reverting back to 60 to prevent looping (csf.conf setting: $config{LF_EXPLOIT})" );
		$config{LF_EXPLOIT} = 60;
	}
}

if ( $config{X_ARF} )
{
	if ( -e $config{HOST} )
	{
		$abuseip = 1
	}
	else
	{
		logfile( "Binary location of HOST is incorrect in csf.conf" )
	}
}

# #
#   Enable Directory Watching
#	
#	This enables lfd to check /tmp and /dev/shm directories for suspicious
#	files, i.e. script exploits. If a suspicious file is found an email alert 
#	is sent. One alert per file per LF_FLUSH interval is sent.
#   
#   To enable this feature set the following to the checking interval in seconds.
#   To disable set to "0"
# # 

my $dirwatch = defined( $config{LF_DIRWATCH}) ? $config{LF_DIRWATCH} : '' ;
$dirwatch =~ s/^\s+|\s+$//g;

logfile( "normal", "info", "[STARTUP] Directory Watch (Core) [" . ( $dirwatch =~ /^\d+$/ && $dirwatch > 0 ? "Enabled ($dirwatch seconds)" : "Disabled" ) . "]" );

if ( $dirwatch )
{
	if ( -e "/etc/csf/csf.fignore" )
	{
		my $count 		= 0;
		my @entries 	= slurp( "/etc/csf/csf.fignore" );

		foreach my $line ( @entries )
		{
			if ( $line =~ /^Include\s*(.*)$/ )
			{
				my @incfile = slurp( $1 );
				push @entries, @incfile;
			}
		}

		foreach my $line ( @entries )
		{
			$line =~ s/$cleanreg//g;
			if ( $line eq "" ) { next }
			if ( $line =~ /^\s*\#|Include/ ) { next }
			if ( $line =~ /\*|\\/ )
			{
				if ( &testregex( $line ) )
				{
					push @matchfile, $line
				}
				else
				{
					logfile( "(csf.fignore) Error: Invalid regex [$line] in csf.fignore" )
				}
			}
			elsif ( $line =~ /^user:(.*)/ )
			{
				$skipuser{$1} = 1;
			}
			else
			{
				$skipfile{$line} = 1;
			}

			$count++;
		}

		logfile( "(csf.fignore): " . ( $count > 0 ? $count : "0" ) . " entries" );
	}

	if ( -e "/var/lib/csf/csf.tempfiles" ) { unlink ( "/var/lib/csf/csf.tempfiles" ) }
	if ( -e "/var/lib/csf/csf.dwdisable" ) { unlink ( "/var/lib/csf/csf.dwdisable" ) }

	$dirwatchtimeout = 0;
}

# # 
#   This option allows you to have lfd watch a particular file or directory for
#   changes and should they change and email alert using watchalert.txt is sent
#   
#   To enable this feature; set LF_DIRWATCH_FILE to the checking interval in seconds
#   (a value of 60 would seem sensible) and add your entries to csf.dirwatch
#   
#   Set to disable set to "0"
# # 

my $dirwatch_file = defined( $config{LF_DIRWATCH_FILE}) ? $config{LF_DIRWATCH_FILE} : '' ;
$dirwatch_file =~ s/^\s+|\s+$//g;

logfile( "normal", "info", "[STARTUP] Directory Watch (File) [" . ( $dirwatch_file =~ /^\d+$/ && $dirwatch_file > 0 ? "Enabled ($dirwatch_file seconds)" : "Disabled" ) . "]" );

if ( $config{LF_DIRWATCH_FILE} )
{
	if ( -e "/etc/csf/csf.dirwatch" )
	{
		my $count 		= 0;
		my @entries 	= slurp( "/etc/csf/csf.dirwatch" );
	
		foreach my $line ( @entries )
		{
			if ( $line =~ /^Include\s*(.*)$/ )
			{
				my @incfile = slurp( $1 );
				push @entries, @incfile;
			}
		}

		foreach my $line ( @entries )
		{
			$line =~ s/$cleanreg//g;
			if ( $line eq "" ) { next }
			if ( $line =~ /^\s*\#|Include/ ) { next }
			if ( -e $line )
			{
				$dirwatchfile{$line} = 1;
				$count++;
			}
			else
			{
				logfile( "(csf.dirwatch): Directory File Watching [$line] not found - ignoring" );
			}
		}

		logfile( "(csf.dirwatch): " . ( $count > 0 ? $count : "0" ) . " entries" );

		&dirwatchfile;
		$dirwatchfiletimeout = 0;
	}
}

# # 
#   Enable scanning of the exim mainlog for repeated emails sent from scripts.
#   To use this feature the exim log_selector option must at least be set to:
#   
#   log_selector = +arguments +subject +received_recipients
#   
#   If you already use extended exim logging, then you need to either include
#   +arguments +received_recipients or use +all
#   
#   This setting will then send an alert email if more than LF_SCRIPT_LIMIT lines
#   appear with the same cwd= path in them within an hour. This can be useful in
#   identifying spamming scripts on a server, especially PHP scripts running
#   under the nobody account. The email that is sent includes the exim log lines
#   and also attempts to find scripts that send email in the path that may be the
#   culprit
# # 

logfile( "normal", "info", "[STARTUP] Email Script Tracking [" . ( $config{LF_SCRIPT_ALERT} ? "Enabled" : "Disabled" ) . "]" );

if ( $config{LF_SCRIPT_ALERT} )
{
	if ( -e "/etc/csf/csf.signore" )
	{
		my $count 		= 0;
		my @entries 	= slurp( "/etc/csf/csf.signore" );

		foreach my $line ( @entries )
		{
			if ( $line =~ /^Include\s*(.*)$/ )
			{
				my @incfile = slurp( $1 );
				push @entries, @incfile;
			}
		}

		foreach my $line ( @entries )
		{
			$line =~ s/$cleanreg//g;
			if ( $line eq "" ) { next }
			if ( $line =~ /^\s*\#|Include/ ) { next }
			$skipscript{$line} = 1;
			$count++;
		}

		logfile( "(csf.signore): " . ( $count > 0 ? $count : "0" ) . " entries" );
	}
}

# # 
#   Checks the length of the exim queue and sends an alert email if the value of
#   settings is exceeded. If the ConfigServer MailScanner configuration is used
#   then both the pending and delivery queues will be checked.
#   
#   Note: If there are problems sending out email, this alert may not be received
#   To disable set to "0"
# # 

logfile( "normal", "info", "[STARTUP] Email Queue Tracking [" . ( $config{LF_QUEUE_ALERT} ? "Enabled" : "Disabled" ) . "]" );

if ( $config{LF_QUEUE_ALERT} )
{
	&queuecheck;
	$queuetimeout = 0;

	if ( $config{LF_QUEUE_INTERVAL} < 30 )
	{
		logfile( "(LF_QUEUE_INTERVAL): Value set lower than 30 seconds. Reverting back to 300 to prevent looping (csf.conf setting: $config{LF_QUEUE_INTERVAL})" );
		$config{LF_QUEUE_INTERVAL} = 300;
	}
}

# # 
#   This option will send an alert if the ModSecurity IP persistent storage grows
#   excessively large: https://goo.gl/rGh5sF
#   
#   More information on cPanel servers here: https://goo.gl/vo6xTE
#   
#   The check is performed at lfd startup and then once per hour, the template
#   used is modsecipdbalert.txt
#   
#   LF_MODSECIPDB_FILE must be set to the correct location of the database file
#   
#   Set to "0" to disable this option, otherwise it is the threshold size of the
#   file to report in gigabytes, e.g. set to 5 for 5GB
# # 

logfile( "normal", "info", "[STARTUP] ModSecurity IP DB Tracking [" . ( $config{LF_MODSECIPDB_ALERT} ? "Enabled" : "Disabled" ) . "]" );

if ( $config{LF_MODSECIPDB_ALERT} )
{
	&modsecipdbcheck;
	$modsecipdbchecktimeout = 0;
}

my $rt_enabled = grep { $config{$_} } qw(
    RT_RELAY_ALERT
    RT_AUTHRELAY_ALERT
    RT_POPRELAY_ALERT
    RT_LOCALRELAY_ALERT
    RT_LOCALHOSTRELAY_ALERT
);

logfile( "normal", "info", "[STARTUP] Email Relay Tracking [" . ( $rt_enabled ? "Enabled" : "Disabled" ) . "]" );

if ( $rt_enabled )
{

	# # 
	#   This option triggers for email sent via /usr/sbin/sendmail or /usr/sbin/exim
	# # 

	logfile( "normal", "info", "[STARTUP] Email Local Relay Alerts [" . ( $config{RT_LOCALRELAY_ALERT} ? "Enabled" : "Disabled" ) . "]" );

	if ( $config{RT_LOCALRELAY_ALERT} )
	{
		if ( -e "/etc/csf/csf.mignore" )
		{

			my $count 		= 0;
			my @entries 	= slurp("/etc/csf/csf.mignore");

			foreach my $line ( @entries )
			{
				if ( $line =~ /^Include\s*(.*)$/ )
				{
					my @incfile = slurp( $1 );
					push @entries, @incfile;
				}
			}

			foreach my $line ( @entries )
			{
				$line =~ s/$cleanreg//g;
				if ( $line eq "" ) { next }
				if ( $line =~ /^\s*\#|Include/ ) { next }
				$rtignore{$line} = 1;
				$count++;
			}

			logfile( "(csf.mignore): " . ( $count > 0 ? $count : "0" ) . " entries" );
		}
	}
}

# # 
#   Temporary to Permanent IP Blocking
#	
#   Permanently block IP addresses that have been temporarily blocked more than
#   LF_PERMBLOCK_COUNT times in the last LF_PERMBLOCK_INTERVAL seconds. Set
#   LF_PERMBLOCK  to "1" to enable this feature
#   
#   Care needs to be taken when setting LF_PERMBLOCK_INTERVAL as it needs to be
#   at least LF_PERMBLOCK_COUNT multiplied by the longest temporary time setting
#   (TTL) for blocked IPs, to be effective
#   
#   Set LF_PERMBLOCK to "0" to disable this feature
# # 

logfile( "normal", "info", "[STARTUP] Temp to Perm Block Tracking [" . ( $config{LF_PERMBLOCK} ? "Enabled" : "Disabled" ) . "]" );

# # 
#   Permanently block IPs by network class.
#	
#   Permanently block classes of IP address where individual IP addresses
#   within the same class LF_NETBLOCK_CLASS have already been blocked more than
#   LF_NETBLOCK_COUNT times in the last LF_NETBLOCK_INTERVAL seconds. Set
#   LF_NETBLOCK  to "1" to enable this feature
#   
#   This can be an affective way of blocking DDOS attacks launched from within
#   the same network class
#   
#   Valid settings for LF_NETBLOCK_CLASS are "A", "B" and "C", care and
#   consideration is required when blocking network classes A or B
#   
#   Set LF_NETBLOCK to "0" to disable this feature
# # 

logfile( "normal", "info", "[STARTUP] Netblock Tracking [" . ( $config{LF_NETBLOCK} ? "Enabled" : "Disabled" ) . "]" );

if ( $config{LF_PERMBLOCK} or $config{LF_NETBLOCK} )
{
    my $count = 0;

	sysopen ( my $TEMPIP, "/var/lib/csf/csf.tempip", O_RDWR | O_CREAT );
	flock ( $TEMPIP, LOCK_EX );
	my @data = <$TEMPIP>;
	chomp @data;
	seek ( $TEMPIP, 0, 0 );
	truncate ( $TEMPIP, 0 );

	foreach my $line ( @data )
	{
		my ( $oip, $operm, $otime, $omessage ) = split( /\|/,$line, 4 );
		my $interval 	= time - $otime;
		my $old 		= 1;

		if ( $config{LF_PERMBLOCK} and $interval < ( $config{LF_PERMBLOCK_INTERVAL} * $config{LF_PERMBLOCK_COUNT} ) )
		{
			$old = 0
		}

		if ( $config{LF_NETBLOCK} and $interval < ( $config{LF_NETBLOCK_INTERVAL} * $config{LF_NETBLOCK_COUNT} ) )
		{
			$old = 0
		}

		unless ( $old )
		{
			print $TEMPIP "$line\n";
			$count++;
		}
	}

	close ( $TEMPIP );

	my $count_old = scalar( @data ) - $count;
	logfile( "(csf.tempip): " . ( $count > 0 ? $count : "0" ) . " entries (removed $count_old)" );
}

# # 
#   This option will gather basic system statistics. Through the UI it displays
#   various graphs for disk, cpu, memory, network, etc usage over 4 intervals:
#       . Hourly (per minute)
#       . 24 hours (per minute)
#       . 7 days (per minute averaged over an hour)
#       . 30 days (per minute averaged over an hour) - user definable
#   The data is stored in /var/lib/csf/stats/system and the option requires the
#   perl GD::Graph module
#   
#   Note: Disk graphs do not show on Virtuozzo/OpenVZ servers as the kernel on
#   those systems do not store the required information in /proc/diskstats
#   On new installations or when enabling this option it will take time for these
#   graphs to be populated
#   
#   This setting MUST be "1" to enable the following buttons:
#       - View System Statistics
# # 

logfile( "normal", "info", "[STARTUP] System Statistics [" . ( $config{ST_SYSTEM} ? "Enabled ($config{ST_SYSTEM})" : "Disabled" ) . "]" );

if ( $config{ST_SYSTEM} )
{
	my $time = time;
	sysopen ( my $SYSSTATNEW, "/var/lib/csf/stats/system.new", O_RDWR | O_CREAT );
	flock ( $SYSSTATNEW, LOCK_EX );
	seek ( $SYSSTATNEW, 0, 0 );
	truncate ( $SYSSTATNEW, 0 );

	sysopen ( my $SYSSTAT, "/var/lib/csf/stats/system", O_RDWR | O_CREAT );
	flock ( $SYSSTAT, LOCK_EX );

	my $count   	= 0;
	my $count_old 	= 0;

	while ( my $line = <$SYSSTAT> )
	{
		chomp $line;
		my ($thistime, undef) = split( /\,/, $line );

		if ( $time - $thistime > ( 86400 * $config{ST_SYSTEM_MAXDAYS} ) )
		{
			$count_old++;
			next;
		}

		print $SYSSTATNEW "$line\n";
		$count++;
	}

	close ( $SYSSTAT );
	close ( $SYSSTATNEW );
	rename "/var/lib/csf/stats/system.new", "/var/lib/csf/stats/system";

	logfile( "(/var/lib/csf/stats/system): " . ( $count > 0 ? $count : "0" ) . " entries (removed $count_old)" );

	&systemstats;
}

# #
#   Port Scan Tracking
#	
#	This feature tracks port blocks logged by iptables to syslog. If an IP 
#	address generates a port block that is logged more than PS_LIMIT within 
#	PS_INTERVAL seconds, the IP address will be blocked.
#   
#   This feature could, for example, be useful for blocking hackers attempting
#   to access the standard SSH port if you have moved it to a port other than 22
#   and have removed 22 from the TCP_IN list so that connection attempts to the
#   old port are being logged
#   
#   Set PS_INTERVAL to "0" to disable this feature. A value of between 60 and 300
#   would be sensible to enable this feature
#   
#   SECURITY NOTE: 		This option is affected by the RESTRICT_SYSLOG option.
#						Read this file about RESTRICT_SYSLOG before enabling 
#						this option.
# # 

logfile( "normal", "info", "[STARTUP] Port Scan Tracking [" . ( $config{PS_INTERVAL} ? "Enabled ($config{PS_INTERVAL})" : "Disabled" ) . "]" );

if ( $config{PS_INTERVAL} )
{
	if ( $config{PS_INTERVAL} < 60 )
	{
		logfile( "(PS_INTERVAL): Value set lower than 60 seconds. Reverting back to 60 to prevent looping (csf.conf setting: $config{PS_INTERVAL})" );
		$config{PS_INTERVAL} = 60;
	}
	$pstimeout = 0;
}

# #
#   User ID Tracking
#	
#	This feature tracks UID blocks logged by iptables to syslog. If a UID 
#	generates a port block that is logged more than UID_LIMIT times within 
#	UID_INTERVAL seconds, an alert will be sent
#   
#   Note: This feature will only track iptables blocks from the log file set in
#   IPTABLES_LOG and if DROP_OUT_LOGGING and DROP_UID_LOGGING are enabled.
#   
#   To ignore specific UIDs list them in csf.uidignore and then restart lfd
#   
#   Set UID_INTERVAL to "0" to disable this feature. A value of between 60 and
#	300 would be sensible to enable this feature
#   
#   SECURITY NOTE: This option is affected by the RESTRICT_SYSLOG option. Read
#   this file about RESTRICT_SYSLOG before enabling this option:
# # 

logfile( "normal", "info", "[STARTUP] User ID Tracking [" . ( $config{UID_INTERVAL} ? "Enabled ($config{UID_INTERVAL})" : "Disabled" ) . "]" );

if ( $config{UID_INTERVAL} )
{
	if ( $config{UID_INTERVAL} < 60 )
	{
		logfile( "(UID_INTERVAL): Value set lower than 60 seconds. Reverting back to 60 to prevent looping (csf.conf setting: $config{UID_INTERVAL})" );
		$config{UID_INTERVAL} = 60;
	}

	$uidtimeout 	= 0;
	my $count 		= 0;
	my @entries 	= slurp( "/etc/csf/csf.uidignore" );

	foreach my $line ( @entries )
	{
		if ( $line =~ /^Include\s*(.*)$/ )
		{
			my @incfile = slurp( $1 );
			push @entries, @incfile;
		}
	}

	foreach my $line ( @entries )
	{
		$line =~ s/$cleanreg//g;
		if ( $line eq "" ) { next }
		if ( $line =~ /^\s*\#|Include/ ) { next }
		$uidignore{$line} = 1;
		$count++;
	}

	logfile( "(csf.uidignore): " . ( $count > 0 ? $count : "0" ) . " entries" );
}

# #
#   Connection Tracking
#	
#	This option enables tracking of all connections from IP addresses to the 
#	server. If the total number of connections is greater than this value then 
#	the offending IP address is blocked. This can be used to help prevent some 
#	types of DOS attack.
#   
#   Care should be taken with this option. It's entirely possible that you will
#   see false-positives. Some protocols can be connection hungry, e.g. FTP, IMAPD
#   and HTTP so it could be quite easy to trigger, especially with a lot of
#   closed connections in TIME_WAIT. However, for a server that is prone to DOS
#   attacks this may be very useful. A reasonable setting for this option might
#   be around 300
#   
#   To disable this feature, set this to 0
# # 

logfile( "normal", "info", "[STARTUP] Connection Tracking" . ( $config{CT_STATES} ? " ($config{CT_STATES})" : "" ) . " [" . ( $config{CT_LIMIT} ? "Enabled" : "Disabled" ) . "]" );

if ( $config{CT_LIMIT} )
{
	&connectiontracking;
	$cttimeout = 0;
	if ( $config{CT_INTERVAL} < 10 )
	{
		logfile( "(CT_INTERVAL): Value set lower than 10 seconds. Reverting back to 30 to prevent looping (csf.conf setting: $config{CT_INTERVAL})" );
		$config{CT_INTERVAL} = 30;
	}
}

# #
#   Process Tracking
#	
#	This option enables tracking of user and nobody processes and examines them 
#	for suspicious executables or open network ports. Its purpose is to identify
#	potential exploit processes that are running on the server, even if they are
#	obfuscated to appear as system services.
#	
#	If a suspicious process is found an alert email is sent with relevant 
#	information.
#	
#   It is then the responsibility of the recipient to investigate the process
#   further as the script takes no further action
#   
#   PT_LIMIT is the number of seconds a process has to be active before it
#   is inspected. If you set this time too low, then you will likely trigger
#   false-positives with CGI or PHP scripts.
#	
#   Set the value to 0 to disable this feature
# # 

logfile( "normal", "info", "[STARTUP] Process Tracking [" . ( $config{PT_LIMIT} ? "Enabled ($config{PT_LIMIT})" : "Disabled" ) . "]" );

if ( $config{PT_LIMIT} )
{
	if ( -e "/etc/csf/csf.pignore" )
	{
		my $count 		= 0;
		my @entries 	= slurp( "/etc/csf/csf.pignore" );
	
		foreach my $line ( @entries )
		{
			if ( $line =~ /^Include\s*(.*)$/ )
			{
				my @incfile = slurp( $1 );
				push @entries, @incfile;
			}
		}

		foreach my $line ( @entries )
		{
	        $line =~ s/$cleanreg//g;
			if ( $line eq "" ) { next }
			if ( $line =~ /^\s*\#|Include/ ) { next }
			my ( $item, $rule ) = split( /:/, $line, 2 );
			$rule =~ s/\r|\n//g;
			$rule =~ s/\s*$//g;
			$item =~ s/\s//g;
			$item = lc $item;
	
			if ( $item =~ /^(cmd|exe|user)$/ )
			{
				$skip{$item}{$rule} = 1;
				$count++;
			}
			elsif ( $item =~ /^(pcmd|pexe|puser)$/ )
			{
				if ( &testregex( $rule ) )
				{
					$pskip{$item}{$rule} = 1;
					$count++;
				}
				else
				{
					logfile( "*Error* Invalid regex [$line] in csf.pignore" );
				}
			}
		}

		logfile( "(csf.pignore): " . ( $count > 0 ? $count : "0" ) . " entries" );
	}

	if ( -e "/var/lib/csf/csf.temppids" ) { unlink ( "/var/lib/csf/csf.temppids" ) }
	if ( -e "/var/lib/csf/csf.tempusers" ) { unlink ( "/var/lib/csf/csf.tempusers" ) }

	&processtracking;
	$pttimeout = 0;

	if ( $config{PT_INTERVAL} < 10 )
	{
		logfile( "(PT_INTERVAL): Value set lower than 10 seconds. Reverting back to 30 to prevent looping (csf.conf setting: $config{PT_INTERVAL})" );
		$config{PT_INTERVAL} = 60;
	}

	logfile( "normal", "info", "[STARTUP] Hung Session Tracking [" . ( $config{PT_SSHDHUNG} ? "Enabled" : "Disabled" ) . "]" );
}

# #
#   Account Tracking
#	
#	The following options enable the tracking of modifications to the accounts
#	on a server. If any of the enabled options are triggered by a modifications
#	to an account, an alert email is sent. Only the modification is reported.
#	
#	The cause of the modification will have to be investigated manually.
#   
#   You can set AT_ALERT to the following:
#   0 = disable this feature
#   1 = enable this feature for all accounts
#   2 = enable this feature only for superuser accounts (UID = 0, e.g. root, etc)
#   3 = enable this feature only for the root account
# # 

logfile( "normal", "info", "[STARTUP] Account Tracking [" . ( $config{AT_ALERT} ? "Enabled" : "Disabled" ) . "]" );

if ( $config{AT_ALERT} )
{
	if ( $config{AT_ALERT} == 3 )
	{
		my ( $user, $passwd, $uid, $gid, $quota, $comment, $gcos, $dir, $shell ) = getpwnam( "root" );
		$accounttracking{$user}{account} 		= 1;
		$accounttracking{$user}{passwd} 		= $passwd;
		$accounttracking{$user}{uid} 			= $uid;
		$accounttracking{$user}{gid} 			= $gid;
		$accounttracking{$user}{dir} 			= $dir;
		$accounttracking{$user}{shell} 			= $shell;
	}
	else
	{
		while ( my ( $user, $passwd, $uid, $gid, $quota, $comment, $gcos, $dir, $shell ) = getpwent( ) )
		{
			if ( ( $config{AT_ALERT} eq "2" ) and ( $uid ne "0" ) )
			{
				next
			}

			$accounttracking{$user}{account} 	= 1;
			$accounttracking{$user}{passwd} 	= $passwd;
			$accounttracking{$user}{uid} 		= $uid;
			$accounttracking{$user}{gid} 		= $gid;
			$accounttracking{$user}{dir} 		= $dir;
			$accounttracking{$user}{shell} 		= $shell;
		}

		endpwent();
	}

	$attimeout = 0;
	if ( $config{AT_INTERVAL} < 10 )
	{
		logfile( "(AT_INTERVAL): Value set lower than 10 seconds. Reverting back to 60 to prevent looping (csf.conf setting: $config{AT_INTERVAL})" );
		$config{AT_INTERVAL} = 60;
	}
}

# # 
#   Send an email alert if anyone accesses WHM/cPanel via an account listed in
#   LF_CPANEL_ALERT_USERS. An IP address will be reported again 1 hour after the
#   last tracked access (or if lfd is restarted)
# # 

logfile( "normal", "info", "[STARTUP] WHM Tracking [" . ( $config{LF_CPANEL_ALERT} ? "Enabled" : "Disabled" ) . "]" );

if ( $config{LF_CPANEL_ALERT} )
{
	$config{LF_CPANEL_ALERT_USERS} =~ s/\s//g;
	foreach my $user ( split( /\,/, $config{LF_CPANEL_ALERT_USERS} ) )
	{
		$cpanelalertusers{$user} = 1;
	}
}

# #
#   Port Knocking
#	
#	This feature allows port knocking to be enabled on multiple ports with a 
#	variable number of knocked ports and a timeout. There must be a minimum of
#	3 ports to knock for an entry to be valid
#   
#   See the following for information regarding Port Knocking:
#   https://en.wikipedia.org/wiki/Port_knocking
#   
#   This feature does not work on servers that do not have the iptables module
#   ipt_recent loaded. Typically, this will be with MONOLITHIC kernels. VPS
#   server admins should check with their VPS host provider that the iptables
#   module is included
#   
#   For further information and syntax refer to the Port Knocking section of the
#   csf readme.txt
#   
#   Note: Run /etc/csf/csftest.pl to check whether this option will function on
#   this server
#   
#   openport;protocol;timeout;kport1;kport2;kport3[...;kportN],...
#   e.g.: 22;TCP;20;100;200;300;400
# # 

logfile( "normal", "info", "[STARTUP] Port Knocking Tracking [" . ( $config{PORTKNOCKING} && $config{PORTKNOCKING_ALERT} ? "Enabled" : "Disabled" ) . "]" );

my $sshdef 				= $config{PORTS_sshd};
$ports{pop3d} 			= $config{PORTS_pop3d};
$ports{imapd} 			= $config{PORTS_imapd};
$ports{htpasswd} 		= $config{PORTS_htpasswd};
$ports{mod_security} 	= $config{PORTS_mod_security};
$ports{mod_qos} 		= $config{PORTS_mod_qos};
$ports{symlink} 		= $config{PORTS_symlink};
$ports{cxs} 			= $config{PORTS_cxs};
$ports{bind} 			= $config{PORTS_bind};
$ports{suhosin} 		= $config{PORTS_suhosin};
$ports{cpanel} 			= $config{PORTS_cpanel};
$ports{ftpd} 			= $config{PORTS_ftpd};
$ports{smtpauth} 		= $config{PORTS_smtpauth};
$ports{eximsyntax} 		= $config{PORTS_eximsyntax};
$ports{webmin} 			= $config{PORTS_webmin};
$ports{directadmin} 	= $config{PORTS_directadmin};

opendir ( DIR, "/etc/chkserv.d" );
while ( my $file = readdir ( DIR ) )
{
	if ( $file =~ /exim-(\d+)/ )
	{
		$ports{smtpauth} .= ",$1";
		$ports{eximsyntax} .= ",$1";
	}
}
closedir ( DIR );

# #
#	Generate SSH ports
# #

if ( -e "/etc/ssh/sshd_config" )
{
	foreach my $line ( slurp( "/etc/ssh/sshd_config" ) )
	{
		$line =~ s/$cleanreg//g;
		if ( $line =~ /^(\s|\#|$)/ ) { next }
		if ( $line =~ /^Port\s+(\d+)/i )
		{
			my $port = $1;
			if ( $ports{sshd} )
			{
				$ports{sshd} .= ",$port";
			}
			else
			{
				$ports{sshd} = $port;
			}
		}
	}
}

unless ( $ports{sshd} )
{
	$ports{sshd} = $sshdef;
}

logfile( "(/etc/ssh/sshd_config): [" . ( $ports{sshd} || "None" ) . "]" );

# # 
#   Interval to track login and other LF_ failures within (seconds),
#   i.e. LF_TRIGGER failures within the last LF_INTERVAL seconds
# # 

if ( $config{LF_INTERVAL} < 60 )
{
	logfile( "(LF_INTERVAL): Value set lower than 60 seconds. Reverting back to 300 to prevent looping (csf.conf setting: $config{LF_INTERVAL})" );
	$config{LT_INTERVAL} = 300;
}

# # 
#   How long the lfd process sleeps (in seconds) before processing the
#   log file entries and checking whether other events need to be triggered
# # 

if ( $config{LF_PARSE} < 5 or $config{LF_PARSE} > 20 )
{
	logfile( "(LF_PARSE): Value set lower than 5 seconds, greater than 20 seconds. Reverting back to 5 to prevent looping (csf.conf setting: $config{LF_PARSE})" );
	$config{LF_PARSE} = 5;
}

my $lastline 	= "";
$scripttimeout 	= 0;
my $duration 	= 0;
my $maintimer 	= 0;
my $parent_bind = ( defined $config{LFD_PROCESS_BIND} and $config{LFD_PROCESS_BIND} ) ? 1 : 0;

logfile( "normal", "info", "[STARTUP] PID binding: " . ( $parent_bind ? "parent only" : "parent + children" ) . " | PID=$$" );

while ( 1 )
{
	$0 = "lfd - processing";
	$maintimer = time;

	# #
	#    LFD Process Shutdown Ownership
	#   
	#    Controls which LFD processes are allowed to perform a full daemon
	#    shutdown when a fatal error, PID mismatch, or internal failure occurs.
	#   
	#    0 = All LFD processes are allowed to validate the PID file and perform
	#        a full shutdown if an error is detected. (Default behavior)
	#   
	#    1 = Only the main LFD parent process is allowed to stop the daemon.
	#        Child processes will still report errors to the log file but will
	#        exit individually without removing the PID file or terminating the
	#        main LFD process.
	# #

	my $do_pid_check = 1;
	if ( $parent_bind )
	{
		$do_pid_check = ( defined $masterpid and $$ == $masterpid ) ? 1 : 0;
	}

	if ( $do_pid_check )
	{
		seek ( $PIDFILE, 0, 0 );
		my @piddata = <$PIDFILE>;
		chomp @piddata;

		my $file_pid    = defined $piddata[0] ? $piddata[0] : '';
		my $file_ino    = ( stat( $pidfile ) )[1];
		$file_ino       = '' unless defined $file_ino;

		if ( ( $pid ne $file_pid ) or ( $pidino ne $file_ino ) )
		{
			&shutdown( __LINE__, "*Error* pid mismatch or missing [mem=$pid file=$file_pid ino_mem=$pidino ino_file=$file_ino]" );
		}
	}

	if ( -e "/etc/csf/csf.error" )
	{
		&shutdown( __LINE__, "*Error* You have an unresolved error when starting csf. You need to restart csf successfully before restarting lfd (see /etc/csf/csf.error). *lfd stopped*");
	}

	my $perms = sprintf "%04o", ( stat( "/etc/csf" ) )[2] & oct( "07777" );
	if ( $perms != "0600" )
	{
		chmod ( 0600, "/etc/csf" );

		logfile( "normal", "info", "[STARTUP] Permissions* on /etc/csf reset to 0600 [currently: $perms]" );
	}

	$perms = sprintf "%04o", ( stat( "/var/lib/csf" ) )[2] & oct( "07777" );
	if ( $perms != "0600" )
	{
		chmod ( 0600, "/var/lib/csf" );
		logfile( "normal", "info", "[STARTUP] Permissions* on /var/lib/csf reset to 0600 [currently: $perms]" );
	}

	$perms = sprintf "%04o", ( stat( "/usr/local/csf" ) )[2] & oct( "07777" );
	if ( $perms != "0600" )
	{
		chmod ( 0600, "/usr/local/csf" );
		logfile( "normal", "info", "[STARTUP] Permissions* on /usr/local/csf reset to 0600 [currently: $perms]" );
	}

	$locktimeout+=$duration;
	if ( $locktimeout >= 60 )
	{
		$locktimeout = 0;
		&lockhang;
	}

    # #
    #   Forks › Tracked
    #   
    #   Total number of entries stored in %forks; includes stale/dead PIDs.
    #   
    #   This should be set to DEBUG:5; it is insanely verbose and will spam
    #   logs. Prints about eery 5s (defined by LF_PARSE).
    #   
    #   Sep  7 02:15:23 csf lfd[ 258900 ] [lfd:3114] [INFO] [DEBUG:5]: Tracked forks:[187]
    #   Sep  7 02:15:24 csf lfd[ 258900 ] [lfd:3131] [INFO] [DEBUG:1]: Active forks:[3]
    # #

	my $forkcnt_total = scalar( keys %forks );
	logfile( "DEBUG:5", "info", "Tracked forks:[$forkcnt_total]" );

	my $forkcnt_active = 0;
	foreach my $key ( keys %forks )
	{
		if ( $key =~ /\d+/ and $key > 1 and kill( 0, $key ) )
		{
			$forkcnt_active++;
		}
	}

    # #
    #   Forks › Active
    #   
    #   Currently alive PIDs.
    #   
    #   Should be assigned to DEBUG:1 or DEBUG:2; moderately prints to log
    #   about eery 5s (defined by LF_PARSE).
    #   
    #   Sep  7 02:15:24 csf lfd[ 258900 ] [lfd:3131] [INFO] [DEBUG:1]: Active forks:[3]
    # #

	logfile( "DEBUG:1", "info", "Active forks:[$forkcnt_active]" );

    # #
    #   Forks › Cleanup
    #   
    #   When more than 200 fork PIDs are tracked, check each PID and remove
    #   any entries for processes that are no longer running.
    #   
    #   If more than 200 active forks remain after cleanup, restart LFD.
    # #

    if ( $forkcnt_total > FORKS_LIMIT )
	{
		my $forkcnt = 0;
		foreach my $key ( keys %forks )
		{
			if ( $key =~ /\d+/ and $key > 1 and kill( 0, $key ) )
			{
				$forkcnt++;

                # #
                #   Log each PID that survived cleanup
                # #

                logfile( "DEBUG:1", "info", "Fork survived cleanup: key [ $key ]" );
			}
			else
			{
				delete $forks{$key};
			}
		}

        # #
        #   Print total count of forks that survived cleanup
        # #

        logfile( "DEBUG:0", "info", "Forks Survived Cleanup: [$forkcnt]" );

        # #
        #   Forks › Cleanup › Excessive Forks (Post Cleanup)
        #   
        #   If more than 200 active forks remain after cleanup, restart LFD.
        # #

		if ( $forkcnt > FORKS_LIMIT )
		{
			logfile( "normal", "error", "Excessive total number [ $forkcnt ] of children forks, restarting lfd" );
			&lfdrestart;
			exit;
		}
	}

	if ( -e "/var/lib/csf/lfd.restart" )
	{
		unlink ( "/var/lib/csf/lfd.restart" );
		&lfdrestart;
		exit;
	}

	if ( -e "/var/lib/csf/csf.restart" )
	{
		unlink ( "/var/lib/csf/csf.restart" );
		&csfrestart;
	}

	# #
	#	lfd.pl › CSF Restart Tracking
	#	
	#	Periodic CSF health check; unless `TESTING` is enabled.
	#	Check ran every 300 seconds.
	# #

	if ( $config{LF_CSF} )
	{
		$csftimeout+=$duration;
		if ( $csftimeout >= 300 )
		{
			$csftimeout = 0;
			&csfcheck;
		}
	}

	if ($config{SYSLOG_CHECK} and $sys_syslog) {
		$syslogchecktimeout+=$duration;
		if ($syslogchecktimeout >= $config{SYSLOG_CHECK}) {
			$syslogchecktimeout = 0;
			if ($syslogcheckcode eq "") {
				my @chars = ('0'..'9','a'..'z','A'..'Z');
				$syslogcheckcode = join '', map {$chars[rand(@chars)]} (1..(15 + int(rand(15))));
				eval {
					local $SIG{__DIE__} = undef;
					openlog('lfd', 'ndelay,pid', 'user');
					syslog('info', "SYSLOG check [$syslogcheckcode]");
					closelog();
				}
			} else {
				&syslogcheck;
				$syslogcheckcode = "";
			}
		}
	}

	if ($config{ST_SYSTEM}) {
		$systemstatstimeout+=$duration;
		if ($systemstatstimeout >= 60) {
			$systemstatstimeout = 0;
			&systemstats;
		}
	}

	if ($config{LT_POP3D}) {
		$logintimeout{pop3d}+=$duration;
		if ($logintimeout{pop3d} >= 3600) {
			delete $logintimeout{pop3d};
			delete $logins{pop3d};
		}
	}
	if ($config{LT_IMAPD}) {
		$logintimeout{imapd}+=$duration;
		if ($logintimeout{imapd} >= 3600) {
			delete $logintimeout{imapd};
			delete $logins{imapd};
		}
	}
	if ($config{PS_INTERVAL}) {
		$pstimeout+=$duration;
		if ($pstimeout >= $config{PS_INTERVAL}) {
			$pstimeout = 0;
			undef %portscans;
		}
	}
	if ($config{UID_INTERVAL}) {
		$uidtimeout+=$duration;
		if ($uidtimeout >= $config{UID_INTERVAL}) {
			$uidtimeout = 0;
			undef %uidscans;
		}
	}
	if ($config{LF_SCRIPT_ALERT}) {
		$scripttimeout+=$duration;
		if ($scripttimeout >= 3600) {
			$scripttimeout = 0;
			undef %scripts;
		}
	}
	if ($config{LF_APACHE_404}) {
		$apache404timeout+=$duration;
		if ($apache404timeout >= $config{LF_INTERVAL}) {
			$apache404timeout = 0;
			undef %apache404;
		}
	}
	if ($config{LF_APACHE_403}) {
		$apache403timeout+=$duration;
		if ($apache403timeout >= $config{LF_INTERVAL}) {
			$apache403timeout = 0;
			undef %apache403;
		}
	}
	if ($config{LF_APACHE_401}) {
		$apache401timeout+=$duration;
		if ($apache401timeout >= $config{LF_INTERVAL}) {
			$apache401timeout = 0;
			undef %apache401;
		}
	}
	if ($config{RT_RELAY_ALERT} or $config{RT_AUTHRELAY_ALERT} or $config{RT_POPRELAY_ALERT} or $config{RT_LOCALRELAY_ALERT} or $config{RT_LOCALHOSTRELAY_ALERT}) {
		$relaytimeout+=$duration;
		if ($relaytimeout >= 3600) {
			$relaytimeout = 0;
			undef %relays;
		}
	}

	if (-e "/var/lib/csf/csf.tempconf") {
		open (my $IN, "<", "/var/lib/csf/csf.tempconf");
		flock ($IN, LOCK_SH);
		while (my $line = <$IN>) {
			chomp $line;
			if ($line =~ /^\#/) { next }
			if ($line !~ /=/) { next }
			my ($name,$value) = split (/=/,$line,2);
			$name =~ s/\s//g;
			if ($value =~ /\"(.*)\"/) {
				$value = $1;
			} else {
				&shutdown(__LINE__,"*Error* Invalid configuration line in csf.tempconf");
			}
			$config{$name} = $value;
		}
		close ($IN);
	}

	if ($config{GLOBAL_IGNORE} and -e "/var/lib/csf/csf.gignore") {
		undef @gcidrs;
		undef %gignoreips;
		undef $gcidr;
		undef $gcidr6;
		$gcidr = Net::CIDR::Lite->new;
		$gcidr6 = Net::CIDR::Lite->new;
		open (my $IN, "<", "/var/lib/csf/csf.gignore");
		flock ($IN, LOCK_SH);
		while (my $line = <$IN>) {
			chomp $line;
			if ($line =~ /^(\#|\n|\r|\s)/ or $line eq "") { next }
			my ($ip,undef) = split(/\s/,$line);
			my (undef,$iscidr) = split(/\//,$ip);
			my $v = checkip(\$ip);
			if ($v) {
				if ($iscidr) {
					push @gcidrs,$ip;
					undef $@;
					if ($v == 6) {
						eval {local $SIG{__DIE__} = undef; $gcidr6->add($ip)};
					} else {
						eval {local $SIG{__DIE__} = undef; $gcidr->add($ip)};
					}
					if ($@) {logfile("Invalid entry in GLOBAL_IGNORE: $ip")}
				} else {$gignoreips{$ip} = 1}
			}
			elsif ($ip ne "127.0.0.1") {logfile("Invalid entry in GLOBAL_IGNORE: [$ip]")}
		}
		close ($IN);
		unlink "/var/lib/csf/csf.gignore";
	}

	$count = 0;
	$0 = "lfd - scanning log files";
	undef %relayip;
	if ($config{RELAYHOSTS}) {
		open (my $IN, "<", "/etc/relayhosts");
		flock ($IN, LOCK_SH);
		while (my $ip = <$IN>) {
			chomp $ip;
			if (checkip(\$ip)) {$relayip{$ip} = 1}
		}
		close ($IN);
	}
	if ($config{DYNDNS} and $config{DYNDNS_IGNORE}) {
		open (my $IN, "<", "/var/lib/csf/csf.tempdyn");
		flock ($IN, LOCK_SH);
		while (my $ip = <$IN>) {
			chomp $ip;
			if (checkip(\$ip)) {$relayip{$ip} = 1}
		}
		close ($IN);
	}
	if ($config{GLOBAL_DYNDNS} and $config{GLOBAL_DYNDNS_IGNORE}) {
		open (my $IN, "<", "/var/lib/csf/csf.tempgdyn");
		flock ($IN, LOCK_SH);
		while (my $ip = <$IN>) {
			chomp $ip;
			if (checkip(\$ip)) {$relayip{$ip} = 1}
		}
		close ($IN);
	}

	if ($config{RESTRICT_SYSLOG} == 3) {&syslog_perms}
	foreach my $lgfile (keys %logfiles) {
		if ($lgfile eq "") { next }
		my $timer = time;
		if ($config{DEBUG} >= 3) {$timer = &timer("start",$lgfile,$timer)}
		my $totlines = 0;
		my @data;
		while (my $line = &getlogfile($lgfile,$count,$totlines))  {
			if ($line eq "reopen") {
				undef @data;
				last;
			} else {
				$totlines ++;
				push @data, $line;
			}
		}
		if ($config{DEBUG} >= 2) {logfile("debug: Parsing $lgfile ($totlines lines)")}
		foreach my $line ( @data ) {
			if (($lastline ne "") and ($line =~ /^\S+\s+\d+\s+\S+ \S+ last message repeated (\d+) times/)) {
				my $hits = $1;
				if ($hits > 100) {$hits = 100}
				for (my $x = 0;$x <$hits ;$x++) {
					&dochecks($lastline,$lgfile);
				}
			} else {
				&dochecks($line,$lgfile);
				$lastline = $line;
			}
		}
		$lastline = "";
		$count++;
		undef %psips;
		undef %blockedips;
		if ($config{DEBUG} >= 3) {$timer = &timer("stop",$lgfile,$timer)}
	}

	$0 = "lfd - processing";
	if ($config{CT_LIMIT}) {
		$cttimeout+=$duration;
		if ($cttimeout >= $config{CT_INTERVAL}) {
			$cttimeout = 0;
			&connectiontracking;
		}
	}

	if ($config{DYNDNS}) {
		$dyndnstimeout+=$duration;
		if ($dyndnstimeout >= $config{DYNDNS}) {
			$dyndnstimeout = 0;
			&dyndns;
		}
	}

	if ($config{GLOBAL_DYNDNS}) {
		$gdyndnstimeout+=$duration;
		if ($gdyndnstimeout >= $config{GLOBAL_DYNDNS_INTERVAL}) {
			$gdyndnstimeout = 0;
			&globaldyndns;
		}
	}

	if ($config{LF_GLOBAL}) {
		$globaltimeout+=$duration;
		if ($globaltimeout >= $config{LF_GLOBAL}) {
			$globaltimeout = 0;
			&global;
		}
	}

	if (scalar(keys %blocklists)) {
		$blocklisttimeout+=$duration;
		if ($blocklisttimeout >= 300) {
			$blocklisttimeout = 0;
			&blocklist;
		}
	}

	if ($config{CC_DENY} or $config{CC_ALLOW} or $config{CC_ALLOW_FILTER} or $config{CC_ALLOW_PORTS} or $config{CC_DENY_PORTS} or $config{CC_ALLOW_SMTPAUTH}) {
		$cctimeout+=$duration;
		if ($cctimeout >= 3600) {
			$cctimeout = 0;
			&countrycode;
		}
	}

	if ($config{CC_LOOKUPS}) {
		$ccltimeout+=$duration;
		if ($ccltimeout >= 3600) {
			$ccltimeout = 0;
			&countrycodelookups;
		}
	}

	if ($config{LOGSCANNER}) {
		my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime(time);
		my $lastrun;

		if (-e "/var/lib/csf/csf.lastlogrun") {
			my @data = slurp("/var/lib/csf/csf.lastlogrun");
			$loginterval = $lastrun = $data[0];
		}
		if ($loginterval eq "") {
			if ($config{LOGSCANNER_INTERVAL} eq "hourly") {$loginterval = $hour}
			if ($config{LOGSCANNER_INTERVAL} eq "daily") {$loginterval = $mday}
		}
		if (-e "/var/lib/csf/csf.logrun") {
			unlink "/var/lib/csf/csf.logrun";
			&logscanner($hour);
		}
		elsif ($config{LOGSCANNER_INTERVAL} eq "hourly" and $loginterval ne $hour) {
			$loginterval = $hour;
			&logscanner($hour);
		}
		elsif ($config{LOGSCANNER_INTERVAL} eq "daily" and $loginterval ne $mday) {
			$loginterval = $mday;
			&logscanner($hour);
		}

		if ($lastrun ne $loginterval) {
			$lastrun = $loginterval;
			sysopen (my $LOGRUN, "/var/lib/csf/csf.lastlogrun", O_WRONLY | O_CREAT | O_TRUNC);
			flock ($LOGRUN, LOCK_EX);
			print $LOGRUN $loginterval;
			close ($LOGRUN);
		}
	}

	if ($config{LF_INTEGRITY}) {
		$integritytimeout+=$duration;
		if ($integritytimeout >= $config{LF_INTEGRITY}) {
			$integritytimeout = 0;
			&integrity;
		}
	}

	if ($config{LF_QUEUE_ALERT}) {
		$queuetimeout+=$duration;
		if ($queuetimeout >= $config{LF_QUEUE_INTERVAL}) {
			$queuetimeout = 0;
			&queuecheck;
		}
	}

	if ($config{LF_MODSECIPDB_ALERT}) {
		$modsecipdbchecktimeout+=$duration;
		if ($modsecipdbchecktimeout >= 3600) {
			$modsecipdbchecktimeout = 0;
			&modsecipdbcheck;
		}
	}

	if ($config{LF_EXPLOIT}) {
		$exploittimeout+=$duration;
		if ($exploittimeout >= $config{LF_EXPLOIT}) {
			$exploittimeout = 0;
			&exploit;
		}
	}

	if ($config{LF_DIRWATCH}) {
		$dirwatchtimeout+=$duration;
		if (not -e "/var/lib/csf/csf.dwdisable") {
			if ($dirwatchtimeout >= $config{LF_DIRWATCH}) {
				$dirwatchtimeout = 0;
				&dirwatch;
			}
		}
	}

	if ($config{LF_DIRWATCH_FILE}) {
		$dirwatchfiletimeout+=$duration;
		if ($dirwatchfiletimeout >= $config{LF_DIRWATCH_FILE}) {
			&dirwatchfile;
			$dirwatchfiletimeout = 0;
		}
	}

	if ($config{PT_LOAD}) {
		$loadtimeout+=$duration;
		if ($loadtimeout >= $config{PT_LOAD}) {
			$loadtimeout = 0;
			&loadcheck;
		}
	}

	if ($config{PT_LIMIT}) {
		$pttimeout+=$duration;
		if ($pttimeout >= $config{PT_INTERVAL}) {
			$pttimeout = 0;
			&processtracking;
		}
	}

    # #
    #   Messenger
    # #

	if ( $config{MESSENGER} )
	{
		my $messenger_user              = $config{MESSENGER_USER};
		my ( $log_ok, $log_error )      = _prepare_messenger_audit_log( $messenger_user );

		if ( !$log_ok )
		{
			_disable_messenger_services( $log_error );
		}
		else
		{
			_restart_failed_messenger_services( $messenger_user );

			logfile( "DEBUG:2", "info", "[Messenger] Service running sub messengerrecaptcha()" );

			messengerrecaptcha();
		}
	}

	if ($config{UI})
    {
		if ($uiip > 1 and !(kill(0,$uiip))) {
			&ui;
			logfile("Integrated UI Service died, restarted");
		}
	}
	if ($config{CLUSTER_RECVFROM}) {
		if ($clusterip > 1 and !(kill(0,$clusterip))) {
			&lfdserver;
			logfile("Cluster Service died, restarted");
		}
	}

	if ($config{AT_ALERT}) {
		$attimeout+=$duration;
		if ($attimeout >= $config{AT_INTERVAL}) {
			$attimeout = 0;
			undef %newaccounttracking;
			if ($config{AT_ALERT} == 3) {
				my ($user,$passwd,$uid,$gid,$quota,$comment,$gcos,$dir,$shell) = getpwnam("root");
				$newaccounttracking{$user}{account} = 1;
				$newaccounttracking{$user}{passwd} = $passwd;
				$newaccounttracking{$user}{uid} = $uid;
				$newaccounttracking{$user}{gid} = $gid;
				$newaccounttracking{$user}{dir} = $dir;
				$newaccounttracking{$user}{shell} = $shell;
			} else {
				while (my ($user,$passwd,$uid,$gid,$quota,$comment,$gcos,$dir,$shell) = getpwent()) {
					if (($config{AT_ALERT} eq "2") and ($uid ne "0")) { next }
					$newaccounttracking{$user}{account} = 1;
					$newaccounttracking{$user}{passwd} = $passwd;
					$newaccounttracking{$user}{uid} = $uid;
					$newaccounttracking{$user}{gid} = $gid;
					$newaccounttracking{$user}{dir} = $dir;
					$newaccounttracking{$user}{shell} = $shell;
				}
				endpwent();
			}
			&accounttracking;
			%accounttracking = %newaccounttracking;
		}
	}

	if ($config{INTERWORX}) {
		if (slurp("/etc/csf/apf_stub.pl") ne slurp("/etc/apf/apf")) {
			&syscommand(__LINE__,"cp -af /etc/csf/apf_stub.pl /etc/apf/apf");
			&syscommand(__LINE__,"chmod 750 /etc/apf/apf");
			logfile ("InterWorx: Reapplied apf stub");
		}
	}

	&ipunblock;

	$0 = "lfd - sleeping";
	sleep ($config{LF_PARSE});

	$duration = time - $maintimer;
	if (($config{DEBUG} >= 1) and ($duration > ($config{LF_PARSE} * 10))) {
		logfile ("debug: *Performance* log parsing taking $duration seconds");
	}
	if ($config{DEBUG} >= 2) {logfile("debug: Tick: $duration [$config{LF_PARSE}]")}
}

exit;

sub dochecks
{
	my $line 				= shift;
	my $lgfile 				= shift;
	my $timenow 			= time;
	my $logscanner_skip 	= 0;
	my ($reason, $ip, $app, $customtrigger, $customports, $customperm, $customcf) = ConfigServer::RegexMain::processline ($line,$lgfile,\%globlogs);

	my ( $gip, $account, $domain ) = split ( /\|/, $ip, 3 );
	if ( $account !~ /^[a-zA-Z0-9\-\_\.\@\%\+]+$/ )
	{
		if ( $account and $config{DEBUG} >= 1 )
		{
			logfile("debug: (processline) Account name [$account] is invalid");
		}
		$account = "";
	}

	$ip = $gip;
	if ( ( $ip) and ( $ip !~ /^127\./ ) and ( $ip ne "::1" ) )
	{
		if ( &ignoreip( $ip ) )
		{
			logfile( "$reason $ip - ignored" );
		}
		else
		{
			if ( $blockedips{$ip}{block} or ( $blockedips{$ip}{apps} =~ /\b$app\b/ ) )
			{
				if ( $config{DEBUG} >= 1 )
				{
					logfile( "debug: $ip already blocked" )
				}
			}
			else
			{
				if ( ( $app eq "pop3d" or $app eq "imapd" ) and $line =~ /\(auth failed, (\d+) attempts/ )
				{
					$db{$ip}{text} .= "$line\n";
					for ( 1..$1 )
					{
						$db{$ip}{count}++;
						$db{$ip}{apps} .= $app." ";
						$db{$ip}{appscount}{$app}++;
						$db{$ip}{mytime} .= "$timenow,";
						$db{$ip}{appstime}{$app} .= "$timenow,";
						$db{$ip}{domains} .= $domain." ";
					}
				}
				else
				{
					$db{$ip}{count}++;
					$db{$ip}{text} .= "$line\n";
					$db{$ip}{apps} .= $app." ";
					$db{$ip}{appscount}{$app}++;
					$db{$ip}{mytime} .= "$timenow,";
					$db{$ip}{appstime}{$app} .= "$timenow,";
					$db{$ip}{domains} .= $domain." ";
				}

				my $hits;
				my $trigger;
				my $setting;
				my @times;
				if ( $customtrigger )
				{
					$trigger 						= "LF_CUSTOMTRIGGER";
					$config{$trigger} 				= $customtrigger;
					$config{"$trigger\_PERM"} 		= $customperm;
					$ports{$app} 					= $customports;
					$cfblocks{LF_CUSTOMTRIGGER} 	= $customcf;
				}

				if ( $config{LF_TRIGGER} )
				{
					@times 		= split( /\,/,$db{$ip}{mytime} );
					$trigger 	= "LF_TRIGGER";
				}
				else
				{
					@times 	= split( /\,/,$db{$ip}{appstime}{$app} );
					if 		( $app eq "sshd" ) 			{ $trigger = "LF_SSHD" }
					elsif 	( $app eq "pop3d" ) 		{ $trigger = "LF_POP3D" }
					elsif 	( $app eq "imapd" ) 		{ $trigger = "LF_IMAPD" }
					elsif 	( $app eq "ftpd" ) 			{ $trigger = "LF_FTPD" }
					elsif 	( $app eq "smtpauth" ) 		{ $trigger = "LF_SMTPAUTH" }
					elsif 	( $app eq "eximsyntax" ) 	{ $trigger = "LF_EXIMSYNTAX" }
					elsif 	( $app eq "htpasswd" ) 		{ $trigger = "LF_HTACCESS" }
					elsif 	( $app eq "mod_security" ) 	{ $trigger = "LF_MODSEC" }
					elsif 	( $app eq "bind" ) 			{ $trigger = "LF_BIND" }
					elsif 	( $app eq "suhosin" )		{ $trigger = "LF_SUHOSIN" }
					elsif 	( $app eq "cpanel" )		{ $trigger = "LF_CPANEL" }
					elsif 	( $app eq "directadmin" )	{ $trigger = "LF_DIRECTADMIN" }
					elsif 	( $app eq "interworx" )		{ $trigger = "LF_INTERWORX" }
					elsif 	( $app eq "cyberpanel" )	{ $trigger = "LF_CYBERPANEL" }
					elsif 	( $app eq "cwp" ) 			{ $trigger = "LF_CWP" }
					elsif 	( $app eq "vesta" ) 		{ $trigger = "LF_VESTA" }
					elsif 	( $app eq "webmin" ) 		{ $trigger = "LF_WEBMIN" }
					elsif 	( $app eq "whm" ) 			{ $trigger = "LF_CPANEL" }
					elsif 	( $app eq "webmail" ) 		{ $trigger = "LF_CPANEL" }
					elsif 	( $app eq "mod_qos" ) 		{ $trigger = "LF_QOS" }
					elsif 	( $app eq "symlink" ) 		{ $trigger = "LF_SYMLINK" }
					elsif 	( $app eq "cxs" ) 			{ $trigger = "LF_CXS" }
				}

				my $newtimes;
				my $newcnt = 0;
				foreach my $time ( @times )
				{
					if ( $timenow - $time <= $config{LF_INTERVAL} )
					{
						$newtimes .= "$time,";
						$newcnt++;
					}
				}

				if ( $config{LF_TRIGGER} )
				{
					$db{$ip}{count}				= $newcnt;
					$db{$ip}{mytime} 			= $newtimes;
					$hits 						= $db{$ip}{count};
				}
				else
				{
					$db{$ip}{appscount}{$app} 	= $newcnt;
					$db{$ip}{appstime}{$app} 	= $newtimes;
					$hits 						= $db{$ip}{appscount}{$app};
				}

				if ( $config{DEBUG} >= 1 )
				{
					logfile( "debug: $reason $ip - $hits failure(s) in the last $config{LF_INTERVAL} secs" )
				}

				if ( $hits >= $config{$trigger} )
				{
					my @text 		= split(/\n/,$db{$ip}{text});
					$db{$ip}{text} 	= "";
					for ( -$hits..-1 )
					{
						$db{$ip}{text} .= "$text[$_]\n"
					}

					$0 = "lfd - blocking $ip";
					&block( $ip, $hits, $app, $config{"$trigger\_PERM"}, $trigger, $reason );
					if ( $config{LF_SELECT} and !$config{LF_TRIGGER} )
					{
						$db{$ip}{appscount}{$app} 	= 0;
						$db{$ip}{appstime}{$app} 	= "";
					}
					else
					{
						delete $db{$ip};
					}

					if ( $cxsreputation )
					{
						ConfigServer::cxs::Rreport( $trigger, $ip, "$reason $ip - $hits failure(s) in the last $config{LF_INTERVAL} secs", $trigger );
					}
			
					$0 = "lfd - scanning $lgfile";
				}

				if ( $config{LF_DISTATTACK} and $account )
				{
					$adb{$app}{$account}{$timenow}{ip} .= "$ip,";
					$adb{$app}{$account}{$timenow}{text} .= "$line\n";

					my @accountips;
					my $text;
					foreach my $key (keys %{$adb{$app}{$account}}) {
						if ($timenow - $key <= $config{LF_INTERVAL}) {
							push @accountips, (split(/\,/,$adb{$app}{$account}{$key}{ip}));
							$text .= $adb{$app}{$account}{$key}{text};
						} else {
							delete $adb{$app}{$account}{$key};
						}
					}
					my %seen;
					my @uniqueips = grep { ! $seen{ $_ }++ } @accountips;
					if ($config{DEBUG} >= 1) {logfile("debug: $reason ".@uniqueips." ip(s) to account [$account] ".@accountips." in the last $config{LF_INTERVAL} secs")}
					if ((@accountips >= $config{$trigger}) and (@uniqueips >= $config{LF_DISTATTACK_UNIQ})) {
						delete $adb{$app}{$account};
						&blockaccount(\@uniqueips,$account,$#accountips+1,$app,$text,$config{"$trigger\_PERM"},$trigger);
					}
				}
			}
		}
	}

	if ($config{LF_DISTFTP} and ($globlogs{FTPD_LOG}{$lgfile})) {
		my ($ip, $account) = ConfigServer::RegexMain::processdistftpline ($line);
		unless ($account =~ /^[a-zA-Z0-9\-\_\.\@\%\+]+$/) {
			if ($account and $config{DEBUG} >= 1) {logfile("debug: (processdistftpline) Account name [$account] is invalid")}
			$account = "";
		}
		if ($ip and $account and ($ip !~ /^127\./) and ($ip ne "::1")) {
			if (&ignoreip($ip)) {
				if ($config{DEBUG} >= 1) {logfile("debug: Distributed FTP $ip - ignored")}
			} else {
				$adf{$account}{$timenow}{ip} .= "$ip,";
				$adf{$account}{$timenow}{text} .= "$line\n";
				my @accountips;
				my $text;
				foreach my $key (keys %{$adf{$account}}) {
					if ($timenow - $key <= $config{LF_DIST_INTERVAL}) {
						push @accountips, (split(/\,/,$adf{$account}{$key}{ip}));
						$text .= $adf{$account}{$key}{text};
					} else {
						delete $adf{$account}{$key};
					}
				}
				my %seen;
				my @uniqueips = grep { ! $seen{ $_ }++ } @accountips;
				if ($config{DEBUG} >= 1) {logfile("debug: FTP logins from ".@uniqueips." ip(s) to account [$account] ".@accountips." in the last $config{LF_INTERVAL} secs")}
				if ((@accountips >= $config{LF_DISTFTP}) and (@uniqueips >= $config{LF_DISTFTP_UNIQ})) {
					delete $adf{$account};
					&blockdistftp(\@uniqueips,$account,$#accountips+1,$text,$config{LF_DISTFTP_PERM});
				}
			}
		}
	}

	if ($config{LF_DISTSMTP} and ($globlogs{SMTPAUTH_LOG}{$lgfile})) {
		my ($ip, $account) = ConfigServer::RegexMain::processdistsmtpline ($line);
		unless ($account =~ /^[a-zA-Z0-9\-\_\.\@\%\+]+$/) {
			if ($account and $config{DEBUG} >= 1) {logfile("debug: (processdistsmtpline) Account name [$account] is invalid")}
			$account = "";
		}
		if ($ip and $account and ($ip !~ /^127\./) and ($ip ne "::1")) {
			if (&ignoreip($ip)) {
				if ($config{DEBUG} >= 1) {logfile("debug: Distributed SMTP $ip - ignored")}
			} else {
				$ads{$account}{$timenow}{ip} .= "$ip,";
				$ads{$account}{$timenow}{text} .= "$line\n";
				my @accountips;
				my $text;
				foreach my $key (keys %{$ads{$account}}) {
					if ($timenow - $key <= $config{LF_DIST_INTERVAL}) {
						push @accountips, (split(/\,/,$ads{$account}{$key}{ip}));
						$text .= $ads{$account}{$key}{text};
					} else {
						delete $ads{$account}{$key};
					}
				}
				my %seen;
				my @uniqueips = grep { ! $seen{ $_ }++ } @accountips;
				if ($config{DEBUG} >= 1) {logfile("debug: SMTP logins from ".@uniqueips." ip(s) to account [$account] ".@accountips." in the last $config{LF_INTERVAL} secs")}
				if ((@accountips >= $config{LF_DISTSMTP}) and (@uniqueips >= $config{LF_DISTSMTP_UNIQ})) {
					delete $ads{$account};
					&blockdistsmtp(\@uniqueips,$account,$#accountips+1,$text,$config{LF_DISTSMTP_PERM});
				}
			}
		}
	}

	if ($config{LF_APACHE_404} and ($globlogs{HTACCESS_LOG}{$lgfile})) {
		my ($ip) = ConfigServer::RegexMain::loginline404($line);
		if ($ip and !&ignoreip($ip)) {
			$apache404{$ip}{count}++;
			$apache404{$ip}{text} .= "$line\n";
			if ($apache404{$ip}{count} > $config{LF_APACHE_404}) {
				&disable404($ip,$apache404{$ip}{text});
				delete $apache404{$ip};
			}
		}
	}

	if ($config{LF_APACHE_403} and ($globlogs{HTACCESS_LOG}{$lgfile})) {
		my ($ip) = ConfigServer::RegexMain::loginline403($line);
		if ($ip and !&ignoreip($ip)) {
			$apache403{$ip}{count}++;
			$apache403{$ip}{text} .= "$line\n";
			if ($apache403{$ip}{count} > $config{LF_APACHE_403}) {
				&disable403($ip,$apache403{$ip}{text});
				delete $apache403{$ip};
			}
		}
	}

	if ($config{LF_APACHE_401} and ($globlogs{HTACCESS_LOG}{$lgfile})) {
		my ($ip) = ConfigServer::RegexMain::loginline401($line);
		if ($ip and !&ignoreip($ip)) {
			$apache401{$ip}{count}++;
			$apache401{$ip}{text} .= "$line\n";
			if ($apache401{$ip}{count} > $config{LF_APACHE_401}) {
				&disable401($ip,$apache401{$ip}{text});
				delete $apache401{$ip};
			}
		}
	}

	if (($config{LT_POP3D} or $config{LT_IMAPD}) and (($globlogs{POP3D_LOG}{$lgfile}) or ($globlogs{IMAPD_LOG}{$lgfile}))) {
		my ($app, $account, $ip) = ConfigServer::RegexMain::processloginline ($line);
		unless ($account =~ /^[a-zA-Z0-9\-\_\.\@\%\+]+$/) {
			if ($account and $config{DEBUG} >= 1) {logfile("debug: (processloginline) Account name [$account] is invalid")}
			$account = "";
		}
		if ($account and $loginproto{$app} and !&ignoreip($ip,1)) {
			$logins{$app}{$account}{$ip}++;
			if ($account and $config{DEBUG} >= 1) {logfile("debug: (processloginline) Account name [$account] [$ip] [$logins{$app}{$account}{$ip}]")}
			if ($logins{$app}{$account}{$ip} > $loginproto{$app}) {
				$0 = "lfd - disabling $app logins for $account";
				&logindisable($app,$ip,$logins{$app}{$account}{$ip},$account);
				delete $logins{$app}{$account}{$ip};
				$0 = "lfd - scanning $lgfile";
			}
		}
	}

	if ($config{LF_SSH_EMAIL_ALERT} and (($lgfile eq "/var/log/messages") or ($lgfile eq "/var/log/secure") or ($lgfile eq "/var/log/auth.log") or ($globlogs{SSHD_LOG}{$lgfile}))) {
		my ($account, $ip, $method) = ConfigServer::RegexMain::processsshline ($line);
		unless ($account =~ /^[a-zA-Z0-9\-\_\.\@\%\+]+$/) {
			if ($account and $config{DEBUG} >= 1) {logfile("debug: (processsshline) Account name [$account] is invalid")}
			$account = "";
		}
		if ($account and $ip and !&ignoreip($ip)) {
			&sshalert($account, $ip, $method, $line);
		}
		elsif (&ignoreip($ip)) {logfile("*SSH login* from $ip into the $account account using $method authentication - ignored")}
	}

	if ($config{LF_SU_EMAIL_ALERT} and (($lgfile eq "/var/log/messages") or ($lgfile eq "/var/log/secure") or ($lgfile eq "/var/log/auth.log") or ($globlogs{SU_LOG}{$lgfile}))) {
		my ($to, $from, $status) = ConfigServer::RegexMain::processsuline ($line);
		if (($to and $from) and ($from ne "root") and ($from ne 'root(uid=0)') and ($from ne '(uid=0)')) {
			&sualert($to, $from, $status, $line);
		}
	}

	if ($config{LF_SUDO_EMAIL_ALERT} and (($lgfile eq "/var/log/messages") or ($lgfile eq "/var/log/secure") or ($lgfile eq "/var/log/auth.log") or ($globlogs{SUDO_LOG}{$lgfile}))) {
		my ($to, $from, $status) = ConfigServer::RegexMain::processsudoline ($line);
		if (($to and $from) and ($from ne "root") and ($from ne 'root(uid=0)') and ($from ne '(uid=0)')) {
			&sudoalert($to, $from, $status, $line);
		}
	}

	if ($config{LF_CONSOLE_EMAIL_ALERT} and (($lgfile eq "/var/log/messages") or ($lgfile eq "/var/log/secure") or ($lgfile eq "/var/log/auth.log") or ($globlogs{SU_LOG}{$lgfile}))) {
		my ($status) = ConfigServer::RegexMain::processconsoleline ($line);
		if ($status) {
			&consolealert($line);
		}
	}

	if ($config{LF_CPANEL_ALERT} and ($globlogs{CPANEL_ACCESSLOG}{$lgfile})) {
		my ($ip,$user) = ConfigServer::RegexMain::processcpanelline ($line);
		unless ($user =~ /^[a-zA-Z0-9\-\_\.\@\%\+]+$/) {
			if ($user and $config{DEBUG} >= 1) {logfile("debug: (processcpanelline) Account name [$user] is invalid")}
			$user = "";
		}
		if ($ip and !&ignoreip($ip) and $user and ($cpanelalertusers{$user} or $cpanelalertusers{all})) {
			if ($cpanelalert{$ip}{$user} and (time - $cpanelalert{$ip}{$user} < 3600)) {
				$cpanelalert{$ip}{$user} = time;
			} else {
				$cpanelalert{$ip}{$user} = time;
				&cpanelalert($ip,$user, $line);
			}
		}
	}

	if ($config{LF_WEBMIN_EMAIL_ALERT} and ($globlogs{WEBMIN_LOG}{$lgfile})) {
		my ($account, $ip) = ConfigServer::RegexMain::processwebminline ($line);
		if ($account) {
			&webminalert($account,$ip, $line);
		}
	}

	if ($config{LF_SCRIPT_ALERT} and ($globlogs{SCRIPT_LOG}{$lgfile})) {
		my $path = ConfigServer::RegexMain::scriptlinecheck($line);
		if ($path ne "") {
			$scripts{$path}{cnt}++;
			if ($scripts{$path}{cnt} <= 10) {
				$scripts{$path}{mails} .= "$line\n";
			}
			if ($scripts{$path}{cnt} > $config{LF_SCRIPT_LIMIT}) {
				&scriptalert($path,$scripts{$path}{cnt},$scripts{$path}{mails});
				delete $scripts{$path};
			}
		}
	}

	if ($config{PS_INTERVAL} and ($globlogs{IPTABLES_LOG}{$lgfile})) {
		my ($ip, $port) = ConfigServer::RegexMain::pslinecheck($line);
		if ($port and $ip and !&ignoreip($ip)) {
			my $hit = 0;
			foreach my $ports (split(/\,/,$config{PS_PORTS})) {
				if ($ports =~ /\:/) {
					my ($start,$end) = split(/\:/,$ports);
					if ($port >= $start and $port <= $end) {$hit = 1}
				}
				elsif ($port == $ports) {$hit = 1}
				if ($hit) {last}
			}
			if ($hit) {
				$portscans{$ip}{count}++;
				$portscans{$ip}{blocks} .= "$line\n";
				$portscans{$ip}{ports}{$port} = 1;
				if ($portscans{$ip}{count} > $config{PS_LIMIT}) {
					if ($config{PS_DIVERSITY} > 1 and ($config{PS_DIVERSITY} > scalar (keys %{$portscans{$ip}{ports}}))) {
						if ($config{DEBUG} >= 1) {logfile("debug: *Port Scan* detected from $ip - but denied by PS_DIVERSITY")}
					} else {
						if ($psips{$ip}) {
							if ($config{DEBUG} >= 1) {logfile("debug: *Port Scan* detected from $ip - already blocked")}
							delete $portscans{$ip};
						} else {
							&portscans($ip,$portscans{$ip}{count},$portscans{$ip}{blocks});
							$psips{$ip} = 1;
							delete $portscans{$ip};
						}
					}
				}
			}
		}
		elsif (($config{DEBUG} >= 1) and $port and $ip and &ignoreip($ip)) {
			logfile("debug: PS count for $ip - ignored");
		}
	}

	if ($config{UID_INTERVAL} and ($globlogs{IPTABLES_LOG}{$lgfile})) {
		my ($port, $uid) = ConfigServer::RegexMain::uidlinecheck($line);
		if ($port and $uid and !$uidignore{$uid}) {
			my $hit = 0;
			foreach my $ports (split(/\,/,$config{UID_PORTS})) {
				if ($ports =~ /\:/) {
					my ($start,$end) = split(/\:/,$ports);
					if ($port >= $start and $port <= $end) {$hit = 1}
				}
				elsif ($port == $ports) {$hit = 1}
				if ($hit) {last}
			}
			if ($hit) {
				$uidscans{$uid}{count}++;
				$uidscans{$uid}{blocks} .= "$line\n";
				if ($uidscans{$uid}{count} > $config{UID_LIMIT}) {
					&uidscans($uid,$uidscans{$uid}{count},$uidscans{$uid}{blocks});
					delete $uidscans{$uid};
				}
			}
		}
		elsif (($config{DEBUG} >= 1) and $port and $uid and $uidignore{$uid}) {
			logfile("debug: UID count for $uid - ignored");
		}
	}

	if ($config{ST_ENABLE} and ($globlogs{IPTABLES_LOG}{$lgfile})) {
		if (ConfigServer::RegexMain::statscheck($line)) {
			&stats($line,"iptables");
		}
	}

	if ($config{SYSLOG_CHECK} and $sys_syslog and $syslogcheckcode and ($globlogs{SYSLOG_LOG}{$lgfile})) {
		if (ConfigServer::RegexMain::syslogcheckline($line,$syslogcheckcode)) {
			if ($config{DEBUG} >= 2) {logfile("debug: SYSLOG_CHECK match [$syslogcheckcode]")}
			$syslogcheckcode = "";
			$logscanner_skip = 1;
		}
	}

	if ($config{PORTKNOCKING} and $config{PORTKNOCKING_ALERT} and ($globlogs{IPTABLES_LOG}{$lgfile})) {
		my ($ip, $port) = ConfigServer::RegexMain::portknockingcheck($line);
		if ($port and $ip and !&ignoreip($ip)) {
			&portknocking($ip, $port);
		}
	}

	if ($config{LOGSCANNER} and $logscannerfiles{$lgfile} and !$logscanner_skip) {
		my $hit = 1;
		foreach my $regex (@logignore) {
			if ($line =~ /$regex/) {
				$hit = 0;
				last;
			}
		}
		if ($hit) {
			unless (-e "/var/lib/csf/csf.logmax") {
				sysopen (my $LOGTEMP,"/var/lib/csf/csf.logtemp", O_RDWR | O_CREAT);
				flock ($LOGTEMP, LOCK_EX);
				my @data = <$LOGTEMP>;
				close ($LOGTEMP);
				if (@data > $config{LOGSCANNER_LINES}) {
					open (my $OUT,">","/var/lib/csf/csf.logmax");
					close ($OUT);
				} else {
					sysopen (my $LOGTEMP,"/var/lib/csf/csf.logtemp", O_WRONLY | O_APPEND | O_CREAT);
					flock ($LOGTEMP, LOCK_EX);
					print $LOGTEMP "$lgfile|$line\n";
					close ($LOGTEMP);
				}
			}
		}
	}

	if ((($config{RT_RELAY_ALERT} or $config{RT_AUTHRELAY_ALERT} or $config{RT_POPRELAY_ALERT} or $config{RT_LOCALRELAY_ALERT} or $config{RT_LOCALHOSTRELAY_ALERT})) and ($globlogs{SMTPRELAY_LOG}{$lgfile})) {
		my ($ip,$check) = ConfigServer::RegexMain::relaycheck($line);
		if ($ip) {
			if ($check eq "RELAY" and !$relays{$ip}{check}) {
				open (my $RELAYHOSTS, "<", "/etc/relayhosts");
				flock ($RELAYHOSTS, LOCK_SH);
				my @relayhosts = <$RELAYHOSTS>;
				close ($RELAYHOSTS);
				chomp @relayhosts;
				if (grep {$_ =~ /^$ip$/} @relayhosts) {$check = "POPRELAY"}

				open (my $ALWAYSRELAY, "<", "/etc/alwaysrelay");
				flock ($ALWAYSRELAY, LOCK_SH);
				@relayhosts = <$ALWAYSRELAY>;
				close ($ALWAYSRELAY);
				chomp @relayhosts;
				if (grep {$_ =~ /^$ip$/} @relayhosts) {$check = "POPRELAY"}
			}
			if ($ips{$ip} or $ipscidr->find($ip) or $ipscidr6->find($ip)) {$check = "LOCALHOSTRELAY"}
			if ($config{ST_SYSTEM}) {
				sysopen (my $EMAIL, "/var/lib/csf/stats/email", O_RDWR | O_CREAT);
				flock ($EMAIL, LOCK_EX);
				my $stats = <$EMAIL>;
				chomp $stats;
				my ($sent,$recv) = split(/\:/,$stats);
				if ($check eq "RELAY") {$recv++} else {$sent++}
				seek ($EMAIL, 0, 0);
				truncate ($EMAIL, 0);
				print $EMAIL "$sent:$recv";
				close ($EMAIL);
			}
		}
		if ($ip and ($ip ne "mailnull") and ($ip ne "root") and (!$rtignore{$ip})) {
			my $tline = $line;
			$tline =~ s/".*"/""/g;
			my $start = 0;
			my $cnt = 0;
			foreach my $item (split(/\s+/,$tline)) {
					if ($item eq "for") {$start = 1 ; next}
					if ($start and ($item =~ /\@/)) {$cnt++} else {$start = 0}
			}
			if ($cnt > 0) {
				$relays{$ip}{cnt}+=$cnt;
			} else {
				$relays{$ip}{cnt}++;
			}
			if ($config{DEBUG} >= 1) {logfile("debug: RT\_$check\_LIMIT detected from $ip, count = $relays{$ip}{cnt}")}

			unless ($relays{$ip}{check}) {$relays{$ip}{check} = $check}

			my $mailcnt = 0;
			foreach my $mail (split(/\n/,$relays{$ip}{mails})) {$mailcnt++}
			if ($mailcnt < 10) {
				$relays{$ip}{mails} .= "$line\n";
			}

			if (($relays{$ip}{cnt} > $config{"RT\_$check\_LIMIT"}) and ($config{"RT\_$check\_ALERT"})) {
				if (($check eq "LOCALHOSTRELAY") or (!&ignoreip($ip))) {
					&relayalert($ip,$relays{$ip}{cnt},$relays{$ip}{check},$relays{$ip}{mails});
					delete $relays{$ip};
				}
			}
		}
		elsif (($config{DEBUG} >= 1) and $ip and $rtignore{$ip}) {
			logfile("debug: RT\_$check\_LIMIT detected from $ip - ignored");
		}
	}
	return;
}
# end dochecks
###############################################################################
# start getlogfile
sub getlogfile {
	my $logfile = shift;
	my $lfn = shift;
	my $totlines = shift;
    my $ino;
	my $size;
    my $line;
	my $count;

    if (!defined($lffd[$lfn]))  {
		if (&openlogfile($logfile,$lfn)) {return undef}
    }

    (undef, $ino, undef, undef, undef, undef, undef, $size, undef) = stat($logfile);

    if ($ino != $lfino[$lfn])  {
		logfile("$logfile rotated. Reopening log file");
		if (&openlogfile($logfile,$lfn)) {return undef}
	    return "reopen";
    }

	if ($size < $lfsize[$lfn])  {
		logfile("$logfile has been reset. Reopening log file");
		if (&openlogfile($logfile,$lfn)) {return undef}
	    return "reopen";
    }

	$lffd[$lfn]->clearerr();
	$line = readline($lffd[$lfn]);

	if ($totlines > ($config{LF_PARSE} * 1000)) {
		my $text = "*Error* Log line flooding/looping in $logfile. Reopening log file";
		logfile("$text");
		if ($config{LOGFLOOD_ALERT}) {
			my @alert = slurp("/usr/local/csf/tpl/logfloodalert.txt");
			my @message;
			foreach my $line (@alert) {
				$line =~ s/\[text\]/$text/ig;
				push @message, $line;
			}
			ConfigServer::Sendmail::relay("", "", @message);
		}
		if (&openlogfile($logfile,$lfn)) {return undef}
	    return "reopen";
	}
	
	chomp $line;
    if ($line)  {
		$lfsize[$lfn] = $size;
		return $line;
    }

    return undef;
}
# end getlogfile
###############################################################################
# start openlogfile
sub openlogfile {
	my $logfile = shift;
	my $lfn = shift;

    if (defined($lffd[$lfn]))  {
		close($lffd[$lfn]);
		delete($lffd[$lfn]);
	}

	sysopen ($lffd[$lfn], $logfile, O_RDONLY | O_NONBLOCK);
	if (!defined($lffd[$lfn]))  {
		logfile("*Error* Cannot open $logfile");
		return 1;
	}
	if (seek($lffd[$lfn], 0, 2) == -1)  {
		logfile("*Error* Cannot seek to end of $logfile");
		return 1;
	}

	logfile("Watching $logfile...");
	(undef, $lfino[$lfn], undef, undef, undef, undef, undef, $lfsize[$lfn], undef) = stat($lffd[$lfn]);

	return 0;
}

sub globlog
{
	my $setting = shift;
	if ( $config{$setting} =~ /\*|\?|\[/ )
	{
		foreach my $log ( glob $config{$setting} )
		{
			$globlogs{$setting}{$log} 			= 1;
			$logfiles{$log} 					= 1;
		}
	}
	else
	{
		$globlogs{$setting}{$config{$setting}} 	= 1;
		$logfiles{$config{$setting}} 			= 1;
	}

	return;
}
# end globlog
###############################################################################
# start lockhang
sub lockhang {
	$SIG{CHLD} = 'IGNORE';
	unless (defined ($childpid = fork)) {
		&shutdown(__LINE__,"*Error* cannot fork: $!");
	} 
	$forks{$childpid} = 1;
	unless ($childpid) {
		my $timer = time;
		if ($config{DEBUG} >= 3) {$timer = &timer("start","lockhang",$timer)}
		$0 = "lfd - (child) checking for lock hang";

		eval {
			local $SIG{__DIE__} = undef;
			local $SIG{'ALRM'} = sub {die};
			alarm(10);
			sysopen (my $COMMANDLOCK, "/var/lib/csf/lock/command.lock", O_RDWR | O_CREAT) or logfile("open: $!");
			flock ($COMMANDLOCK, LOCK_EX) or logfile("lock: $!");
			close ($COMMANDLOCK);
			alarm(0);
		};
		alarm(0);
		if ($@) {
			sysopen (my $COMMANDLOCK, "/var/lib/csf/lock/command.lock", O_RDWR | O_CREAT);
			flock ($COMMANDLOCK, LOCK_SH);
			my $pid = <$COMMANDLOCK>;
			chomp $pid;
			close ($COMMANDLOCK);
			if ($pid == $$) {
				logfile("*Hanging Lock* by main lfd process found for /var/lib/csf/lock/command.lock - restarting lfd");
				open (my $LFDOUT, ">", "/var/lib/csf/lfd.restart");
				close ($LFDOUT);
			} else {
				kill (9, $pid);
				logfile("*Hanging Lock* by $pid found for /var/lib/csf/lock/command.lock - terminated");
			}
		}

		if ($config{DEBUG} >= 3) {$timer = &timer("stop","lockhang",$timer)}
		$0 = "lfd - child closing";
		exit;
	}
	return;
}
# end lockhang
###############################################################################
# start syslog_init
sub syslog_init {
	local $SIG{CHLD} = 'DEFAULT';
	my %syslogusers;
	my @entries = slurp("/etc/csf/csf.syslogusers");
	foreach my $line ( @entries ) {
		if ( $line =~ /^Include\s*(.*)$/ ) {
			my @incfile = slurp( $1 );
			push @entries, @incfile;
		}
	}
	foreach my $line ( @entries ) {
		$line =~ s/$cleanreg//g;
		if ( $line eq "" ) { next }
		if ( $line =~ /^\s*\#|Include/ ) { next }
		# Allow a leading underscore (Debian/Ubuntu system users such as _apt, _chrony)
		if ($line =~ /^[a-zA-Z0-9_][a-zA-Z0-9_.\-]*\$?$/) {$syslogusers{$line} = 1}
		else {logfile("RESTRICT_SYSLOG: Ignoring invalid username [$line] in /etc/csf/csf.syslogusers")}
	}

	$sysloggid = getgrnam($config{RESTRICT_SYSLOG_GROUP});
	unless ($sysloggid) {&syscommand(__LINE__,"/usr/sbin/groupadd","-r",$config{RESTRICT_SYSLOG_GROUP})}
	$sysloggid = getgrnam($config{RESTRICT_SYSLOG_GROUP});
	unless ($sysloggid) {
		logfile("RESTRICT_SYSLOG: *Error* Failed to create group: [$config{RESTRICT_SYSLOG_GROUP}], RESTRICT_SYSLOG disabled");
		$config{RESTRICT_SYSLOG} = 0;
		return;
	}

	my (undef,undef,$gid,$members) = getgrgid($sysloggid);
	foreach my $name (split(/\s+/,$members)) {$syslogusers{$name} = 0}
	foreach my $name (keys %syslogusers) {
		if ($syslogusers{$name} and getpwnam($name) ne "") {
			&syscommand(__LINE__,"/usr/sbin/usermod","-a","-G",$config{RESTRICT_SYSLOG_GROUP},$name);
			if ($config{DEBUG} >= 1) {logfile("debug: RESTRICT_SYSLOG: User $name added to group $config{RESTRICT_SYSLOG_GROUP}")}
		}
	}
	return;
}
# end syslog_init
###############################################################################
# start syslog_perms
sub syslog_perms {
	my $newpid = 1;
	my @socketids;
	my @sockets;
	if (-S "/dev/log") {push @sockets, "/dev/log"}
	if (-S "/usr/share/cagefs-skeleton/dev/log") {push @sockets, "/usr/share/cagefs-skeleton/dev/log"}

	if ($syslogpid) {
		if (readlink("/proc/$syslogpid/exe") =~ m[^(/sbin/syslog)|(/sbin/rsyslog)|(/usr/sbin/syslog)|(/usr/sbin/rsyslog)]) {$newpid = 0}
	}

	if ($newpid) {
		opendir (PROCDIR, "/proc");
		while (my $pid = readdir(PROCDIR)) {
			if ($pid !~ /^\d+$/) { next }
			my $exe = readlink("/proc/$pid/exe");
			if ($exe =~ m[^(/sbin/syslog)|(/sbin/rsyslog)|(/usr/sbin/syslog)|(/usr/sbin/rsyslog)]) {
				$syslogpid = $pid;
				last;
			}
		}
		closedir (PROCDIR);
	}

	if ($syslogpid) {
		opendir (DIR, "/proc/$syslogpid/fd/");
		while (my $file = readdir(DIR)) {
			if (readlink("/proc/$syslogpid/fd/$file") =~/^socket:\[(\d*)\]$/) {push @socketids,$1}
		}
		closedir (DIR);
		if (@socketids) {
			open (my $IN, "<", "/proc/net/unix");
			flock ($IN, LOCK_SH);
			while (my $line = <$IN>) {
				chomp $line;
				my @data = split(/\s+/,$line,8);
				foreach my $socket (@socketids) {
					if (($socket == $data[6]) and ($data[7] ne "/dev/log") and ($data[7] ne "/usr/share/cagefs-skeleton/dev/log")) {push @sockets,$data[7]}
				}
			}
			close ($IN);
		} else {
			if ($config{DEBUG} >= 2) {logfile("debug: RESTRICT_SYSLOG: *Error* No additional unix sockets found")}
		}
	} else {
		if ($config{DEBUG} >= 1) {logfile("debug: RESTRICT_SYSLOG: *Error* syslog/rsyslog process not found")}
	}

	if (@sockets) {
		my $fixme = 0;
		foreach my $socket (@sockets) {
			if (-S $socket) {
				my (undef,undef,$mode,undef,$uid,$gid,undef) = stat($socket);
				$mode = sprintf("%04o",$mode & oct("07777"));
				if ($gid != $sysloggid or $mode ne "0660") {
					$fixme = 1;
					last;
				}
			}
		}
		if ($fixme) {
			chown (-1,$sysloggid,@sockets);
			chmod (0660, @sockets);
			my $count = 0;
			logfile("RESTRICT_SYSLOG: Unix socket permissions reapplied. Reopening log files...");
			foreach my $lgfile (keys %logfiles) {
				&openlogfile($lgfile,$count);
				$count++;
			}
			if ($config{DEBUG} >= 1) {logfile("debug: RESTRICT_SYSLOG: Fixed socket ownership/permissions")}
		}
	} else {
			logfile("RESTRICT_SYSLOG: *Error* No matching unix sockets found");
			return;
	}
	return;
}
# end syslog_perms
###############################################################################
# start block
sub block {
	my $ip = shift;
	my $ipcount = shift;
	my $app = shift;
	my $temp = shift;
	my $active = shift;
	my $reason = shift;
	my $ipc = $ipcount;

	my $text = $db{$ip}{text};
	my $apps = $db{$ip}{apps};
	my $domains = $db{$ip}{domains};
	unless ($config{LF_TRIGGER}) {$apps = $app}

	$blockedips{$ip}{block} = 1;
	$blockedips{$ip}{apps} .= "$app\,";
	$text =~ s/\n+/\n/g;

	$SIG{CHLD} = 'IGNORE';
	unless (defined ($childpid = fork)) {
		&shutdown(__LINE__,"*Error* cannot fork: $!");
	} 
	$forks{$childpid} = 1;
	unless ($childpid) {
		my $timer = time;
		if ($config{DEBUG} >= 3) {$timer = &timer("start","block",$timer)}
		my %logapps;
		my $apptext;
		foreach my $app (split(/ /,$apps)) {$logapps{$app} = 1}
		foreach my $key (keys %logapps) {
			if ($apptext eq "") {$apptext = $key} else {$apptext .= ",$key"}
		}
		my $perm = 1;
		if ($temp > 1) {$perm = 0}

		$0 = "lfd - (child) blocking $ip";

		my $tip = iplookup($ip);
		my $failtext = "Login failure/trigger from";
		if (keys %logapps == 1) {$failtext = $reason}

		my $cfid;
		if ($config{CF_ENABLE} and $cfblocks{$active}) {
			$perm = 0;
			$temp = $config{CF_TEMP};
			&cloudflare("deny",$ip,$config{CF_BLOCK},$domains);
			$cfid = " (CF_ENABLE)";
		}
		if ($config{PT_SSHDKILL} and $logapps{sshd}) {ConfigServer::KillSSH::find($ip,$ports{sshd})}

		my $blocked = 0;
		if ($config{LF_SELECT} and !$config{LF_TRIGGER}) {
			if (&ipblock($perm,"($apptext) $failtext $tip: $ipcount in the last $config{LF_INTERVAL} secs$cfid",$ip,$ports{$app},"in",$temp,0,$text,$active)) {
				if ($config{DEBUG} >= 1) {logfile("debug: $ip already blocked")}
			} else {$blocked = 1}
		} else {
			if (&ipblock($perm,"($apptext) $failtext $tip: $ipcount in the last $config{LF_INTERVAL} secs$cfid",$ip,"","inout",$temp,0,$text,$active)) {
				if ($config{DEBUG} >= 1) {logfile("debug: $ip already blocked")}
			} else {$blocked = 1}
		}

		if ($blocked) {
			if ($config{LF_EMAIL_ALERT} and ($perm or (!$perm and $config{LF_TEMP_EMAIL_ALERT}))) {
				$0 = "lfd - (child) sending alert email for $ip";

				my @alert = slurp("/usr/local/csf/tpl/alert.txt");
				my $block = "Temporary Block for $temp seconds [$active]";
				if ($perm) {$block = "Permanent Block [$active]"}

				my $allowip = &allowip($ip);
				if ($allowip == 1) {$block .= " (IP match in csf.allow, block may not work)"}
				if ($allowip == 2) {$block .= " (IP match in GLOBAL_ALLOW, block may not work)"}

				my @message;
				foreach my $line (@alert) {
					$line =~ s/\[ip\]/$tip/ig;
					$line =~ s/\[ipcount\]/$ipcount \($apptext\)/ig;
					$line =~ s/\[iptick\]/$config{LF_INTERVAL}/ig;
					$line =~ s/\[block\]/$block/ig;
					$line =~ s/\[text\]/$text/ig;
					push @message, $line;
				}
				ConfigServer::Sendmail::relay("", "", @message);

				if ($config{DEBUG} >= 1) {logfile("debug: alert email sent for $ip")}
			}

			if ($config{X_ARF}) {
				$0 = "lfd - (child) sending X-ARF email for $ip";

				my @alert = slurp("/usr/local/csf/tpl/x-arf.txt");
				my @message;
				my $rfc3339 = strftime('%Y-%m-%dT%H:%M:%S%z',localtime);
				my $boundary = time;
				my $reportedfrom = "root\@$hostname";
				if ($config{X_ARF_TO}) {$config{LF_ALERT_TO} = $config{X_ARF_TO}}
				if ($config{X_ARF_FROM}) {$config{LF_ALERT_FROM} = $config{X_ARF_FROM}; $reportedfrom = $config{X_ARF_FROM}}
				my $iptype = "ipv".checkip(\$ip);
				my $abuseto = "";
				my $abusemsg = "";

				if ($abuseip) {
					($abuseto, $abusemsg) = abuseip($ip);
					if ($abuseto eq "") {
						$abusemsg = "";
					}
					elsif ($config{X_ARF_ABUSE} and $config{X_ARF_FROM}) {
						if ($config{LF_ALERT_TO}) {
							$config{LF_ALERT_TO} .= ",".$abuseto;
						} else {
							$config{LF_ALERT_TO} = "root,".$abuseto;
						}
					}
				}

				foreach my $line (@alert) {
					$line =~ s/\[ip\]/$ip/ig;
					$line =~ s/\[abuseip\]/$abusemsg/ig;
					$line =~ s/\[iptype\]/$iptype/ig;
					$line =~ s/\[tip\]/$tip/ig;
					$line =~ s/\[ipcount\]/$ipc/ig;
					$line =~ s/\[iptick\]/$config{LF_INTERVAL}/ig;
					$line =~ s/\[service\]/$app/ig;
					$line =~ s/\[csfversion\]/$version/ig;
					$line =~ s/\[reportedfrom\]/$reportedfrom/ig;
					$line =~ s/\[reportedid\]/$boundary\@$hostname/ig;
					$line =~ s/\[boundary\]/$boundary/ig;
					$line =~ s/\[text\]/$text/ig;
					$line =~ s/\[RFC3339\]/$rfc3339/ig;
					push @message, $line;
				}
				ConfigServer::Sendmail::relay($config{LF_ALERT_TO}, $config{LF_ALERT_FROM}, @message);

				if ($config{DEBUG} >= 1) {logfile("debug: X-ARF email sent for $ip")}
			}
		}

		if ($config{DEBUG} >= 3) {$timer = &timer("stop","block",$timer)}
		$0 = "lfd - child closing";
		exit;
	}
	return;
}
# end block
###############################################################################
# start blockaccount
sub blockaccount {
	my $ipa = shift;
	my @ips = @$ipa;
	my $account = shift;
	my $ipcount = shift;
	my $app = shift;
	my $text = shift;
	my $temp = shift;
	my $trigger = shift;

	foreach my $ip (@ips) {
		$blockedips{$ip}{block} = 1;
		$blockedips{$ip}{apps} .= "$app\,";
	}

	$SIG{CHLD} = 'IGNORE';
	unless (defined ($childpid = fork)) {
		&shutdown(__LINE__,"*Error* cannot fork: $!");
	} 
	$forks{$childpid} = 1;
	unless ($childpid) {
		my $timer = time;
		if ($config{DEBUG} >= 3) {$timer = &timer("start","blockaccount",$timer)}
		my $perm = 1;
		if ($temp > 1) {$perm = 0}

		$text .= "\nIP Addresses Blocked:\n\n";
		foreach my $ip (@ips) {
			$0 = "lfd - (child) blocking $ip";

			if ($config{PT_SSHDKILL} and $app eq "sshd") {ConfigServer::KillSSH::find($ip,$ports{sshd})}

			my $tip = iplookup($ip);
			if ($config{LF_SELECT} and !$config{LF_TRIGGER}) {
				if (&ipblock($perm,"$tip, $ipcount distributed $app attacks on account [$account] in the last $config{LF_INTERVAL} secs",$ip,$ports{$app},"in",$temp,0,$text,"LF_DISTATTACK")) {
					if ($config{DEBUG} >= 1) {logfile("debug: $ip already blocked")}
				}
			} else {
				if (&ipblock($perm,"$tip, $ipcount distributed $app attacks on account [$account] in the last $config{LF_INTERVAL} secs",$ip,"","inout",$temp,0,$text,"LF_DISTATTACK")) {
					if ($config{DEBUG} >= 1) {logfile("debug: $ip already blocked")}
				}
			}
			$text .= "$tip\n";
			if ($cxsreputation) {
				ConfigServer::cxs::Rreport($trigger,$ip,"$ipcount distributed $trigger attacks in the last $config{LF_INTERVAL} secs",$trigger);
			}
		}

		if ($config{LF_EMAIL_ALERT} and ($perm or $config{LF_TEMP_EMAIL_ALERT})) {
			my @alert = slurp("/usr/local/csf/tpl/alert.txt");
			my $block = "Temporary Block for $temp seconds [LF_DISTATTACK]";
			if ($perm) {$block = "Permanent Block [LF_DISTATTACK]"}

			my @message;
			foreach my $line (@alert) {
				$line =~ s/\[ip\]/distributed $app attack on account [$account]/ig;
				$line =~ s/\[ipcount\]/$ipcount/ig;
				$line =~ s/\[iptick\]/$config{LF_INTERVAL}/ig;
				$line =~ s/\[block\]/$block/ig;
				$line =~ s/\[text\]/$text/ig;
				push @message, $line;
			}
			ConfigServer::Sendmail::relay("", "", @message);
		}

		if ($config{DEBUG} >= 3) {$timer = &timer("stop","blockaccount",$timer)}
		$0 = "lfd - child closing";
		exit;
	}
	return;
}
# end blockaccount
###############################################################################
# start blockdistftp
sub blockdistftp {
	my $ipa = shift;
	my @ips = @$ipa;
	my $account = shift;
	my $ipcount = shift;
	my $text = shift;
	my $temp = shift;

	$SIG{CHLD} = 'IGNORE';
	unless (defined ($childpid = fork)) {
		&shutdown(__LINE__,"*Error* cannot fork: $!");
	} 
	$forks{$childpid} = 1;
	unless ($childpid) {
		my $timer = time;
		if ($config{DEBUG} >= 3) {$timer = &timer("start","blockdistftp",$timer)}
		my $perm = 1;
		if ($temp > 1) {$perm = 0}

		$text .= "\nIP Addresses Blocked:\n\n";
		foreach my $ip (@ips) {
			$0 = "lfd - (child) blocking $ip";
			my $tip = iplookup($ip);
			if (&ipblock($perm,"$tip, $ipcount distributed FTP Logins on account [$account] in the last $config{LF_DIST_INTERVAL} secs",$ip,"","inout",$temp,0,$text,"LF_DISTFTP")) {
				if ($config{DEBUG} >= 1) {logfile("debug: $ip already blocked")}
			}
			$text .= "$tip\n";
		}

		if ($config{LF_DISTFTP_ALERT}) {
			my @alert = slurp("/usr/local/csf/tpl/alert.txt");
			my $block = "Temporary Block for $temp seconds [LF_DISTFTP]";
			if ($perm) {$block = "Permanent Block [LF_DISTFTP]"}

			my @message;
			foreach my $line (@alert) {
				$line =~ s/\[ip\]/distributed FTP Logins on account [$account]/ig;
				$line =~ s/\[ipcount\]/$ipcount/ig;
				$line =~ s/\[iptick\]/$config{LF_INTERVAL}/ig;
				$line =~ s/\[block\]/$block/ig;
				$line =~ s/\[text\]/$text/ig;
				push @message, $line;
			}
			ConfigServer::Sendmail::relay("", "", @message);
		}

		if ($config{LF_DIST_ACTION} and -e $config{LF_DIST_ACTION} and -x $config{LF_DIST_ACTION}) {
			$0 = "lfd - (child) running LF_DIST_ACTION";
			system($config{LF_DIST_ACTION},"LF_DISTFTP",$account,$text);
		}

		if ($config{DEBUG} >= 3) {$timer = &timer("stop","blockdistftp",$timer)}
		$0 = "lfd - child closing";
		exit;
	}
	return;
}
# end blockdistftp
###############################################################################
# start blockdistsmtp
sub blockdistsmtp {
	my $ipa = shift;
	my @ips = @$ipa;
	my $account = shift;
	my $ipcount = shift;
	my $text = shift;
	my $temp = shift;

	$SIG{CHLD} = 'IGNORE';
	unless (defined ($childpid = fork)) {
		&shutdown(__LINE__,"*Error* cannot fork: $!");
	} 
	$forks{$childpid} = 1;
	unless ($childpid) {
		my $timer = time;
		if ($config{DEBUG} >= 3) {$timer = &timer("start","blockdistsmtp",$timer)}
		my $perm = 1;
		if ($temp > 1) {$perm = 0}

		$text .= "\nIP Addresses Blocked:\n\n";
		foreach my $ip (@ips) {
			$0 = "lfd - (child) blocking $ip";
			my $tip = iplookup($ip);
			if (&ipblock($perm,"$tip, $ipcount distributed SMTP Logins on account [$account] in the last $config{LF_DIST_INTERVAL} secs",$ip,"","inout",$temp,0,$text,"LF_DISTSMTP")) {
				if ($config{DEBUG} >= 1) {logfile("debug: $ip already blocked")}
			}
			$text .= "$tip\n";
		}

		if ($config{LF_DISTSMTP_ALERT}) {
			my @alert = slurp("/usr/local/csf/tpl/alert.txt");
			my $block = "Temporary Block for $temp seconds [LF_DISTSMTP]";
			if ($perm) {$block = "Permanent Block [LF_DISTSMTP]"}

			my @message;
			foreach my $line (@alert) {
				$line =~ s/\[ip\]/distributed SMTP Logins on account [$account]/ig;
				$line =~ s/\[ipcount\]/$ipcount/ig;
				$line =~ s/\[iptick\]/$config{LF_INTERVAL}/ig;
				$line =~ s/\[block\]/$block/ig;
				$line =~ s/\[text\]/$text/ig;
				push @message, $line;
			}
			ConfigServer::Sendmail::relay("", "", @message);
		}

		if ($config{LF_DIST_ACTION} and -e $config{LF_DIST_ACTION} and -x $config{LF_DIST_ACTION}) {
			$0 = "lfd - (child) running LF_DIST_ACTION";
			system($config{LF_DIST_ACTION},"LF_DISTSMTP",$account,$text);
		}

		if ($config{DEBUG} >= 3) {$timer = &timer("stop","blockdistsmtp",$timer)}
		$0 = "lfd - child closing";
		exit;
	}
	return;
}
# end blockdistsmtp
###############################################################################
# start disable404
sub disable404 {
	my $ip = shift;
	my $text = shift;

	$SIG{CHLD} = 'IGNORE';
	unless (defined ($childpid = fork)) {
		&shutdown(__LINE__,"*Error* cannot fork: $!");
	} 
	$forks{$childpid} = 1;
	unless ($childpid) {
		my $timer = time;
		if ($config{DEBUG} >= 3) {$timer = &timer("start","disable404",$timer)}

		my $tip = iplookup($ip);
		my $perm = 1;
		if ($config{LF_APACHE_404_PERM} > 1) {$perm = 0}
		if (&ipblock($perm,"$tip, more than $config{LF_APACHE_404} Apache 404 hits in the last $config{LF_INTERVAL} secs",$ip,$ports{mod_security},"in",$config{LF_APACHE_404_PERM},0,"","LF_APACHE_404")) {
			if ($config{DEBUG} >= 1) {logfile("debug: $ip already blocked")}
		} else {
			if ($config{LT_EMAIL_ALERT}) {
				$0 = "lfd - (child) sending alert email for $ip";

				my @alert = slurp("/usr/local/csf/tpl/alert.txt");
				my $block = "Temporary Block for $config{LF_APACHE_404_PERM} seconds [LF_APACHE_404]";
				if ($perm) {$block = "Permanent Block [LF_APACHE_404]"}
				my @message;
				foreach my $line (@alert) {
					$line =~ s/\[ip\]/$tip/ig;
					$line =~ s/\[ipcount\]/$config{LF_APACHE_404}/ig;
					$line =~ s/\[iptick\]/$config{LF_INTERVAL}/ig;
					$line =~ s/\[block\]/$block/ig;
					$line =~ s/\[text\]/$text/ig;
					push @message, $line;
				}
				ConfigServer::Sendmail::relay("", "", @message);
			}
		}

		if ($config{DEBUG} >= 3) {$timer = &timer("stop","disable404",$timer)}
		$0 = "lfd - child closing";
		exit;
	}
	return;
}
# end disable404
###############################################################################
# start disable403
sub disable403 {
	my $ip = shift;
	my $text = shift;

	$SIG{CHLD} = 'IGNORE';
	unless (defined ($childpid = fork)) {
		&shutdown(__LINE__,"*Error* cannot fork: $!");
	} 
	$forks{$childpid} = 1;
	unless ($childpid) {
		my $timer = time;
		if ($config{DEBUG} >= 3) {$timer = &timer("start","disable403",$timer)}

		my $tip = iplookup($ip);
		my $perm = 1;
		if ($config{LF_APACHE_403_PERM} > 1) {$perm = 0}
		if (&ipblock($perm,"$tip, more than $config{LF_APACHE_403} Apache 403 hits in the last $config{LF_INTERVAL} secs",$ip,$ports{mod_security},"in",$config{LF_APACHE_403_PERM},0,"","LF_APACHE_403")) {
			if ($config{DEBUG} >= 1) {logfile("debug: $ip already blocked")}
		} else {
			if ($config{LT_EMAIL_ALERT}) {
				$0 = "lfd - (child) sending alert email for $ip";

				my @alert = slurp("/usr/local/csf/tpl/alert.txt");
				my $block = "Temporary Block for $config{LF_APACHE_403_PERM} seconds [LF_APACHE_403]";
				if ($perm) {$block = "Permanent Block [LF_APACHE_403]"}
				my @message;
				foreach my $line (@alert) {
					$line =~ s/\[ip\]/$tip/ig;
					$line =~ s/\[ipcount\]/$config{LF_APACHE_403}/ig;
					$line =~ s/\[iptick\]/$config{LF_INTERVAL}/ig;
					$line =~ s/\[block\]/$block/ig;
					$line =~ s/\[text\]/$text/ig;
					push @message, $line;
				}
				ConfigServer::Sendmail::relay("", "", @message);
			}
		}

		if ($config{DEBUG} >= 3) {$timer = &timer("stop","disable403",$timer)}
		$0 = "lfd - child closing";
		exit;
	}
	return;
}
# end disable403
###############################################################################
# start disable401
sub disable401 {
	my $ip = shift;
	my $text = shift;

	$SIG{CHLD} = 'IGNORE';
	unless (defined ($childpid = fork)) {
		&shutdown(__LINE__,"*Error* cannot fork: $!");
	} 
	$forks{$childpid} = 1;
	unless ($childpid) {
		my $timer = time;
		if ($config{DEBUG} >= 3) {$timer = &timer("start","disable401",$timer)}

		my $tip = iplookup($ip);
		my $perm = 1;
		if ($config{LF_APACHE_401_PERM} > 1) {$perm = 0}
		if (&ipblock($perm,"$tip, more than $config{LF_APACHE_401} Apache 401 hits in the last $config{LF_INTERVAL} secs",$ip,$ports{mod_security},"in",$config{LF_APACHE_401_PERM},0,"","LF_APACHE_401")) {
			if ($config{DEBUG} >= 1) {logfile("debug: $ip already blocked")}
		} else {
			if ($config{LT_EMAIL_ALERT}) {
				$0 = "lfd - (child) sending alert email for $ip";

				my @alert = slurp("/usr/local/csf/tpl/alert.txt");
				my $block = "Temporary Block for $config{LF_APACHE_401_PERM} seconds [LF_APACHE_401]";
				if ($perm) {$block = "Permanent Block [LF_APACHE_401]"}
				my @message;
				foreach my $line (@alert) {
					$line =~ s/\[ip\]/$tip/ig;
					$line =~ s/\[ipcount\]/$config{LF_APACHE_401}/ig;
					$line =~ s/\[iptick\]/$config{LF_INTERVAL}/ig;
					$line =~ s/\[block\]/$block/ig;
					$line =~ s/\[text\]/$text/ig;
					push @message, $line;
				}
				ConfigServer::Sendmail::relay("", "", @message);
			}
		}

		if ($config{DEBUG} >= 3) {$timer = &timer("stop","disable401",$timer)}
		$0 = "lfd - child closing";
		exit;
	}
	return;
}
# end disable401
###############################################################################
# start logindisable
sub logindisable {
	my $app = shift;
	my $ip = shift;
	my $logins = shift;
	my $account = shift;
	my $trigger = "LT_".uc($app);

	my $port = "110";
	my $sport = "995";
	if ($app eq "imapd") {$port = "143"; $sport = "993"}

	$SIG{CHLD} = 'IGNORE';
	unless (defined ($childpid = fork)) {
		&shutdown(__LINE__,"*Error* cannot fork: $!");
	} 
	$forks{$childpid} = 1;
	unless ($childpid) {
		my $timer = time;
		if ($config{DEBUG} >= 3) {$timer = &timer("start","logindisable",$timer)}
		my $flush = (3600-$logintimeout{$app});

		my $tip = iplookup($ip);
		if ($config{LT_SKIPPERMBLOCK}) {$config{LF_PERMBLOCK} = 0}
		if (&ipblock(0,"$app - $logins logins in $logintimeout{$app} secs from $tip for $account exceeds $loginproto{$app}/hour",$ip,"$port,$sport","in",$flush,0,"",$trigger)) {
			if ($config{DEBUG} >= 1) {logfile("debug: $ip already blocked")}
		} else {
			if ($config{LT_EMAIL_ALERT}) {
				$0 = "lfd - (child) sending alert email for $account";

				my @alert = slurp("/usr/local/csf/tpl/tracking.txt");
				my @message;
				foreach my $line (@alert) {
					$line =~ s/\[ip\]/$tip/ig;
					$line =~ s/\[app\]/$app/ig;
					$line =~ s/\[logins\]/$logins/ig;
					$line =~ s/\[account\]/$account/ig;
					$line =~ s/\[timeout\]/$logintimeout{$app}/ig;
					$line =~ s/\[flush\]/$flush/ig;
					$line =~ s/\[rate\]/$loginproto{$app}/ig;
					push @message, $line;
				}
				ConfigServer::Sendmail::relay("", "", @message);

				logfile("tracking email sent for $account");
			}
		}

		if ($config{DEBUG} >= 3) {$timer = &timer("stop","logindisable",$timer)}
		$0 = "lfd - child closing";
		exit;
	}
	return;
}

# #
# 	Port Scans
# #

sub portscans
{
	my $ip = shift;
	my $count = shift;
	my $blocks = shift;

	$SIG{CHLD} = 'IGNORE';
	unless (defined ($childpid = fork)) {
		&shutdown(__LINE__,"*Error* cannot fork: $!");
	} 
	$forks{$childpid} = 1;
	unless ($childpid) {
		my $timer = time;
		if ($config{DEBUG} >= 3) {$timer = &timer("start","portscans",$timer)}

		my $tip = iplookup($ip);
		if (&ipblock($config{PS_PERMANENT},"*Port Scan* detected from $tip. $count hits in the last $pstimeout seconds",$ip,"","in",$config{PS_BLOCK_TIME},0,$blocks,"PS_LIMIT")) {
			if ($config{DEBUG} >= 1) {logfile("debug: $ip already blocked")}
		} else {
			if ($config{PS_EMAIL_ALERT}) {
				$0 = "lfd - (child) sending alert email for $ip";

				my @alert = slurp("/usr/local/csf/tpl/portscan.txt");
				my $block = "Temporary Block for $config{PS_BLOCK_TIME} seconds [PS_LIMIT]";
				if ($config{PS_PERMANENT}) {$block = "Permanent Block [PS_LIMIT]"}

				my $allowip = &allowip($ip);
				if ($allowip == 1) {$block .= " (IP match in csf.allow, block may not work)"}
				if ($allowip == 2) {$block .= " (IP match in GLOBAL_ALLOW, block may not work)"}

				my @message;
				foreach my $line (@alert) {
					$line =~ s/\[ip\]/$tip/ig;
					$line =~ s/\[count\]/$count/ig;
					$line =~ s/\[blocks\]/$blocks/ig;
					$line =~ s/\[temp\]/$block/ig;
					push @message, $line;
				}
				ConfigServer::Sendmail::relay("", "", @message);
				if ($config{DEBUG} >= 1) {logfile("debug: alert email sent for $ip")}

				if ($config{X_ARF}) {
					$0 = "lfd - (child) sending X-ARF email for $ip";

					my @alert = slurp("/usr/local/csf/tpl/x-arf.txt");
					my @message;
					my $rfc3339 = strftime('%Y-%m-%dT%H:%M:%S%z',localtime);
					my $boundary = time;
					my $reportedfrom = "root\@$hostname";
					if ($config{X_ARF_TO}) {$config{LF_ALERT_TO} = $config{X_ARF_TO}}
					if ($config{X_ARF_FROM}) {$config{LF_ALERT_FROM} = $config{X_ARF_FROM}; $reportedfrom = $config{X_ARF_FROM}}
					my $iptype = "ipv".checkip(\$ip);

					my $abuseto = "";
					my $abusemsg = "";
					if ($iptype eq "ipv4" and $abuseip) {
						($abuseto, $abusemsg) = abuseip($ip);
						if ($abuseto eq "") {
							$abusemsg = "";
						}
						elsif ($config{X_ARF_ABUSE} and $config{X_ARF_FROM}) {
							if ($config{LF_ALERT_TO}) {
								$config{LF_ALERT_TO} .= ",".$abuseto;
							} else {
								$config{LF_ALERT_TO} = "root,".$abuseto;
							}
						}
					}

					foreach my $line (@alert) {
						$line =~ s/\[ip\]/$ip/ig;
						$line =~ s/\[abuseip\]/$abusemsg/ig;
						$line =~ s/\[iptype\]/$iptype/ig;
						$line =~ s/\[tip\]/$tip/ig;
						$line =~ s/\[ipcount\]/$count/ig;
						$line =~ s/\[iptick\]/$config{LF_INTERVAL}/ig;
						$line =~ s/\[service\]/firewall/ig;
						$line =~ s/\[csfversion\]/$version/ig;
						$line =~ s/\[reportedfrom\]/$reportedfrom/ig;
						$line =~ s/\[reportedid\]/$boundary\@$hostname/ig;
						$line =~ s/\[boundary\]/$boundary/ig;
						$line =~ s/\[text\]/$blocks/ig;
						$line =~ s/\[RFC3339\]/$rfc3339/ig;
						push @message, $line;
					}
					ConfigServer::Sendmail::relay($config{LF_ALERT_TO}, $config{LF_ALERT_FROM}, @message);

					if ($config{DEBUG} >= 1) {logfile("debug: X-ARF email sent for $ip")}
				}
			}
		}

		if ($config{DEBUG} >= 3) {$timer = &timer("stop","portscans",$timer)}
		$0 = "lfd - child closing";
		exit;
	}
	return;
}

# #
#   Fork child process to handle UID scan alerts without blocking lfd.
#	
#   Child proc logs the UID/user and block count, fill the uidscan email template
#   ([uid], [count], [ports]), send the alert email.
# #

sub uidscans
{
	my $uid 		= shift;
	my $count 		= shift;
	my $blocks 		= shift;

	$SIG{CHLD} = 'IGNORE';
	unless ( defined ( $childpid = fork ) )
	{
		&shutdown( __LINE__, "*Error* cannot fork: $!" );
	}

	$forks{$childpid} = 1;
	unless ( $childpid )
	{
		my $timer = time;
		if ( $config{DEBUG} >= 3 )
		{
			$timer = &timer( "start", "uidscans", $timer )
		}

		$0 = "lfd - (child) sending alert email for UID $uid";

		my $user = getpwuid($uid);
		if ( $user eq "" ) { $user = $uid }
		logfile( "[STATUS] *UID Tracking* $count blocks for UID $uid ($user)" );

		my @alert = slurp( "/usr/local/csf/tpl/uidscan.txt" );
		my @message;
	
		foreach my $line ( @alert )
		{
			$line =~ s/\[uid\]/$uid ($user)/ig;
			$line =~ s/\[count\]/$count/ig;
			$line =~ s/\[ports\]/$blocks/ig;
			push @message, $line;
		}

		ConfigServer::Sendmail::relay( "", "", @message );
	
		if ( $config{DEBUG} >= 1 )
		{
			logfile( "[DEBUG][1] alert email sent for UID $uid ($user)" );
		}

		if ( $config{DEBUG} >= 3 )
		{
			$timer = &timer( "stop", "uidscans", $timer )
		}
	
		$0 = "lfd - child closing";
		exit;
	}
	return;
}

# #
#	Restart CSF firewall via csf -sf and optionally track execution time in DEBUG mode.
# #

sub csfrestart
{
	my $timer = time;
	if ( $config{DEBUG} >= 3 )
	{
		$timer = &timer( "start", "csfrestart", $timer )
	}

	$0 = "lfd - (re)starting csf...";

	logfile( "[STATUS] csf (re)start requested - running *csf startup*..." );
	&syscommand( __LINE__, "/usr/sbin/csf", "-sf" );
	logfile( "[STATUS] csf (re)start completed" );

	if ( $config{DEBUG} >= 3 )
	{
		$timer = &timer( "stop", "csfrestart", $timer )
	}

	$0 = "lfd - processing";
	return;
}


sub lfdrestart
{
	$SIG{INT} 	= 'IGNORE';
	$SIG{TERM} 	= 'IGNORE';
	$SIG{CHLD} 	= 'IGNORE';
	$0 			= "lfd - stopping";

	logfile( "Daemon restart requested" );

	close( $PIDFILE );
	unlink( $pidfile );

	$SIG{HUP} = 'IGNORE';
	kill HUP => -$$;
	exec("/usr/sbin/lfd");

	exit 0;
}

sub csfcheck
{
	my $timer = time;
	if ( $config{DEBUG} >= 3 )
	{
		$timer = &timer( "start", "csfcheck", $timer )
	}

	my @ipdata = &syscommand( __LINE__, "$config{IPTABLES} $config{IPTABLESWAIT} -L LOCALINPUT -n" );
	chomp @ipdata;
	if ( $ipdata[0] =~ /# Warning: iptables-legacy tables present/)
	{
		shift @ipdata
	}

	if ( $ipdata[0] =~ /xtables lock/ )
	{
		logfile( "*Error*: Unable to check csf due to xtables lock, enable WAITLOCK in csf.conf" );
	}
	else
	{
		if ( $ipdata[0] !~ /^Chain LOCALINPUT/ )
		{
			$0 = "lfd - starting csf...";
			logfile( "iptables appears to have been flushed - running *csf startup*..." );
			&syscommand( __LINE__, "/usr/sbin/csf", "-sf" );
			logfile( "csf startup completed" );
			$0 = "lfd - processing";
		}

		if ( $config{INTERWORX} )
		{
			&syscommand( __LINE__, "cp -af /etc/csf/apf_stub.pl /etc/apf/apf" );
			&syscommand( __LINE__, "chmod 750 /etc/apf/apf" );
		}

		if ( -e "/usr/local/cpanel/version" )
		{
			my $skip;

			if ( -e "/var/run/upcp.pid" )
			{
				open ( my $IN, "<", "/var/run/upcp.pid" );
				flock ( $IN, LOCK_SH );
				my $upcp = <$IN>;
				close ( $IN );
				chomp ( $upcp );

				if ( -d "/proc/$upcp" )
				{
					if ( $config{DEBUG} >= 1 )
					{
						logfile( "cPanel upcp is running, skipped version check" )
					}
					$skip = 1;
				}
			}

			if ( -e "/var/lib/csf/cpanel.new" )
			{
				my $mtime = ( stat( "/var/lib/csf/cpanel.new" ) )[9];
				if ( time - $mtime < 3600 )
				{
					$skip = 1
				}
			}

			unless ($skip) {
				my $current;
				foreach my $line (slurp("/usr/local/cpanel/version")) {
					$line =~ s/$cleanreg//g;
					if ($line =~ /\d/) {$current = $line}
				}
				if ($current ne $cpconfig{version}) {
					$SIG{CHLD} = 'IGNORE';
					unless (defined ($childpid = fork)) {
						&shutdown(__LINE__,"*Error* cannot fork: $!");
					} 
					$forks{$childpid} = 1;
					unless ($childpid) {
						local $SIG{CHLD} = 'DEFAULT';
						my $timer = time;
						if ($config{DEBUG} >= 3) {$timer = &timer("start","cpanelcheck",$timer)}
						$0 = "lfd - (child) cPanel upgraded...";

						my $lockstr = "LF_CSF";
						sysopen (my $THISLOCK, "/var/lib/csf/lock/$lockstr.lock", O_RDWR | O_CREAT) or &shutdown_child("*Error* Unable to open /var/lib/csf/lock/$lockstr.lock");
						flock ($THISLOCK, LOCK_EX | LOCK_NB) or &shutdown_child("*Lock Error* [$lockstr] still active - section skipped");
						print $THISLOCK time;

						logfile("cPanel upgrade detected, restarting ConfigServer services...");

						if (-e "/var/lib/csf/cpanel.new") { unlink "/var/lib/csf/cpanel.new"}
						open (my $CPANELNEW, ">", "/var/lib/csf/cpanel.new");
						flock ($CPANELNEW, LOCK_EX);
						print $CPANELNEW time;
						close ($CPANELNEW);

						if (-e "/etc/cxs/cxs.pl") {
							logfile("cPanel upgrade detected, restarting cxs Watch (if running)");
							open (my $OUT, ">", "/etc/cxs/newusers/cxswatchrestart");
							close ($OUT);
							logfile("cPanel upgrade detected, restarting cxs pure-uploadscript (if running)");
							eval {
								local $SIG{__DIE__} = undef;
								local $SIG{'ALRM'} = sub {die};
								alarm(30);
								&syscommand(__LINE__,"/sbin/service","pure-uploadscript","restart");
								&syscommand(__LINE__,"/scripts/restartsrv_ftpserver");
								alarm(0);
							};
							alarm(0);
						}

						if (-e "/etc/osm/osmd.pl") {
							logfile("cPanel upgrade detected, restarting osmd");
							eval {
								local $SIG{__DIE__} = undef;
								local $SIG{'ALRM'} = sub {die};
								alarm(30);
								&syscommand(__LINE__,"/sbin/service","osmd","restart");
								alarm(0);
							};
							alarm(0);
						}

						if (-e "/etc/exim_outgoing.conf" and (-e "/etc/init.d/MailScanner" or -e "/etc/systemd/system/multi-user.target.wants/MailScanner.service")) {
							logfile("cPanel upgrade detected, restarting MailScanner");
							eval {
								local $SIG{__DIE__} = undef;
								local $SIG{'ALRM'} = sub {die};
								alarm(30);
								&syscommand(__LINE__,"/sbin/service","MailScanner","restart");
								alarm(0);
							};
							alarm(0);
						}

						logfile("cPanel upgrade detected, restarting lfd");
						open (my $LFDOUT, ">", "/var/lib/csf/lfd.restart");
						close ($LFDOUT);
				
						close ($THISLOCK );
						if ($config{DEBUG} >= 3) {$timer = &timer("stop","cpanelcheck",$timer)}
						$0 = "lfd - child closing";
						exit;
					}
				}
			}
		}
	}

	if ( $config{DEBUG} >= 3 )
	{
		$timer = &timer( "stop", "csfcheck", $timer )
	}

	return;
}

# #
#	Load Check
# #

sub loadcheck
{
	if ( -e "/var/lib/csf/csf.load" )
	{
		open ( my $IN, "<", "/var/lib/csf/csf.load" );
		flock ( $IN, LOCK_SH );
		my $start = <$IN>;
		close ( $IN );
		chomp $start;
		if ( time - $start < $config{PT_LOAD_SKIP} )
		{
			return;
		}
		else
		{
			unlink ("/var/lib/csf/csf.load");
		}
	}

	$SIG{CHLD} = 'IGNORE';
	unless (defined ($childpid = fork))
	{
		&shutdown(__LINE__,"*Error* cannot fork: $!");
	} 

	$forks{$childpid} = 1;
	unless ( $childpid )
	{
		my $timer = time;
		if ($config{DEBUG} >= 3) {$timer = &timer("start","loadcheck",$timer)}
		$0 = "lfd - (child) checking load...";

		my $lockstr = "PT_LOAD";
		sysopen (my $THISLOCK, "/var/lib/csf/lock/$lockstr.lock", O_RDWR | O_CREAT) or &shutdown_child("*Error* Unable to open /var/lib/csf/lock/$lockstr.lock");
		flock ($THISLOCK, LOCK_EX | LOCK_NB) or &shutdown_child("*Lock Error* [$lockstr] still active - section skipped");
		print $THISLOCK time;

		open (my $IN, "<", "/proc/loadavg");
		flock ($IN, LOCK_SH);
		my $loadavg = <$IN>;
		close ($IN);
		chomp $loadavg;
		my @load = split(/\s+/,$loadavg);

		my $reportload 							= $load[1];
		if ( $config{PT_LOAD_AVG} == 1 ) 		{ $reportload = $load[0] }
		elsif ( $config{PT_LOAD_AVG} == 15 ) 	{ $reportload = $load[2] }
		else { $config{PT_LOAD_AVG} = 5 }

		if ( $reportload >= $config{PT_LOAD_LEVEL} )
		{
			logfile("*LOAD* $config{PT_LOAD_AVG} minute load average is $reportload, threshold is $config{PT_LOAD_LEVEL} - email sent");

			sysopen (my $LOAD, "/var/lib/csf/csf.load", O_WRONLY | O_CREAT) or &shutdown_child(__LINE__,"*Error* Cannot write to file: $!");
			flock ($LOAD, LOCK_EX);
			seek ($LOAD, 0, 0);
			truncate ($LOAD, 0);
			print $LOAD time;
			close ($LOAD);

			if ( $config{PT_LOAD_ACTION} and -e "$config{PT_LOAD_ACTION}" and -x "$config{PT_LOAD_ACTION}" )
			{
				$SIG{CHLD} = 'IGNORE';

				my $ptchildpid = fork;
				if ( !defined $ptchildpid )
				{
					shutdown( __LINE__, "*Error* cannot fork: $!" );
				}

				# Run block in child process
				if ( $ptchildpid == 0 )
				{
					system( $config{PT_LOAD_ACTION} );
					exit;
				}
			}

			my @proclist;
			eval {
				local $SIG{__DIE__} = undef;
				local $SIG{'ALRM'} = sub {die};
				alarm(15);
				@proclist = &syscommand(__LINE__,$config{PS},"axuf");
				alarm(0);
			};
			alarm(0);
			if ($@) {push @proclist, "Unable to obtain process output within 15 seconds - Timed out"}

			my @vmstat;
			eval {
				local $SIG{__DIE__} = undef;
				local $SIG{'ALRM'} = sub {die};
				alarm(10);
				@vmstat = &syscommand(__LINE__,$config{VMSTAT});
				alarm(0);
			};
			alarm(0);
			if ($@) {push @vmstat, "Unable to obtain vmstat output within 10 seconds - Timed out"}

			my @netstat;
			eval
			{
				local $SIG{__DIE__} = undef;
				local $SIG{'ALRM'} = sub {die};
				alarm(10);
				@netstat = &syscommand(__LINE__,$config{NETSTAT}, "-autpn");
				alarm(0);
			};

			alarm(0);
	
			if ( $@ ) 				{ push @netstat, "Unable to obtain netstat output within 10 seconds - Timed out" }
			my ( $url, $log_url ) 	= _get_apache_status_url( $config{PT_APACHESTATUS} );			# query http://127.0.0.1/whm-server-status
			my ( $status, $apache ) = $urlget->urlget($url);
			if ( $status ) 			{ $apache = "Unable to retrieve Apache Server Status [$log_url] - $apache" }

			my @alert 		= slurp("/usr/local/csf/tpl/loadalert.txt");
			my $boundary 	= "csf".time;
			my @message;

			foreach my $line ( @alert )
			{
				$line =~ s/\[loadavg1\]/$load[0]/ig;
				$line =~ s/\[loadavg5\]/$load[1]/ig;
				$line =~ s/\[loadavg15\]/$load[2]/ig;
				$line =~ s/\[loadavg\]/$config{PT_LOAD_AVG}/ig;
				$line =~ s/\[reportload\]/$reportload/ig;
				$line =~ s/\[totprocs\]/$load[3]/ig;
				$line =~ s/\[processlist\]/@proclist/ig;
				$line =~ s/\[vmstat\]/@vmstat/ig;
				$line =~ s/\[netstat\]/@netstat/ig;
				$line =~ s/\[apache\]/$apache/ig;
				$line =~ s/\[boundary\]/$boundary/ig;
				push @message, $line;
			}

			ConfigServer::Sendmail::relay( "", "", @message );
		}

		close ($THISLOCK );
		if ( $config{DEBUG} >= 3 ) { $timer = &timer( "stop", "loadcheck", $timer ) }
		$0 = "lfd - child closing";

		exit;
	}

	return;
}
# end loadcheck
###############################################################################
# start denycheck
sub denycheck {
	my $ip = shift;
	my $port = shift;
	my $perm = shift;
	my $ipstring = quotemeta($ip);
	my $skip = 0;

	my @deny = slurp("/etc/csf/csf.deny");
	foreach my $line (@deny) {
		if ( $line =~ /^Include\s*(.*)$/ ) {
			my @incfile = slurp( $1 );
			push @deny,@incfile;
		}
	}
	my $denymatches = scalar(grep {$_ =~ /^$ipstring\b/i} @deny);
	if ($config{LF_REPEATBLOCK} and $denymatches < $config{LF_REPEATBLOCK}) {$denymatches = 0}
	unless ($denymatches == 0) {$skip = 1}

	open (my $IN, "<", "/var/lib/csf/csf.tempban");
	flock ($IN, LOCK_SH);
	@deny = <$IN>;
	close ($IN);
	chomp @deny;
	if (grep {$_ =~ /^\d+\|$ipstring\|$port\|/i} @deny) {
		unless ($perm) {$skip = 1}
	}

	return $skip;
}
# end denycheck
###############################################################################
# start queuecheck
sub queuecheck {
	if (-e "/var/lib/csf/csf.queue") {
		open (my $IN, "<", "/var/lib/csf/csf.queue");
		flock ($IN, LOCK_SH);
		my $start = <$IN>;
		close ($IN);
		chomp $start;
		if (time - $start < $config{LF_FLUSH}) {
			return;
		} else {
			unlink ("/var/lib/csf/csf.queue");
		}
	}
	$SIG{CHLD} = 'IGNORE';
	unless (defined ($childpid = fork)) {
		&shutdown(__LINE__,"*Error* cannot fork: $!");
	} 
	$forks{$childpid} = 1;
	unless ($childpid) {
		my $timer = time;
		if ($config{DEBUG} >= 3) {$timer = &timer("start","queuecheck",$timer)}
		$0 = "lfd - (child) checking mail queue...";

		my $lockstr = "LF_QUEUE_INTERVAL";
		sysopen (my $THISLOCK, "/var/lib/csf/lock/$lockstr.lock", O_RDWR | O_CREAT) or &shutdown_child("*Error* Unable to open /var/lib/csf/lock/$lockstr.lock");
		flock ($THISLOCK, LOCK_EX | LOCK_NB) or &shutdown_child("*Lock Error* [$lockstr] still active - section skipped");
		print $THISLOCK time;

		my $queue;
		my $msqueue;
		my $timeout = "";
		eval {
			local $SIG{__DIE__} = undef;
			local $SIG{'ALRM'} = sub {die};
			alarm(30);
			$queue = (&syscommand(__LINE__,"/usr/sbin/exim","-bpc"))[0];
			alarm(0);
		};
		alarm(0);
		if ($@) {$timeout = "Unable to obtain exim queue length within 30 seconds - Timed out"}
		chomp $queue;

		if (-e "/etc/exim_outgoing.conf") {
			$msqueue = $queue;
			eval {
				local $SIG{__DIE__} = undef;
				local $SIG{'ALRM'} = sub {die};
				alarm(30);
				$queue = (&syscommand(__LINE__,"/usr/sbin/exim","-C","/etc/exim_outgoing.conf","-bpc"))[0];
				alarm(0);
			};
			alarm(0);
			if ($@) {$timeout = "Unable to obtain exim_outgoing.conf queue length within 30 seconds - Timed out"}
			chomp $queue;
		}

		if (($queue > $config{LF_QUEUE_ALERT}) or ($msqueue > $config{LF_QUEUE_ALERT}) or ($timeout ne "")) {
			my $report = "The exim delivery queue size is $queue";
			if ($msqueue) {$report .= ", the MailScanner pending queue size is $msqueue"}
			if ($timeout) {$report = $timeout}
			logfile("*Email Queue* $report");

			sysopen (my $QUEUE, "/var/lib/csf/csf.queue", O_WRONLY | O_CREAT) or &shutdown_child(__LINE__,"*Error* Cannot write to file: $!");
			flock ($QUEUE, LOCK_EX);
			seek ($QUEUE, 0, 0);
			truncate ($QUEUE, 0);
			print $QUEUE time;
			close ($QUEUE);

			my @alert = slurp("/usr/local/csf/tpl/queuealert.txt");
			my @message;
			foreach my $line (@alert) {
				$line =~ s/\[text\]/$report/ig;
				push @message, $line;
			}
			ConfigServer::Sendmail::relay("", "", @message);
		}

		close ($THISLOCK );
		if ($config{DEBUG} >= 3) {$timer = &timer("stop","queuecheck",$timer)}
		$0 = "lfd - child closing";
		exit;
	}
	return;
}
# end queuecheck
###############################################################################
# start modsecipdbcheck
sub modsecipdbcheck {
	if (-e "/var/lib/csf/csf.modsecipdbcheck") {
		open (my $IN, "<", "/var/lib/csf/csf.modsecipdbcheck");
		flock ($IN, LOCK_SH);
		my $start = <$IN>;
		close ($IN);
		chomp $start;
		if (time - $start < $config{LF_FLUSH}) {
			return;
		} else {
			unlink ("/var/lib/csf/csf.modsecipdbcheck");
		}
	}
	$SIG{CHLD} = 'IGNORE';
	unless (defined ($childpid = fork)) {
		&shutdown(__LINE__,"*Error* cannot fork: $!");
	} 
	$forks{$childpid} = 1;
	unless ($childpid) {
		my $timer = time;
		if ($config{DEBUG} >= 3) {$timer = &timer("start","modsecipdbcheck",$timer)}
		$0 = "lfd - (child) checking modsec ip db...";

		my $lockstr = "LF_MODSECIPDB_ALERT";
		sysopen (my $THISLOCK, "/var/lib/csf/lock/$lockstr.lock", O_RDWR | O_CREAT) or &shutdown_child("*Error* Unable to open /var/lib/csf/lock/$lockstr.lock");
		flock ($THISLOCK, LOCK_EX | LOCK_NB) or &shutdown_child("*Lock Error* [$lockstr] still active - section skipped");
		print $THISLOCK time;

		my $size = (stat $config{LF_MODSECIPDB_FILE})[7]/(1024*1024*1024);

		if ($size > $config{LF_MODSECIPDB_ALERT}) {
			$size = sprintf("%.2f", $size);
			my $report = "ModSecurity persistent IP database ($config{LF_MODSECIPDB_FILE}) size is ${size}GB";

			sysopen (my $QUEUE, "/var/lib/csf/csf.modsecipdbcheck", O_WRONLY | O_CREAT) or &shutdown_child(__LINE__,"*Error* Cannot write to file: $!");
			flock ($QUEUE, LOCK_EX);
			seek ($QUEUE, 0, 0);
			truncate ($QUEUE, 0);
			print $QUEUE time;
			close ($QUEUE);

			my @alert = slurp("/usr/local/csf/tpl/modsecipdbalert.txt");
			my @message;
			foreach my $line (@alert) {
				$line =~ s/\[text\]/$report/ig;
				push @message, $line;
			}
			ConfigServer::Sendmail::relay("", "", @message);
		}

		close ($THISLOCK );
		if ($config{DEBUG} >= 3) {$timer = &timer("stop","modsecipdbcheck",$timer)}
		$0 = "lfd - child closing";
		exit;
	}
	return;
}
# end modsecipdbcheck
###############################################################################
# start connectiontracking
sub connectiontracking
{

	$SIG{CHLD} = 'IGNORE';
	unless ( defined ( $childpid = fork ) )
	{
		&shutdown(__LINE__,"*Error* cannot fork: $!");
	}

	$forks{$childpid} = 1;

	unless ( $childpid )
	{
		my $timer = time;
		if ($config{DEBUG} >= 3) {$timer = &timer("start","connectiontracking",$timer)}
		$0 = "lfd - (child) connection tracking...";

		my $lockstr = "CT_INTERVAL";
		sysopen (my $THISLOCK, "/var/lib/csf/lock/$lockstr.lock", O_RDWR | O_CREAT) or &shutdown_child("*Error* Unable to open /var/lib/csf/lock/$lockstr.lock");
		flock ($THISLOCK, LOCK_EX | LOCK_NB) or &shutdown_child("*Lock Error* [$lockstr] still active - section skipped");
		print $THISLOCK time;

		my @connections;
		my %ipcnt;
		my %iptext;
		my %subcnt;
		my %subtext;
		my $alarm = int($config{CT_INTERVAL}/10) + 10;
		my $start = time;
		my $tfail = 0;
		my %states;
		if ($config{CT_STATES}) {
			foreach my $state (split(/\,/,$config{CT_STATES})) {
				$states{$state} = 1;
			}
		}
		my %countports;
		if ($config{CT_PORTS}) {
			foreach my $port (split(/\,/,$config{CT_PORTS})) {
				$countports{$port} = 1;
			}
		}

		my %net;
		my %tcpstates = (
			"01" => "ESTABLISHED",
			"02" => "SYN_SENT",
			"03" => "SYN_RECV",
			"04" => "FIN_WAIT1",
			"05" => "FIN_WAIT2",
			"06" => "TIME_WAIT",
			"07" => "CLOSE",
			"08" => "CLOSE_WAIT",
			"09" => "LAST_ACK",
			"0A" => "LISTEN",
			"0B" => "CLOSING"
		);

		foreach my $proto ( "tcp","udp","tcp6","udp6" )
		{
			open (my $IN, "<", "/proc/net/$proto");
			flock ($IN, LOCK_SH);
			while (<$IN>) {
				my @rec = split();
				if ($rec[9] =~ /uid/) { next }

				my ($dip,$dport) = split(/:/,$rec[1]);
				$dport = hex($dport);

				my ($sip,$sport) = split(/:/,$rec[2]);
				$sport = hex($sport);

				$dip = ConfigServer::GetIPs::hex2ip( $dip );
				if ($dip =~ /^0:0:0:0:0:ffff:(.*)$/) {
					my $embed = ConfigServer::GetIPs::ipv4in6($dip);
					if ($embed =~ /^$ipv4reg$/) {$dip = $embed}
				}

				$sip = ConfigServer::GetIPs::hex2ip($sip);
				if ($sip =~ /^0:0:0:0:0:ffff:(.*)$/) {
					my $embed = ConfigServer::GetIPs::ipv4in6($sip);
					if ($embed =~ /^$ipv4reg$/) {$sip = $embed}
				}

				my $state = $tcpstates{$rec[3]};

				if ($config{DEBUG} >= 4) {logfile("debug: CT $proto: $sip:$sport -> $dip:$dport state:[$state]")}

				if ($config{CT_SKIP_TIME_WAIT} and ($state eq "TIME_WAIT")) { next }
				if ($config{CT_STATES} and ($states{$state} != 1)) { next }
				if ($config{CT_PORTS} and ($countports{$dport} != 1)) { next }
				if ($state eq "LISTEN") { next }
				if ($dip =~ /^127\./) { next }
				if ($dip =~ /^0\.0\.0\.1/) { next }

				checkip(\$sip);
				$ipcnt{$sip}++;
				$iptext{$sip} .= "$proto: $sip:$sport -> $dip:$dport ($state)\n";

				if ($config{CT_SUBNET_LIMIT} > 0) {
					my $subnet;
					if ($sip =~ /^(\d+\.\d+\.\d+)\.\d+$/) {
						$subnet = $1;
						if ($subnet ne "0.0.0" and $subnet ne "255.255.255") {
							$subcnt{$subnet}++;
							$subtext{$subnet} .= "$proto: $sip:$sport -> $dip:$dport ($state)\n";
							if ($config{DEBUG} >= 2) {logfile("debug: CT $proto: $sip:$sport -> $dip:$dport state:[$state] count:[$ipcnt{$sip}] subnet:[$subnet] subnet count:[$subcnt{$subnet}]")}
						}
					}
				} else {
					if ($config{DEBUG} >= 2) {logfile("debug: CT $proto: $sip:$sport -> $dip:$dport state:[$state] count:[$ipcnt{$sip}]")}
				}
			}
			close ($IN);
		}

		foreach my $ip (keys %ipcnt) {
			if (($ipcnt{$ip} > $config{CT_LIMIT}) and !&ignoreip($ip)) {
				my $tip = iplookup($ip);
				if (&ipblock($config{CT_PERMANENT},"(CT) IP $tip found to have $ipcnt{$ip} connections",$ip,"","inout",$config{CT_BLOCK_TIME},0,$iptext{$ip},"CT_LIMIT")) {
					if ($config{DEBUG} >= 1) {logfile("debug: CT $ip already blocked")}
				} else {
					if ($config{CT_EMAIL_ALERT}) {
						$0 = "lfd - (child) (CT) sending alert email for $ip";

						my @alert = slurp("/usr/local/csf/tpl/connectiontracking.txt");
						my $block = "Temporary Block for $config{CT_BLOCK_TIME} seconds [CT_LIMIT]";
						if ($config{CT_PERMANENT}) {$block = "Permanent Block [CT_LIMIT]"}

						my $allowip = &allowip($ip);
						if ($allowip == 1) {$block .= " (IP match in csf.allow, block may not work)"}
						if ($allowip == 2) {$block .= " (IP match in GLOBAL_ALLOW, block may not work)"}

						my @message;
						foreach my $line (@alert) {
							$line =~ s/\[ip\]/$tip/ig;
							$line =~ s/\[ipcount\]/$ipcnt{$ip}/ig;
							$line =~ s/\[iptext\]/$iptext{$ip}/ig;
							$line =~ s/\[temp\]/$block/ig;
							push @message, $line;
						}
						ConfigServer::Sendmail::relay("", "", @message);

						if ($config{X_ARF}) {
							$0 = "lfd - (child) sending X-ARF email for $ip";

							my @alert = slurp("/usr/local/csf/tpl/x-arf.txt");
							my @message;
							my $rfc3339 = strftime('%Y-%m-%dT%H:%M:%S%z',localtime);
							my $boundary = time;
							my $reportedfrom = "root\@$hostname";
							if ($config{X_ARF_TO}) {$config{LF_ALERT_TO} = $config{X_ARF_TO}}
							if ($config{X_ARF_FROM}) {$config{LF_ALERT_FROM} = $config{X_ARF_FROM}; $reportedfrom = $config{X_ARF_FROM}}
							my $iptype = "ipv".checkip(\$ip);

							my $abuseto = "";
							my $abusemsg = "";
							if ($iptype eq "ipv4" and $abuseip) {
								($abuseto, $abusemsg) = abuseip($ip);
								if ($abuseto eq "") {
									$abusemsg = "";
								}
								elsif ($config{X_ARF_ABUSE} and $config{X_ARF_FROM}) {
									if ($config{LF_ALERT_TO}) {
										$config{LF_ALERT_TO} .= ",".$abuseto;
									} else {
										$config{LF_ALERT_TO} = "root,".$abuseto;
									}
								}
							}

							foreach my $line (@alert) {
								$line =~ s/\[ip\]/$ip/ig;
								$line =~ s/\[abuseip\]/$abusemsg/ig;
								$line =~ s/\[iptype\]/$iptype/ig;
								$line =~ s/\[tip\]/$tip/ig;
								$line =~ s/\[ipcount\]/$ipcnt{$ip}/ig;
								$line =~ s/\[iptick\]/$config{LF_INTERVAL}/ig;
								$line =~ s/\[service\]/port-flood/ig;
								$line =~ s/\[csfversion\]/$version/ig;
								$line =~ s/\[reportedfrom\]/$reportedfrom/ig;
								$line =~ s/\[reportedid\]/$boundary\@$hostname/ig;
								$line =~ s/\[boundary\]/$boundary/ig;
								$line =~ s/\[text\]/$iptext{$ip}/ig;
								$line =~ s/\[RFC3339\]/$rfc3339/ig;
								push @message, $line;
							}
							ConfigServer::Sendmail::relay($config{LF_ALERT_TO}, $config{LF_ALERT_FROM}, @message);

							if ($config{DEBUG} >= 1) {logfile("debug: CT X-ARF email sent for $ip")}
						}

						if ($config{DEBUG} >= 1) {logfile("debug: CT alert email sent for $ip")}
					}
				}
			}
		}

		foreach my $subnet (keys %subcnt) {
			if ($config{DEBUG} >= 2) {logfile("debug: CT $subnet processing $subcnt{$subnet} entries")}
			my $fullsubnet = $subnet.".0/24";
			if (($subcnt{$subnet} > $config{CT_SUBNET_LIMIT}) and !&ignoreip($fullsubnet)) {
				my $tip = iplookup($fullsubnet);
				if (&ipblock($config{CT_PERMANENT},"(CT) subnet $tip found to have $subcnt{$subnet} connections",$fullsubnet,"","inout",$config{CT_BLOCK_TIME},0,$subtext{$subnet},"CT_SUBNET_LIMIT")) {
					if ($config{DEBUG} >= 1) {logfile("debug: CT $subnet already blocked")}
				} else {
					if ($config{CT_EMAIL_ALERT}) {
						$0 = "lfd - (child) (CT) sending alert email for $subnet";

						my @alert = slurp("/usr/local/csf/tpl/connectiontracking.txt");
						my $block = "Temporary Block for $config{CT_BLOCK_TIME} seconds [CT_LIMIT]";
						if ($config{CT_PERMANENT}) {$block = "Permanent Block [CT_LIMIT]"}

						my $allowip = &allowip($fullsubnet);
						if ($allowip == 1) {$block .= " (subnet match in csf.allow, block may not work)"}
						if ($allowip == 2) {$block .= " (subnet match in GLOBAL_ALLOW, block may not work)"}

						my @message;
						foreach my $line (@alert) {
							$line =~ s/\[ip\]/$tip/ig;
							$line =~ s/\[ipcount\]/$subcnt{$subnet}/ig;
							$line =~ s/\[iptext\]/$subtext{$subnet}/ig;
							$line =~ s/\[temp\]/$block/ig;
							push @message, $line;
						}
						ConfigServer::Sendmail::relay("", "", @message);

						if ($config{DEBUG} >= 1) {logfile("debug: CT alert email sent for $fullsubnet")}
					}
				}
			}
		}
		
		if ($tfail) {
			$config{CT_INTERVAL} = $config{CT_INTERVAL} * 1.5;
			sysopen (my $TEMPCONF, "/var/lib/csf/csf.tempconf", O_WRONLY | O_APPEND | O_CREAT) or &shutdown_child(__LINE__,"*Error* Cannot append out file: $!");
			flock ($TEMPCONF, LOCK_EX);
			print $TEMPCONF "CT_INTERVAL = \"$config{CT_INTERVAL}\"\n";
			close ( $TEMPCONF );
			logfile("CT_INTERVAL taking $alarm seconds, temporarily throttled to run every $config{CT_INTERVAL} seconds");
		}

		close ($THISLOCK );
		if ($config{DEBUG} >= 3) {$timer = &timer("stop","connectiontracking",$timer)}
		$0 = "lfd - (child) closing";
		exit;
	}
	return;
}
# end connectiontracking
###############################################################################
# start accounttracking
sub accounttracking {
	$SIG{CHLD} = 'IGNORE';
	unless (defined ($childpid = fork)) {
		&shutdown(__LINE__,"*Error* cannot fork: $!");
	} 
	$forks{$childpid} = 1;
	unless ($childpid) {
		my $timer = time;
		if ($config{DEBUG} >= 3) {$timer = &timer("start","accounttracking",$timer)}
		$0 = "lfd - (child) account tracking...";

		my $lockstr = "AT_INTERVAL";
		sysopen (my $THISLOCK, "/var/lib/csf/lock/$lockstr.lock", O_RDWR | O_CREAT) or &shutdown_child("*Error* Unable to open /var/lib/csf/lock/$lockstr.lock");
		flock ($THISLOCK, LOCK_EX | LOCK_NB) or &shutdown_child("*Lock Error* [$lockstr] still active - section skipped");
		print $THISLOCK time;

		my $report = "";
		foreach my $user (keys %newaccounttracking) {
			if (($config{AT_ALERT} eq "2") and ($newaccounttracking{$user}{uid} ne "0")) { next }
			if ($accounttracking{$user}{account} != 1) {
				if ($config{AT_NEW}) {
					$report .= "New account [$user] has been created with uid:[$newaccounttracking{$user}{uid}] gid:[$newaccounttracking{$user}{gid}] login:[$newaccounttracking{$user}{dir}] shell:[$newaccounttracking{$user}{shell}]\n";
				}
			} else {
				if ($config{AT_PASSWD} and ($newaccounttracking{$user}{passwd} ne $accounttracking{$user}{passwd})) {
					$report .= "Account [$user] password has changed\n";
				}
				if ($config{AT_UID} and ($newaccounttracking{$user}{uid} ne $accounttracking{$user}{uid})) {
					$report .= "Account [$user] uid has changed from [$accounttracking{$user}{uid}] to [$newaccounttracking{$user}{uid}]\n";
				}
				if ($config{AT_GID} and ($newaccounttracking{$user}{gid} ne $accounttracking{$user}{gid})) {
					$report .= "Account [$user] gid has changed from [$accounttracking{$user}{gid}] to [$newaccounttracking{$user}{gid}]\n";
				}
				if ($config{AT_DIR} and ($newaccounttracking{$user}{dir} ne $accounttracking{$user}{dir})) {
					$report .= "Account [$user] login directory has changed from [$accounttracking{$user}{dir}] to [$newaccounttracking{$user}{dir}]\n";
				}
				if ($config{AT_SHELL} and ($newaccounttracking{$user}{shell} ne $accounttracking{$user}{shell})) {
					$report .= "Account [$user] login shell has changed from [$accounttracking{$user}{shell}] to [$newaccounttracking{$user}{shell}]\n";
				}
			}
		}
		foreach my $user (keys %accounttracking) {
			if (($config{AT_ALERT} eq "2") and ($accounttracking{$user}{uid} ne "0")) { next }
			if ($config{AT_OLD} and ($newaccounttracking{$user}{account} != 1)) {
				$report .= "Existing account [$user] has been removed. Old settings uid:[$accounttracking{$user}{uid}] gid:[$accounttracking{$user}{gid}] login:[$accounttracking{$user}{dir}] shell:[$accounttracking{$user}{shell}]\n";
			}
		}
		if ($report ne "") {
			logfile("*Account Modification* Email sent");

			my @alert = slurp("/usr/local/csf/tpl/accounttracking.txt");
			my @message;
			foreach my $line (@alert) {
				$line =~ s/\[report\]/$report/ig;
				push @message, $line;
			}
			ConfigServer::Sendmail::relay("", "", @message);
		}			

		close ($THISLOCK );
		if ($config{DEBUG} >= 3) {$timer = &timer("stop","accounttracking",$timer)}
		$0 = "lfd - (child) closing";
		exit;
	}
	return;
}
# end accounttracking
###############################################################################
# start syslogcheck
sub syslogcheck {
	$SIG{CHLD} = 'IGNORE';
	unless (defined ($childpid = fork)) {
		&shutdown(__LINE__,"*Error* cannot fork: $!");
	} 
	$forks{$childpid} = 1;
	unless ($childpid) {
		my $timer = time;
		if ($config{DEBUG} >= 3) {$timer = &timer("start","syslogcheck",$timer)}
		$0 = "lfd - (child) SYSLOG check...";

		my $lockstr = "SYSLOG_CHECK";
		sysopen (my $THISLOCK, "/var/lib/csf/lock/$lockstr.lock", O_RDWR | O_CREAT) or &shutdown_child("*Error* Unable to open /var/lib/csf/lock/$lockstr.lock");
		flock ($THISLOCK, LOCK_EX | LOCK_NB) or &shutdown_child("*Lock Error* [$lockstr] still active - section skipped");
		print $THISLOCK time;

		logfile("*SYSLOG CHECK* Failed to detect check line [$syslogcheckcode] sent to SYSLOG");

		my @alert = slurp("/usr/local/csf/tpl/syslogalert.txt");
		my @message;
		foreach my $line (@alert) {
			$line =~ s/\[code\]/$syslogcheckcode/ig;
			$line =~ s/\[log\]/$config{SYSLOG_LOG}/ig;
			push @message, $line;
		}
		ConfigServer::Sendmail::relay("", "", @message);

		close ($THISLOCK );
		if ($config{DEBUG} >= 3) {$timer = &timer("stop","syslogcheck",$timer)}
		$0 = "lfd - (child) closing";
		exit;
	}
	return;
}
# end syslogcheck
###############################################################################
# start processtracking
sub processtracking
{
	$SIG{CHLD} = 'IGNORE';
	unless ( defined ( $childpid = fork ) )
	{
		&shutdown( __LINE__,"*Error* cannot fork: $!" );
	}

	$forks{$childpid} = 1;
	unless ($childpid) {
		my $timer = time;
		if ($config{DEBUG} >= 3) {$timer = &timer("start","processtracking",$timer)}
		$0 = "lfd - (child) process tracking...";

		my $lockstr = "PT_INTERVAL";
		sysopen (my $THISLOCK, "/var/lib/csf/lock/$lockstr.lock", O_RDWR | O_CREAT) or &shutdown_child("*Error* Unable to open /var/lib/csf/lock/$lockstr.lock");
		flock ($THISLOCK, LOCK_EX | LOCK_NB) or &shutdown_child("*Lock Error* [$lockstr] still active - section skipped");
		print $THISLOCK time;

		my %users;
		my %net;

		unless ( $config{GENERIC} )
		{
			opendir ( DIR, "/var/cpanel/users" );
			while ( my $user = readdir ( DIR ) )
			{
				if ($user =~ /^\./) { next }
				$users{$user} = 1;
			}
			closedir (DIR);
			$users{nobody} = 1;
		}

		foreach my $proto ( "udp","tcp","udp6","tcp6" )
		{
			open (my $IN, "<", "/proc/net/$proto");
			flock ($IN, LOCK_SH);
			while (<$IN>)
			{
				my @rec = split();
				if ( $rec[9] =~ /uid/ )
				{
					next
				}

				my ( $dip, $dport )	= split( /:/,$rec[2] );
				$dport				= hex( $dport );

				my ( $sip, $sport )	= split( /:/,$rec[1] );
				$sport 				= hex( $sport );

				if ( $dip == 0 or $sip == 0 )
				{
					next
				}

				$dip = ConfigServer::GetIPs::hex2ip( $dip );
				if ( $dip =~ /^0:0:0:0:0:ffff:(.*)$/ )
				{
					my $embed = ConfigServer::GetIPs::ipv4in6( $dip );
					if ( $embed =~ /^$ipv4reg$/ )
					{
						$dip = $embed
					}
				}

				$sip = ConfigServer::GetIPs::hex2ip($sip);
				if ($sip =~ /^0:0:0:0:0:ffff:(.*)$/) {
					my $embed = ConfigServer::GetIPs::ipv4in6($sip);
					if ($embed =~ /^$ipv4reg$/) {$sip = $embed}
				}

				if ($sip eq '0.0.0.1') { next }

				$net{$rec[9]}{proto} = $proto;
				$net{$rec[9]}{sport} = $sport;
				$net{$rec[9]}{sip} = $sip;
				$net{$rec[9]}{dport} = $dport;
				$net{$rec[9]}{dip} = $dip;
				if ($config{DEBUG} >= 4) {logfile("debug: PT $proto: $sip:$sport -> $dip:$dport")}
			}
			close ($IN);
		}

		open (my $IN,"<", "/proc/uptime");
		flock ($IN, LOCK_SH);
		my @up = <$IN>;
		close ($IN);
		chomp @up;
		my ($upsecs,undef) = split (/\s/,$up[0]);

		my %pids;
		if (! -z "/var/lib/csf/csf.temppids") {
			open (my $IN, "<", "/var/lib/csf/csf.temppids");
			flock ($IN, LOCK_SH);
			my @data = <$IN>;
			close ($IN);
			chomp @data;

			foreach my $line ( @data ) {
				my ($itemttl,$item) = split(/:/,$line);
				if (time - $itemttl < $config{LF_FLUSH}) {
					$pids{$item} = 1;
				}
			}
		}
		my %ignoreusers;
		if (! -z "/var/lib/csf/csf.tempusers") {
			open (my $IN, "<", "/var/lib/csf/csf.tempusers");
			flock ($IN, LOCK_SH);
			my @data = <$IN>;
			close ($IN);
			chomp @data;

			foreach my $line ( @data ) {
				my ($itemttl,$item) = split(/:/,$line);
				if (time - $itemttl < $config{LF_FLUSH}) {
					$ignoreusers{$item} = 1;
				}
			}
		}

		my %totproc;
		my %procres;
		my %sessions;
		opendir (PROCDIR, "/proc");
		while (my $pid = readdir(PROCDIR)) {
			if ($pid !~ /^\d+$/) { next }
			open (my $IN,"<", "/proc/$pid/status") or next;
			flock ($IN, LOCK_SH);
			my @status = <$IN>;
			close ($IN);
			chomp @status;
			my $user;
			my $uid;
			my $vmsize = 0;
			my $vmrss = 0;
			my $ppid = $pid;
			foreach my $line (@status) {
				if ($line =~ /^Uid:(.*)/) {
					my $uidline = $1;
					my @uids;
					foreach my $bit (split(/\s/,$uidline)) {
						if ($bit =~ /^(\d*)$/) {push @uids, $1}
					}
					$uid = $uids[-1];
					$user = getpwuid($uid);
				}
				if ($line =~ /^VmSize:\s+(\d+) kB$/) {$vmsize = $1}
				if ($line =~ /^VmRSS:\s+(\d+) kB$/) {$vmrss = $1}
				if ($line =~ /^PPid:\s+(\d+)$/) {
					$ppid = $1;
					if ($ppid == 1) {$ppid = $pid}
				}
			}

			if ($users{$user} or $config{GENERIC} or $config{PT_ALL_USERS}) {
				if ($pids{$pid}) { next }
				if ($skip{user}{$user}) { next }
				my $pmatch = 0;
				foreach my $item (keys %{$pskip{puser}}) {
					if ($user =~ /^$item$/) {
						$pmatch = 1;
						last;
					}
				}
				if ($pmatch) { next }

				my %printable = ( ( map { chr($_), unpack('H2', chr($_)) } (0..255) ), "\\"=>'\\', "\r"=>'r', "\n"=>'n', "\t"=>'t', "\""=>'"' ); ##no critic

				my $exe = readlink("/proc/$pid/exe");
				my $cwd = readlink("/proc/$pid/cwd");
				$exe =~ s/([\r\n\t\"\\\x00-\x1f\x7F-\xFF])/\\$printable{$1}/sg;
				$cwd =~ s/([\r\n\t\"\\\x00-\x1f\x7F-\xFF])/\\$printable{$1}/sg;
				if ($exe eq "") { next }

				if ($config{DEBUG} >= 4) {logfile("debug: PT exe = $exe")}
				my $exet = $exe;
				my $deleted = 0;
				if ($exe =~ /\(deleted\)/) {
					if ($ppid and ($ppid != $pid) and $pids{$ppid}) {
						my $pexe = readlink("/proc/$ppid/exe");
						$pexe =~ s/([\r\n\t\"\\\x00-\x1f\x7F-\xFF])/\\$printable{$1}/sg;
						if ($pexe =~ /\(deleted\)/) {
							if ($config{DEBUG} >= 2) {logfile("Process Tracking - Parent PID $ppid already reported for deleted $pid - ignored")}
							next;
						}
					}
					$deleted = 1;
					if ($config{PT_DELETED}) {
						$exet .= "\n\nThe file system shows this process is running an executable file that has been deleted. This typically happens when the original file has been replaced by a new file when the application is updated. To prevent this being reported again, restart the process that runs this executable file. See csf.conf and the PT_DELETED text for more information about the security implications of processes running deleted executable files.";
					} else { next }
				}

				open (my $CMDLINE,"<", "/proc/$pid/cmdline");
				flock ($CMDLINE, LOCK_SH);
				my $cmdline = <$CMDLINE>;
				close ($CMDLINE);
				chomp $cmdline;
				$cmdline =~ s/\0$//g;
				$cmdline =~ s/\0/ /g;
				$cmdline =~ s/\s+$//g;
				$cmdline =~ s/([\r\n\t\"\\\x00-\x1f\x7F-\xFF])/\\$printable{$1}/sg;

				open (my $STAT,"<", "/proc/$pid/stat") or next;
				flock ($STAT, LOCK_SH);
				my $pstatline = <$STAT>;
				close ($STAT);
				chomp $pstatline;
				my @pstat;
				if ($pstatline =~ /^\d+\s\(.*\)\s(.*)$/) {
					@pstat = split(/\s/,$1);
				} else { next }

				my $jiffsecs = $pstat[19] / $clock_ticks;
				my $uptime = int($upsecs - $jiffsecs);

				if ($config{PT_SSHDHUNG}) {
					if ($cmdline =~ /^sshd:\s+unknown\s+\[net|priv\]\s*$/) {
						if ($uptime > 60) {
							kill (9, $pid);
							logfile("*PT_SSHDHUNG* process pid:[$pid] cmd:[$cmdline] Uptime:[$uptime], killed");
							next;
						}
					}
				}

				if ($skip{exe}{$exe}) { next }

				$pmatch = 0;
				foreach my $item (keys %{$pskip{pexe}}) {
					if ($exe =~ /^$item$/) {
						$pmatch = 1;
						last;
					}
				}
				if ($pmatch) { next }

				if ($skip{cmd}{$cmdline}) { next }
				$pmatch = 0;
				foreach my $item (keys %{$pskip{pcmd}}) {
					if ($cmdline =~ /^$item$/) {
						$pmatch = 1;
						last;
					}
				}
				if ($pmatch) { next }

				if (($config{MESSENGER} and $user eq $config{MESSENGER_USER}) and ($cmdline =~ /^lfd (HTML|TEXT|HTTPS) messenger/)) { next }

				if ($config{PT_FORKBOMB}) {
					my $sid = $pstat[3];
					if ($sid > 1) {
						$sessions{$sid}{count}++;
						$sessions{$sid}{text} .= "PID:$pid PPID:$ppid SID:$sid User:$user EXE:$exe CMD:$cmdline\n";
						if ($sessions{$sid}{count} >= $config{PT_FORKBOMB}) {
							logfile("*PT_FORKBOMB* PID:$pid SID:$sid User:$user EXE:$exe CMD:$cmdline");
							my $text = $sessions{$sid}{text};
							delete $sessions{$sid};
							kill 9, "-$sid";

							my @alert = slurp("/usr/local/csf/tpl/forkbombalert.txt");
							my @message;
							foreach my $line (@alert) {
								$line =~ s/\[level\]/$config{PT_FORKBOMB}/ig;
								$line =~ s/\[text\]/$text/ig;
								push @message, $line;
							}
							ConfigServer::Sendmail::relay("", "", @message);
							next;
						}
					}
				}
				if ($user eq "root") { next }

				if ($config{PT_SKIP_HTTP}) {
					my $pgrp = $pstat[2];
					my $pgrpexe = readlink("/proc/$pgrp/exe");
					if (($pid ne $pgrp) and ($pgrpexe eq "/usr/local/apache/bin/httpd")) { next }
					if (($pid ne $pgrp) and ($pgrpexe eq "/usr/local/bin/httpd")) { next }
					if (($pid ne $pgrp) and ($pgrpexe eq "/usr/bin/httpd")) { next }
				}

				if ($user ne "nobody") {
					unless ($deleted) {
						$totproc{$user}{count}++;
						if ($totproc{$user}{pids} eq "") {
							$totproc{$user}{pids} = $pid;
						} else {
							$totproc{$user}{pids} .= ",$pid";
						}
						$totproc{$user}{text} .= "User:$user PID:$pid PPID:$ppid Run Time:$uptime(secs) Memory:$vmsize(kb) RSS:$vmrss(kb) exe:$exe cmd:$cmdline\n";
						$procres{$pid}{vmsize} = $vmsize;
						$procres{$pid}{vmrss} = $vmrss;
						$procres{$pid}{uptime} = $uptime;
						$procres{$pid}{user} = $user;
						$procres{$pid}{exe} = $exe;
						$procres{$pid}{exet} = $exet;
						$procres{$pid}{cmd} = $cmdline;
						$procres{$pid}{ppid} = $ppid;
					}
				}

				if ($uptime > $config{PT_LIMIT}) {
					my $suspect = 0;

					my @fd;
					opendir (DIR, "/proc/$pid/fd") or next;
					while (my $file = readdir (DIR)) {
						if ($file =~ /^\./) { next }
						push (@fd, readlink("/proc/$pid/fd/$file"));
					}
					closedir (DIR);

					my $files;
					my $sockets;
					foreach my $file (@fd) {
						if ($file =~ /^socket:\[?([0-9]+)\]?$/) {
							my $ino = $1;
							if ($net{$ino}) {
								$sockets .= "$net{$ino}{proto}: $net{$ino}{sip}:$net{$ino}{sport} -> $net{$ino}{dip}:$net{$ino}{dport}\n";
								if ($suspect != 2) {$suspect = 1}
								if ($config{PT_SKIP_HTTP} and $net{$ino}{sport} =~ /^(80|443)$/) {$suspect = 2}
							}
						}
						if ($file =~ /^socket|pipe/) { next }
						$files .= $file."\n";
					}
					if ($suspect == 2) {$suspect = 0}

					if ($suspect or $deleted) {
						my $sexe = readlink("/proc/$pid/exe");
						if ($sexe eq "") { next }

						logfile("*Suspicious Process* PID:$pid PPID:$ppid User:$user Uptime:$uptime secs EXE:$exe CMD:$cmdline");

						sysopen (my $TEMPPIDS, "/var/lib/csf/csf.temppids", O_WRONLY | O_APPEND | O_CREAT) or &shutdown_child(__LINE__,"*Error* Cannot append out file: $!");
						flock ($TEMPPIDS, LOCK_EX);
						print $TEMPPIDS time.":$pid\n";
						if ($deleted and $ppid and ($ppid != $pid)) {
							my $pexe = readlink("/proc/$ppid/exe");
							$pexe =~ s/([\r\n\t\"\\\x00-\x1f\x7F-\xFF])/\\$printable{$1}/sg;
							if ($pexe =~ /\(deleted\)/) {
								print $TEMPPIDS time.":$ppid\n";
								$pids{$ppid} = 1;
							}
						}
						close ($TEMPPIDS);

						$0 = "lfd - (child) (PT) sending alert email for process $pid";

						open (my $IN,"<", "/proc/$pid/maps");
						flock ($IN, LOCK_SH);
						my @maps = <$IN>;
						close ($IN);
						chomp @maps;
						my $maps;
						foreach my $line (@maps) {$maps .= $line."\n"}

						my @alert = slurp("/usr/local/csf/tpl/processtracking.txt");
						my @message;
						foreach my $line (@alert) {
							$line =~ s/\[pid\]/$pid (Parent PID:$ppid)/ig;
							$line =~ s/\[user\]/$user/ig;
							$line =~ s/\[uptime\]/$uptime/ig;
							$line =~ s/\[sockets\]/$sockets/ig;
							$line =~ s/\[files\]/$files/ig;
							$line =~ s/\[maps\]/$maps/ig;
							$line =~ s/\[exe\]/$exet/ig;
							$line =~ s/\[cmdline\]/$cmdline/ig;
							push @message, $line;
						}
						ConfigServer::Sendmail::relay("", "", @message);

						if ($deleted and $config{PT_DELETED_ACTION} and -e "$config{PT_DELETED_ACTION}" and -x "$config{PT_DELETED_ACTION}") {
							$SIG{CHLD} = 'IGNORE';
							unless (defined ($ptchildpid = fork)) {
								&shutdown_child(__LINE__,"*Error* cannot fork: $!");
							} 
							unless ($ptchildpid) {
								system($config{PT_DELETED_ACTION},$exe,$pid,$user,$ppid);
								logfile("Executed PT_DELETED_ACTION for PID:$pid");
								exit;
							}
						}

					}
				}
			}
		}
		if ($config{PT_USERPROC}) {
			$0 = "lfd - (child) (PT) checking user processes";
			foreach my $user (keys %totproc) {
				if ($ignoreusers{$user}) { next }
				if ($totproc{$user}{count} > $config{PT_USERPROC}) {
					my $kill = "Not killed";
					if ($config{PT_USERKILL}) {
						foreach my $pid (split(/\,/,$totproc{$user}{pids})) {
							kill (9, $pid);
						}
						$kill = "Killed";
					} else {
						sysopen (my $TEMPUSERS, "/var/lib/csf/csf.tempusers", O_WRONLY | O_APPEND | O_CREAT) or &shutdown_child(__LINE__,"*Error* Cannot append out file: $!");
						flock ($TEMPUSERS, LOCK_EX);
						print $TEMPUSERS time.":$user\n";
						close ($TEMPUSERS);
					}

					logfile("*Excessive Processes* User:$user Kill:$config{PT_USERKILL} Process Count:$totproc{$user}{count}");

					if (!$config{PT_USERKILL} or ($config{PT_USERKILL} and $config{PT_USERKILL_ALERT})) {
						my @alert = slurp("/usr/local/csf/tpl/usertracking.txt");
						my @message;
						foreach my $line (@alert) {
							$line =~ s/\[user\]/$user/ig;
							$line =~ s/\[count\]/$totproc{$user}{count} \($kill\)/ig;
							$line =~ s/\[text\]/$totproc{$user}{text}/ig;
							$line =~ s/\[kill\]/$kill/ig;
							push @message, $line;
						}
						ConfigServer::Sendmail::relay("", "", @message);
					}
					if ($config{PT_USER_ACTION} and -e "$config{PT_USER_ACTION}" and -x "$config{PT_USER_ACTION}") {
						$SIG{CHLD} = 'IGNORE';
						unless (defined ($ptchildpid = fork)) {
							&shutdown_child(__LINE__,"*Error* cannot fork: $!");
						} 
						unless ($ptchildpid) {
							system($config{PT_USER_ACTION},$totproc{$user}{pids});
							exit;
						}
					}
				}
			}
		}

        # #
        #   @note           Keep the log format below stable. Users may rely on
        #                   regex patterns to match these entries for alerts or
        #                   e-mail processing, so changing the format may break
        #                   existing rules for a user.
        # #

		if ($config{PT_USERMEM} or $config{PT_USERRSS} or $config{PT_USERTIME})
        {
			foreach my $pid (keys %procres)
            {
				my $report = 0;
				my $resource;
				my $level;

				if ($config{PT_USERMEM} and ($procres{$pid}{vmsize} > ($config{PT_USERMEM} * 1024))) {
					$report = 1;
					$resource = "Virtual Memory Size";
					my $memsize = int($procres{$pid}{vmsize} / 1024);
					$level = "$memsize > $config{PT_USERMEM} (MB)";
					logfile("*User Processing* PID:$pid Kill:$config{PT_USERKILL} User:$procres{$pid}{user} VM:$memsize(MB) EXE:$procres{$pid}{exe} CMD:$procres{$pid}{cmd}");
				}
				if ($config{PT_USERRSS} and ($procres{$pid}{vmrss} > ($config{PT_USERRSS} * 1024))) {
					$report = 1;
					$resource = "RSS Memory Size";
					my $memsize = int($procres{$pid}{vmrss} / 1024);
					$level = "$memsize > $config{PT_USERRSS} (MB)";
					logfile("*User Processing* PID:$pid Kill:$config{PT_USERKILL} User:$procres{$pid}{user} RSS:$memsize(MB) EXE:$procres{$pid}{exe} CMD:$procres{$pid}{cmd}");
				}
				if ($config{PT_USERTIME} and ($procres{$pid}{uptime} > $config{PT_USERTIME})) {
					$report = 1;
					$resource = "Process Time";
					$level = "$procres{$pid}{uptime} > $config{PT_USERTIME} (seconds)";
					logfile("*User Processing* PID:$pid Kill:$config{PT_USERKILL} User:$procres{$pid}{user} Time:$procres{$pid}{uptime} EXE:$procres{$pid}{exe} CMD:$procres{$pid}{cmd}");
				}
				if ($report) {
					my $kill = "No";
					if ($config{PT_USERKILL}) {
						kill (9, $pid);
						$kill = "Yes";
					} else {
						sysopen (my $TEMPPIDS, "/var/lib/csf/csf.temppids", O_WRONLY | O_APPEND | O_CREAT) or &shutdown_child(__LINE__,"*Error* Cannot append out file: $!");
						flock ($TEMPPIDS, LOCK_EX);
						print $TEMPPIDS time.":$pid\n";
						close ($TEMPPIDS);
					}

					if (!$config{PT_USERKILL} or ($config{PT_USERKILL} and $config{PT_USERKILL_ALERT})) {
						my @alert = slurp("/usr/local/csf/tpl/resalert.txt");
						my @message;
						foreach my $line (@alert) {
							$line =~ s/\[user\]/$procres{$pid}{user}/ig;
							$line =~ s/\[cmd\]/$procres{$pid}{cmd}/ig;
							$line =~ s/\[exe\]/$procres{$pid}{exet}/ig;
							$line =~ s/\[resource\]/$resource/ig;
							$line =~ s/\[level\]/$level/ig;
							$line =~ s/\[kill\]/$kill/ig;
							$line =~ s/\[pid\]/$pid (Parent PID:$procres{$pid}{ppid})/ig;
							push @message, $line;
						}
						ConfigServer::Sendmail::relay("", "", @message);
					}

					if ($config{PT_USER_ACTION} and -e "$config{PT_USER_ACTION}" and -x "$config{PT_USER_ACTION}") {
						$SIG{CHLD} = 'IGNORE';
						unless (defined ($ptchildpid = fork)) {
							&shutdown_child(__LINE__,"*Error* cannot fork: $!");
						} 
						unless ($ptchildpid) {
							system($config{PT_USER_ACTION},$pid);
							exit;
						}
					}
				}
			}
		}

		close ($THISLOCK );
		if ($config{DEBUG} >= 3) {$timer = &timer("stop","processtracking",$timer)}
		$0 = "lfd - (child) closing";
		exit;
	}
	return;
}
# end processtracking
###############################################################################
# start sshalert
sub sshalert {
	my $account = shift;
	my $ip = shift;
	my $method = shift;
	my $text = shift;

	$SIG{CHLD} = 'IGNORE';
	unless (defined ($childpid = fork)) {
		&shutdown(__LINE__,"*Error* cannot fork: $!");
	} 
	$forks{$childpid} = 1;
	unless ($childpid) {
		my $timer = time;
		if ($config{DEBUG} >= 3) {$timer = &timer("start","sshalert",$timer)}
		logfile("*SSH login* from $ip into the $account account using $method authentication");

		$0 = "lfd - (child) sending SSH login alert email for $ip";

		my @alert = slurp("/usr/local/csf/tpl/sshalert.txt");
		my $tip = iplookup($ip);
		my @message;
		foreach my $line (@alert) {
			$line =~ s/\[ip\]/$tip/ig;
			$line =~ s/\[account\]/$account/ig;
			$line =~ s/\[method\]/$method/ig;
			$line =~ s/\[text\]/$text/ig;
			push @message, $line;
		}
		ConfigServer::Sendmail::relay("", "", @message);

		if ($config{DEBUG} >= 3) {$timer = &timer("stop","sshalert",$timer)}
		$0 = "lfd - child closing";
		exit;
	}
	return;
}
# end sshalert
###############################################################################
# start sualert
sub sualert {
	my $suto = shift;
	my $sufrom = shift;
	my $status = shift;
	my $text = shift;

	$SIG{CHLD} = 'IGNORE';
	unless (defined ($childpid = fork)) {
		&shutdown(__LINE__,"*Error* cannot fork: $!");
	} 
	$forks{$childpid} = 1;
	unless ($childpid) {
		my $timer = time;
		if ($config{DEBUG} >= 3) {$timer = &timer("start","sualert",$timer)}
		logfile("*SU login* from account $sufrom to account $suto: $status");

		$0 = "lfd - (child) sending SU login alert email from $sufrom to $suto";

		my @alert = slurp("/usr/local/csf/tpl/sualert.txt");
		my @message;
		foreach my $line (@alert) {
			$line =~ s/\[to\]/$suto/ig;
			$line =~ s/\[from\]/$sufrom/ig;
			$line =~ s/\[status\]/$status/ig;
			$line =~ s/\[text\]/$text/ig;
			push @message, $line;
		}
		ConfigServer::Sendmail::relay("", "", @message);

		if ($config{DEBUG} >= 3) {$timer = &timer("stop","sualert",$timer)}
		$0 = "lfd - child closing";
		exit;
	}
	return;
}
# end sualert
###############################################################################
# start sudoalert
sub sudoalert {
	my $suto = shift;
	my $sufrom = shift;
	my $status = shift;
	my $text = shift;

	$SIG{CHLD} = 'IGNORE';
	unless (defined ($childpid = fork)) {
		&shutdown(__LINE__,"*Error* cannot fork: $!");
	} 
	$forks{$childpid} = 1;
	unless ($childpid) {
		my $timer = time;
		if ($config{DEBUG} >= 3) {$timer = &timer("start","sudoalert",$timer)}
		logfile("*SUDO login* from account $sufrom to account $suto: $status");

		$0 = "lfd - (child) sending SU login alert email from $sufrom to $suto";

		my @alert = slurp("/usr/local/csf/tpl/sudoalert.txt");
		my @message;
		foreach my $line (@alert) {
			$line =~ s/\[to\]/$suto/ig;
			$line =~ s/\[from\]/$sufrom/ig;
			$line =~ s/\[status\]/$status/ig;
			$line =~ s/\[text\]/$text/ig;
			push @message, $line;
		}
		ConfigServer::Sendmail::relay("", "", @message);

		if ($config{DEBUG} >= 3) {$timer = &timer("stop","sudoalert",$timer)}
		$0 = "lfd - child closing";
		exit;
	}
	return;
}
# end sudoalert
###############################################################################
# start webminalert
sub webminalert {
	my $account = shift;
	my $ip = shift;
	my $text = shift;

	$SIG{CHLD} = 'IGNORE';
	unless (defined ($childpid = fork)) {
		&shutdown(__LINE__,"*Error* cannot fork: $!");
	} 
	$forks{$childpid} = 1;
	unless ($childpid) {
		my $timer = time;
		if ($config{DEBUG} >= 3) {$timer = &timer("start","webminalert",$timer)}
		logfile("*Webmin login* from $ip into the $account account");

		$0 = "lfd - (child) sending Webmin login alert email for $ip";

		my @alert = slurp("/usr/local/csf/tpl/webminalert.txt");
		my $tip = iplookup($ip);
		my @message;
		foreach my $line (@alert) {
			$line =~ s/\[ip\]/$tip/ig;
			$line =~ s/\[account\]/$account/ig;
			$line =~ s/\[text\]/$text/ig;
			push @message, $line;
		}
		ConfigServer::Sendmail::relay("", "", @message);

		if ($config{DEBUG} >= 3) {$timer = &timer("stop","webminalert",$timer)}
		$0 = "lfd - child closing";
		exit;
	}
	return;
}
# end webminalert
###############################################################################
# start consolealert
sub consolealert {
	my $logline = shift;

	$SIG{CHLD} = 'IGNORE';
	unless (defined ($childpid = fork)) {
		&shutdown(__LINE__,"*Error* cannot fork: $!");
	} 
	$forks{$childpid} = 1;
	unless ($childpid) {
		my $timer = time;
		if ($config{DEBUG} >= 3) {$timer = &timer("start","consolealert",$timer)}
		logfile("*CONSOLE login* to root");

		$0 = "lfd - (child) sending console login alert email";

		my @alert = slurp("/usr/local/csf/tpl/consolealert.txt");
		my @message;
		foreach my $line (@alert) {
			$line =~ s/\[line\]/$logline/ig;
			push @message, $line;
		}
		ConfigServer::Sendmail::relay("", "", @message);

		if ($config{DEBUG} >= 3) {$timer = &timer("stop","consolealert",$timer)}
		$0 = "lfd - child closing";
		exit;
	}
	return;
}
# end consolealert
###############################################################################
# start cpanelalert
sub cpanelalert {
	my $ip = shift;
	my $user = shift;
	my $text = shift;

	$SIG{CHLD} = 'IGNORE';
	unless (defined ($childpid = fork)) {
		&shutdown(__LINE__,"*Error* cannot fork: $!");
	} 
	$forks{$childpid} = 1;
	unless ($childpid) {
		my $timer = time;
		if ($config{DEBUG} >= 3) {$timer = &timer("start","cpanelalert",$timer)}
		logfile("*WHM/cPanel $user access* from $ip");

		$0 = "lfd - (child) sending WHM/cPanel access alert email for $ip";

		my @alert = slurp("/usr/local/csf/tpl/cpanelalert.txt");
		my $tip = iplookup($ip);
		my @message;
		foreach my $line (@alert) {
			$line =~ s/\[ip\]/$tip/ig;
			$line =~ s/\[user\]/$user/ig;
			$line =~ s/\[text\]/$text/ig;
			push @message, $line;
		}
		ConfigServer::Sendmail::relay("", "", @message);

		if ($config{LF_CPANEL_ALERT_ACTION} and -e "$config{LF_CPANEL_ALERT_ACTION}" and -x "$config{LF_CPANEL_ALERT_ACTION}") {
			$0 = "lfd - (child) running LF_CPANEL_ALERT_ACTION";
			system($config{LF_CPANEL_ALERT_ACTION},$ip,$user,$tip);
		}

		if ($config{DEBUG} >= 3) {$timer = &timer("stop","cpanelalert",$timer)}
		$0 = "lfd - child closing";
		exit;
	}
	return;
}
# end cpanelalert
###############################################################################
# start scriptalert
sub scriptalert {
	my $path = shift;
	my $count = shift;
	my $mails = shift;
	my $text;
	my $files;

	$SIG{CHLD} = 'IGNORE';
	unless (defined ($childpid = fork)) {
		&shutdown(__LINE__,"*Error* cannot fork: $!");
	} 
	$forks{$childpid} = 1;
	unless ($childpid) {
		my $timer = time;
		if ($config{DEBUG} >= 3) {$timer = &timer("start","scriptalert",$timer)}
		if ($skipscript{$path}) {
			logfile("*Script Alert* - A script in '$path' has sent an email $count times within the last hour - ignored");
			exit;
		}
		logfile("*Script Alert* - A script in '$path' has sent an email $count times within the last hour");

		$0 = "lfd - (child) identifying possible email scripts";

		opendir (DIR, "$path");
		while (my $file = readdir (DIR)) {
			if ($file =~ /\.(php([\ds]?)|phtml|cgi|pl|pm|sh|py)$/) {
				open (my $IN, "<", "$path/$file");
				flock ($IN, LOCK_SH);
				while (my $line = <$IN>) {
					chomp $line;
					if ($line =~ /mail\s*\(/) {$files .= "'$path/$file'\n"; last;}
					if ($line =~ /sendmail/) {$files .= "'$path/$file'\n"; last;}
					if ($line =~ /exim/) {$files .= "'$path/$file'\n"; last;}
				}
				close ($IN);
			}
		}
		closedir (DIR);

		if ($config{LF_SCRIPT_PERM}) {
			if (-l $path) {
				logfile("'$path' is a symlink - *not* disabled by LF_SCRIPT_PERM");
				$files .= "\nDirectory '$path' is a symlink - *not* disabled\n";
			} else {
				my $perms = sprintf "%04o", (stat($path))[2] & oct("00777");
				$files .= "\nDirectory '$path' has been disabled with 000 permissions.\n\nTo restore the permissions use:\nchattr -i $path\nchmod $perms $path\n";
				chmod (0000,$path);
				system($config{CHATTR},"+i",$path);
				logfile("'$path' has been disabled");
			}
		}

		$0 = "lfd - (child) sending script alert";

		my @alert = slurp("/usr/local/csf/tpl/scriptalert.txt");
		my @message;
		foreach my $line (@alert) {
			$line =~ s/\[path\]/\'$path\'/ig;
			$line =~ s/\[count\]/$count/ig;
			$line =~ s/\[emails\]/$mails/ig;
			$line =~ s/\[scripts\]/$files/ig;
			push @message, $line;
		}
		ConfigServer::Sendmail::relay("", "", @message);

		if ($config{LF_SCRIPT_ACTION} and -e $config{LF_SCRIPT_ACTION} and -x $config{LF_SCRIPT_ACTION}) {
			$0 = "lfd - (child) running LF_SCRIPT_ACTION";
			system($config{LF_SCRIPT_ACTION},$path,$count,$mails,$files);
		}

		if ($config{DEBUG} >= 3) {$timer = &timer("stop","scriptalert",$timer)}
		$0 = "lfd - child closing";
		exit;
	}
	return;
}
# end scriptalert
###############################################################################
# start relayalert
sub relayalert {
	my $ip = shift;
	my $cnt = shift;
	my $check = shift;
	my $mails = shift;

	$SIG{CHLD} = 'IGNORE';
	unless (defined ($childpid = fork)) {
		&shutdown(__LINE__,"*Error* cannot fork: $!");
	} 
	$forks{$childpid} = 1;
	unless ($childpid) {
		my $timer = time;
		if ($config{DEBUG} >= 3) {$timer = &timer("start","relayalert",$timer)}

		logfile("*Exceeded $check limit* from $ip ($cnt in the last hour)");

		$0 = "lfd - (child) reporting exceeded $check limit";

		my $tip = $ip;
		my $type = "$check, Local Account";
		if ($ip =~ /^127\./) {
			$type = "$check, IPv4 localhost";
		}
		elsif ($ip eq "::1") {
			$type = "$check, IPv6 localhost";
		}
		elsif (checkip(\$ip)) {
			$tip = iplookup($ip);
			$type = "$check, Remote IP";
		}

		if ($config{"RT\_$check\_BLOCK"}) {
			if (checkip(\$ip) and !&ignoreip($ip)) {
				my $perm = 0;
				if ($config{"RT\_$check\_BLOCK"} == 1) {$perm = 1}
				if (&ipblock($perm,"$tip $check limit exceeded",$ip,$ports{smtpauth},"in",$config{"RT\_$check\_BLOCK"},0,$mails,"RT\_$check\_LIMIT")) {
					if ($config{DEBUG} >= 1) {logfile("debug: $ip already blocked")}
				}
			}
		}

		my @alert = slurp("/usr/local/csf/tpl/relayalert.txt");
		my $block = "No";
		if ($config{"RT\_$check\_BLOCK"} == 1) {$block = "Permanent Block [RT\_$check\_LIMIT]"}
		if ($config{"RT\_$check\_BLOCK"} > 1) {$block = "Temporary Block for ".$config{"RT\_$check\_BLOCK"}." seconds [RT\_$check\_LIMIT]"}

		my $allowip = &allowip($ip);
		if ($allowip == 1 and $block ne "No") {$block .= " (IP match in csf.allow, block may not work)"}
		if ($allowip == 2 and $block ne "No") {$block .= " (IP match in GLOBAL_ALLOW, block may not work)"}

		my @message;
		foreach my $line (@alert) {
			$line =~ s/\[ip\]/$tip/ig;
			$line =~ s/\[block\]/$block/ig;
			$line =~ s/\[check\]/$check/ig;
			$line =~ s/\[type\]/$type/ig;
			$line =~ s/\[count\]/$cnt/ig;
			$line =~ s/\[emails\]/$mails/ig;
			push @message, $line;
		}
		ConfigServer::Sendmail::relay("", "", @message);

		if ($config{RT_ACTION} and -e "$config{RT_ACTION}" and -x "$config{RT_ACTION}") {
			$0 = "lfd - (child) running RT_ACTION";
			system($config{RT_ACTION},$ip,$check,$block,$cnt,$mails);
		}

		if ($config{DEBUG} >= 3) {$timer = &timer("stop","relayalert",$timer)}
		$0 = "lfd - child closing";
		exit;
	}
	return;
}
# end relayalert
###############################################################################
# start portknocking
sub portknocking {
	my $ip = shift;
	my $port = shift;

	$SIG{CHLD} = 'IGNORE';
	unless (defined ($childpid = fork)) {
		&shutdown(__LINE__,"*Error* cannot fork: $!");
	} 
	$forks{$childpid} = 1;
	unless ($childpid) {
		my $timer = time;
		if ($config{DEBUG} >= 3) {$timer = &timer("start","portknocking",$timer)}
		logfile("*Port Knocking* port $port opened by $ip");

		$0 = "lfd - (child) sending Port Knocking alert email for $ip";

		my @alert = slurp("/usr/local/csf/tpl/portknocking.txt");
		my $tip = iplookup($ip);
		my @message;
		foreach my $line (@alert) {
			$line =~ s/\[ip\]/$tip/ig;
			$line =~ s/\[port\]/$port/ig;
			push @message, $line;
		}
		ConfigServer::Sendmail::relay("", "", @message);

		if ($config{DEBUG} >= 3) {$timer = &timer("stop","portknocking",$timer)}
		$0 = "lfd - child closing";
		exit;
	}
	return;
}
# end portknocking
###############################################################################
# start blocklist
sub blocklist {
	$SIG{CHLD} = 'IGNORE';
	unless (defined ($childpid = fork)) {
		&shutdown(__LINE__,"*Error* cannot fork: $!");
	} 
	$forks{$childpid} = 1;
	unless ($childpid) {
		my $timer = time;
		if ($config{DEBUG} >= 3) {$timer = &timer("start","blocklist",$timer)}
		$0 = "lfd - retrieving blocklists";

		my $lockstr = "BLOCKLISTS";
		sysopen (my $THISLOCK, "/var/lib/csf/lock/$lockstr.lock", O_RDWR | O_CREAT) or &shutdown_child("*Error* Unable to open /var/lib/csf/lock/$lockstr.lock");
		flock ($THISLOCK, LOCK_EX | LOCK_NB) or &shutdown_child("*Lock Error* [$lockstr] still active - section skipped");
		print $THISLOCK time;

		$0 = "lfd - retrieving blocklists (waiting for list lock)";
		&listlock("lock");

		my $skipcxs;
		foreach my $name (keys %blocklists) {
			if ($skipcxs) { next }
			my $getlist = 0;
			my $verbose = 1;

			if ($name =~ /^CXS_/ and $blocklists{$name}{url} =~ /download\.configserver\.com/) {
				$blocklists{$name}{interval} = 600;
				$verbose = 0;
			}
			if (-e "/var/lib/csf/csf.block.$name") {
				my $mtime = (stat("/var/lib/csf/csf.block.$name"))[9];
				my $listtime = (time - $mtime);
				if ($listtime >= $blocklists{$name}{interval}) {$getlist = 1}
			} else {$getlist = 1}

			if ($getlist and ($name eq "SPAMDROP" or $name eq "SPAMEDROP")) {
				my $tmpfile = "/var/lib/csf/$name.tmp";
				if (-e $tmpfile) {
					my $mtime = (stat($tmpfile))[9];
					my $listtime = (time - $mtime);
					if ($listtime < 7200) {
						logfile("Unable to retrieve blocklist $name for the next ".(7200 - $listtime)." secs");
						$getlist = 0;
					} else { unlink $tmpfile}
				} else {
					sysopen (my $OUT, $tmpfile, O_WRONLY | O_CREAT);
					flock ($OUT, LOCK_EX);
					print $OUT time;
					close ($OUT);
				}
			}

			if ($getlist) {
				$0 = "lfd - retrieving blocklist $name";
				my ($status, $text) = $urlget->urlget($blocklists{$name}{url});
				if ($status) {
					logfile("Unable to retrieve blocklist $name - $text");
					if ($name =~ /^CXS_/ and $text =~ /Forbidden/) {
						logfile("CXS Reputation service disabled [$text]");
						$skipcxs = 1;
						unlink "/etc/cxs/cxs.reputation";
					}
					next;
				}

				my $blcidr = Net::CIDR::Lite->new;
				eval {local $SIG{__DIE__} = undef; $blcidr->add_any("127.0.0.1")};
				my $blcidr6 = Net::CIDR::Lite->new;
				eval {local $SIG{__DIE__} = undef; $blcidr6->add("::1/128")};
				foreach my $bl (keys %blocklists) {
					if ($bl eq $name) { next }
					if (-e "/var/lib/csf/csf.block.$bl") {
						sysopen (my $BLOCK, "/var/lib/csf/csf.block.$bl", O_RDWR | O_CREAT) or &shutdown_child(__LINE__,"*Error* Cannot open out file: $!");
						flock ($BLOCK, LOCK_SH);
						while (my $ipstr = <$BLOCK>) {
							chomp $ipstr;
							my $iptype = checkip(\$ipstr);
							if ($iptype == 4) {
								eval {local $SIG{__DIE__} = undef; $blcidr->add_any($ipstr)};
							}
							elsif ($iptype == 6 and $config{IPV6}) {
								eval {local $SIG{__DIE__} = undef; $blcidr6->add_any($ipstr)};
							}
						}
						close ($BLOCK);
					}
				}

				if (&csflock) {&lockfail("BLOCKLIST")}
				if ($verbose) {logfile("Retrieved and blocking blocklist $name IP address ranges")}
				my $drop = $config{DROP};
				if ($config{DROP_IP_LOGGING}) {$drop = "BLOCKDROP"}

				if ($text =~ m[^PK\x03\x04] or $text =~ m[^PK\x05\x06] or $text =~ m[^PK\x07\x08]) {
					sysopen (my $BLOCK, "/var/lib/csf/csf.block.${name}.zip", O_WRONLY | O_CREAT) or &shutdown_child(__LINE__,"*Error* Cannot open out file: $!");
					flock ($BLOCK, LOCK_EX);
					print $BLOCK $text;
					close ($BLOCK);
					my @data;
					eval {
						local $SIG{__DIE__} = undef;
						local $SIG{'ALRM'} = sub {die};
						alarm(180);
						@data = &syscommand(__LINE__,$config{UNZIP},"-p","/var/lib/csf/csf.block.${name}.zip");
						alarm(0);
					};
					alarm(0);
					if ($@) {
						logfile("CC Error: Unable to unzip Blocklist $name [/var/lib/csf/csf.block.${name}.zip] - timeout");
						$text = "";
					} else {
						logfile("CC: Unzipped Blocklist $name [/var/lib/csf/csf.block.${name}.zip]");
						$text = join("\n",@data);
					}
				}

				sysopen (my $BLOCK, "/var/lib/csf/csf.block.$name", O_WRONLY | O_CREAT) or &shutdown_child(__LINE__,"*Error* Cannot open out file: $!");
				flock ($BLOCK, LOCK_EX);
				seek ($BLOCK, 0, 0);
				truncate ($BLOCK, 0);
				my $count = 0;
				my @blocklist = split (/\n/,$text);
				my %seen;
				my @uniqueips = grep { ! $seen{ $_ }++ } @blocklist;
				if ($config{FASTSTART}) {$faststart = 1}
				foreach my $line (@uniqueips) {
					if ($line =~ /^\#/) { next }

					# Spamhaus JSON (NDJSON) format is supported alongside text; e.g.
					# {"cidr":"1.10.16.0/20","sblid":"SBL256894","rir":"apnic"}
					if ($line =~ /"cidr"\s*:\s*"([^"]+)"/) { $line = $1 }

					if ($line =~ /($ipv4reg(\/\d+)?)/) {
						my $iprange = $1;
						if ($name eq "DSHIELD" and $iprange !~/\/24/) {$iprange .= "/24"}
						if (checkip(\$iprange)) {
							my $skip = 0;
							eval {local $SIG{__DIE__} = undef; $skip = $blcidr->find($iprange)};
							if ($skip) {
								if ($config{DEBUG} >= 1) {logfile("debug: BLOCKLIST [$name] duplicate skipped: [$iprange]")}
								next;
							}
							$count++;
							if ($blocklists{$name}{max} > 0 and $count > $blocklists{$name}{max}) {last}
							print $BLOCK "$iprange\n";
						}
					}
					elsif ($line =~ /($ipv6reg(\/\d+)?)/) {
						my $iprange = $1;
						if (checkip(\$iprange)) {
							my $skip = 0;
							eval {local $SIG{__DIE__} = undef; $skip = $blcidr6->find($iprange)};
							if ($skip) {
								if ($config{DEBUG} >= 1) {logfile("debug: BLOCKLIST [$name] duplicate skipped: [$iprange]")}
								next;
							}
							$count++;
							if ($blocklists{$name}{max} > 0 and $count > $blocklists{$name}{max}) {last}
							print $BLOCK "$iprange\n";
						}
					}
				}
				close ($BLOCK);

				if ($config{LF_IPSET}) {
					open (my $BLOCK, "<", "/var/lib/csf/csf.block.$name");
					flock ($BLOCK, LOCK_SH);
					my @ipset6;
					while (my $line = <$BLOCK>) {
						chomp $line;
						if ($line =~ /^\#/) { next }
						if ($line =~ /($ipv4reg(\/\d+)?)/) {
							my $iprange = $1;
							push @ipset,"add new_$name $iprange\n";
						}
						elsif ($line =~ /($ipv6reg(\/\d+)?)/) {
							my $iprange = $1;
							push @ipset6,"add new_6_$name $iprange\n";
						}
					}
					close ($BLOCK);
					&ipsetrestore("new_$name");
					&ipsetswap("new_$name","bl_$name");
					if ($config{IPV6}) {
						@ipset = @ipset6;
						&ipsetrestore("new_6_$name");
						&ipsetswap("new_6_$name","bl_6_$name");
					}
				} else {
					if ($config{SAFECHAINUPDATE}) {
						&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -N NEW$name");
					} else {
						&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -F $name");
					}
					if ($config{IPV6}) {
						if ($config{SAFECHAINUPDATE}) {
							&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -N NEW$name");
						} else {
							&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -F $name");
						}
					}
					open (my $BLOCK, "<", "/var/lib/csf/csf.block.$name");
					flock ($BLOCK, LOCK_SH);
					while (my $line = <$BLOCK>) {
						chomp $line;
						if ($line =~ /^\#/) { next }
						if ($line =~ /($ipv4reg(\/\d+)?)/) {
							my $iprange = $1;
							if ($config{SAFECHAINUPDATE}) {
								&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -A NEW$name -s $iprange -j $drop");
							} else {
								&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -A $name -s $iprange -j $drop");
							}
						}
						elsif ($line =~ /($ipv6reg(\/\d+)?)/) {
							my $iprange = $1;
							if ($config{SAFECHAINUPDATE}) {
								&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -A NEW$name -s $iprange -j $drop");
							} else {
								&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -A $name -s $iprange -j $drop");
							}
						}
					}
					close ($BLOCK);
					if ($config{FASTSTART}) {&faststart("Blocklist [$name]")}

					$config{LF_BOGON_SKIP} =~ s/\s//g;
					if ($name eq "BOGON" and $config{LF_BOGON_SKIP} ne "") {
						foreach my $device (split(/\,/,$config{LF_BOGON_SKIP})) {
							if ($config{SAFECHAINUPDATE}) {
								&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -I NEWBOGON -i $device -j RETURN");
							} else {
								&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -I BOGON -i $device -j RETURN");
							}
						}
					}
					if ($config{SAFECHAINUPDATE}) {
						if ($cxsreputation and $name =~ /^CXS_/ and $name ne "CXS_ALL" and $cxsports{$name} ne "") {
							&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -A LOCALINPUT -p tcp -m multiport --dport $cxsports{$name} $ethdevin -j NEW$name");
							&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -D LOCALINPUT -p tcp -m multiport --dport $cxsports{$name} $ethdevin -j $name");
						} else {
							&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -A LOCALINPUT $ethdevin -j NEW$name");
							&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -D LOCALINPUT $ethdevin -j $name");
						}
						&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -F $name");
						&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -X $name");
						&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -E NEW$name $name");
						if ($config{IPV6}) {
							if ($cxsreputation and $name =~ /^CXS_/ and $name ne "CXS_ALL" and $cxsports{$name} ne "") {
								&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -A LOCALINPUT -p tcp -m multiport --dport $cxsports{$name} $ethdevin -j NEW$name");
								&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -D LOCALINPUT -p tcp -m multiport --dport $cxsports{$name} $ethdevin -j $name");
							} else {
								&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -A LOCALINPUT $ethdevin -j NEW$name");
								&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -D LOCALINPUT $ethdevin -j $name");
							}
							&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -F $name");
							&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -X $name");
							&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -E NEW$name $name");
						}
					}
				}
			}
		}

		&listlock("unlock");
		close ($THISLOCK );
		if ($config{DEBUG} >= 3) {$timer = &timer("stop","blocklist",$timer)}
		$0 = "lfd - child closing";
		exit;
	}
	return;
}
# end blocklist
###############################################################################
# start ccindex
# Index the requested country codes and ASNs once, so the GeoLite2/ip2asn
# databases are scanned with a hash lookup per record instead of looping over
# every CC_* entry (with a regex) for every record.
sub ccindex {
	my $cclist = shift;
	my %byiso;
	my %byasn;
	foreach my $cc (keys %{$cclist}) {
		push @{$byiso{uc $cc}}, $cc;
		if (uc($cc) =~ /AS(\d+)/) {push @{$byasn{$1}}, $cc}
	}
	return (\%byiso, \%byasn);
}
# end ccindex
###############################################################################
# start ccemptyzone
# A country code or ASN without entries for this IP family still gets a zone
# file. Otherwise the missing file is treated as out of date and every hourly
# check re-reads the database and repopulates every CC_* ipset.
# Nothing is written when the database could not be read (a failed download
# or unzip leaves it missing or empty), and a zone that still has entries is
# kept, so a broken database never replaces existing zones.
sub ccemptyzone {
	my $file = shift;
	my $db = shift;
	unless (-s $db) {return}
	if (-s $file) {
		open (my $IN, "<", $file);
		flock ($IN, LOCK_SH);
		my @entries = grep {!/^(\s|\#|$)/} <$IN>;
		close ($IN);
		if (@entries) {return}
	}
	sysopen (my $CIDROUT, $file, O_WRONLY | O_CREAT);
	flock ($CIDROUT, LOCK_EX);
	seek ($CIDROUT, 0, 0);
	truncate ($CIDROUT, 0);
	print $CIDROUT "# no entries found in the database\n";
	close ($CIDROUT);
	return;
}
# end ccemptyzone
###############################################################################
# start countrycode
sub countrycode {
	my $force = shift;

	if ($config{MM_LICENSE_KEY} eq "" and $config{CC_SRC} eq "1") {
		logfile("CC Error: Country Code Lookups setting MM_LICENSE_KEY must be set in /etc/csf/csf.conf to continue using the MaxMind databases");
		return;
	}

	$SIG{CHLD} = 'IGNORE';
	unless (defined ($childpid = fork)) {
		&shutdown(__LINE__,"*Error* cannot fork: $!");
	} 
	$forks{$childpid} = 1;
	unless ($childpid) {
		my $timer = time;
		if ($config{DEBUG} >= 3) {$timer = &timer("start","countrycode",$timer)}
		$0 = "lfd - retrieving countrycode lists";

		my $lockstr = "COUNTRYCODE";
		sysopen (my $THISLOCK, "/var/lib/csf/lock/$lockstr.lock", O_RDWR | O_CREAT) or &shutdown_child("*Error* Unable to open /var/lib/csf/lock/$lockstr.lock");
		flock ($THISLOCK, LOCK_EX | LOCK_NB) or &shutdown_child("*Lock Error* [$lockstr] still active - section skipped");
		print $THISLOCK time;

		$0 = "lfd - retrieving countrycode lists (waiting for list lock)";
		&listlock("lock");
		$0 = "lfd - retrieving countrycode lists";

		my $drop = $config{DROP};
		if ($config{DROP_IP_LOGGING}) {$drop = "CCDROP"}

		my $redo_deny = 0;
		my $redo_allow = 0;
		my $redo_allow_filter = 0;
		my $redo_allow_ports = 0;
		my $redo_deny_ports = 0;
		my $redo_allow_smtpauth = 0;
		$config{CC_DENY} =~ s/\s//g;
		$config{CC_ALLOW} =~ s/\s//g;
		$config{CC_ALLOW_FILTER} =~ s/\s//g;
		$config{CC_ALLOW_PORTS} =~ s/\s//g;
		$config{CC_DENY_PORTS} =~ s/\s//g;
		$config{CC_ALLOW_SMTPAUTH} =~ s/\s//g;
		my $getgeo = 0;
		my %cclist;

		if ($config{CC_SRC} eq "" or $config{CC_SRC} eq "1") {
			unless (-e "/var/lib/csf/Geo/GeoLite2-Country-Blocks-IPv4.csv") {$getgeo = 1}
			if (-z "/var/lib/csf/Geo/GeoLite2-Country-Blocks-IPv4.csv") {$getgeo = 1}
			unless (-e "/var/lib/csf/Geo/GeoLite2-ASN-Blocks-IPv4.csv") {$getgeo = 1}
			if (-z "/var/lib/csf/Geo/GeoLite2-ASN-Blocks-IPv4.csv") {$getgeo = 1}

			if (-e "/var/lib/csf/Geo/GeoLite2-Country-Blocks-IPv4.csv") {
				my $mtime = (stat("/var/lib/csf/Geo/GeoLite2-Country-Blocks-IPv4.csv"))[9];
				my $days = int((time - $mtime) / 86400);
				if ($days >= $config{CC_INTERVAL}) {$getgeo = 1}
			} else {$getgeo = 1}
			if ($getgeo) {
				unless (-e $config{UNZIP}) {
					logfile("Error: unzip binary ($config{UNZIP}) does not exist");
					exit;
				}
				logfile("CC: Retrieving $config{cc_src} Country database [$config{cc_country}]");
				my ($status, $text) = $urlget->urlget("$config{cc_country}","/var/lib/csf/Geo/GeoLite2-Country-CSV.zip");
				if ($status) {
					logfile("CC Error: Unable to retrieve $config{cc_src} Country database [$config{cc_country}] - $text");
				} else {
					if (-e "/var/lib/csf/Geo/GeoLite2-Country-Blocks-IPv4.csv") { unlink "/var/lib/csf/Geo/GeoLite2-Country-Blocks-IPv4.csv"}
					my @data;
					eval {
						local $SIG{__DIE__} = undef;
						local $SIG{'ALRM'} = sub {die};
						alarm(180);
						@data = &syscommand(__LINE__,$config{UNZIP},"-DDjod","/var/lib/csf/Geo/","/var/lib/csf/Geo/GeoLite2-Country-CSV.zip");
						alarm(0);
					};
					alarm(0);
					if ($@) {
						logfile("CC Error: Unable to unzip $config{cc_src} Country database /var/lib/csf/Geo/GeoLite2-Country-CSV.zip - timeout");
					}
					if (-z "/var/lib/csf/Geo/GeoLite2-Country-Blocks-IPv4.csv" or !(-e "/var/lib/csf/Geo/GeoLite2-Country-Blocks-IPv4.csv")) {
						logfile("CC Error: GeoLite2-Country-Blocks-IPv4.csv empty or missing");
					}
					foreach my $cc (split(/\,/,"$config{CC_DENY},$config{CC_ALLOW},$config{CC_ALLOW_FILTER},$config{CC_ALLOW_PORTS},$config{CC_DENY_PORTS},$config{CC_ALLOW_SMTPAUTH}")) {
						if ($cc and length($cc) == 2) {
							$cc = lc $cc;
							$cclist{$cc} = 1;
						}
					}
				}
				logfile("CC: Retrieving $config{asn_src} ASN database [$config{cc_asn}]");
				($status, $text) = $urlget->urlget("$config{cc_asn}","/var/lib/csf/Geo/GeoLite2-ASN-CSV.zip");
				if ($status) {
					logfile("CC Error: Unable to retrieve $config{asn_src} ASN database [$config{cc_asn}] - $text");
				} else {
					if (-e "/var/lib/csf/Geo/GeoLite2-ASN-Blocks-IPv4.csv") { unlink "/var/lib/csf/Geo/GeoLite2-ASN-Blocks-IPv4.csv"}
					my @data;
					eval {
						local $SIG{__DIE__} = undef;
						local $SIG{'ALRM'} = sub {die};
						alarm(180);
						@data = &syscommand(__LINE__,$config{UNZIP},"-DDjod","/var/lib/csf/Geo/","/var/lib/csf/Geo/GeoLite2-ASN-CSV.zip");
						alarm(0);
					};
					alarm(0);
					if ($@) {
						logfile("CC Error: Unable to unzip $config{cc_src} Country database /var/lib/csf/Geo/GeoLite2-ASN-CSV.zip - timeout");
					}
					if (-z "/var/lib/csf/Geo/GeoLite2-ASN-Blocks-IPv4.csv" or !(-e "/var/lib/csf/Geo/GeoLite2-ASN-Blocks-IPv4.csv")) {
						logfile("CC Error: GeoLite2-ASN-Blocks-IPv4.csv empty or missing");
					}
					foreach my $cc (split(/\,/,"$config{CC_DENY},$config{CC_ALLOW},$config{CC_ALLOW_FILTER},$config{CC_ALLOW_PORTS},$config{CC_DENY_PORTS},$config{CC_ALLOW_SMTPAUTH}")) {
						if ($cc and length($cc) > 2) {
							$cc = lc $cc;
							$cclist{$cc} = 1;
						}
					}
				}
				unlink glob "/var/lib/csf/Geo/*.zip";
				unlink glob "/var/lib/csf/Geo/*-Locations-de.csv";
				unlink glob "/var/lib/csf/Geo/*-Locations-es.csv";
				unlink glob "/var/lib/csf/Geo/*-Locations-fr.csv";
				unlink glob "/var/lib/csf/Geo/*-Locations-ja.csv";
				unlink glob "/var/lib/csf/Geo/*-Locations-pt-BR.csv";
				unlink glob "/var/lib/csf/Geo/*-Locations-ru.csv";
				unlink glob "/var/lib/csf/Geo/*-Locations-zh-CN.csv";
				unlink glob "/var/lib/csf/Geo/*.dat";
				unlink glob "/var/lib/csf/zone/*.zip";
				unlink glob "/var/lib/csf/zone/*.csv";
				unlink "/var/lib/csf/Geo/GeoIPv6.csv";
			}

			$0 = "lfd - processing countrycode lists";
			foreach my $cc (split(/\,/,"$config{CC_DENY},$config{CC_ALLOW},$config{CC_ALLOW_FILTER},$config{CC_ALLOW_PORTS},$config{CC_DENY_PORTS},$config{CC_ALLOW_SMTPAUTH}")) {
				if ($cc) {
					$cc = lc $cc;
					if (-e "/var/lib/csf/zone/$cc.zone") {
						my $mtime = (stat("/var/lib/csf/zone/$cc.zone"))[9];
						my $days = int((time - $mtime) / 86400);
						if ($days >= $config{CC_INTERVAL}) {$getgeo = 1; $cclist{$cc} = 1}
					} else {$getgeo = 1;  $cclist{$cc} = 1}
					if (-z "/var/lib/csf/zone/$cc.zone") {$getgeo = 1;  $cclist{$cc} = 1}

					if ($cclist{$cc}) {
						if ($config{CC_DENY} =~ /\b$cc\b/i) {$redo_deny = 1}
						if ($config{CC_ALLOW} =~ /\b$cc\b/i) {$redo_allow = 1}
						if ($config{CC_ALLOW_FILTER} =~ /\b$cc\b/i) {$redo_allow_filter = 1}
						if ($config{CC_ALLOW_PORTS} =~ /\b$cc\b/i) {$redo_allow_ports = 1}
						if ($config{CC_DENY_PORTS} =~ /\b$cc\b/i) {$redo_deny_ports = 1}
						if ($config{CC_ALLOW_SMTPAUTH} =~ /\b$cc\b/i) {$redo_allow_smtpauth = 1}
					}
				}
			}

			if ($getgeo) {
				logfile("CC: Processing $config{cc_src} Country/ASN database");
				my ($ccbyiso,$ccbyasn) = &ccindex(\%cclist);
				my %dcidr;
				my %geoid;
				open (my $GEO, "<", "/var/lib/csf/Geo/GeoLite2-Country-Locations-en.csv");
				flock ($GEO, LOCK_SH);
				while (my $record = <$GEO>) {
					chomp $record;
					$record =~ s/\"//g;
					my ($geoname_id,undef,undef,undef,$country_iso_code,undef) = split (/\,/,$record);
					foreach my $cc (@{$ccbyiso->{uc $country_iso_code} || []}) {
						push @{$geoid{$geoname_id}}, $cc;
					}
				}
				close ($GEO);
				open (my $IN, "<", "/var/lib/csf/Geo/GeoLite2-Country-Blocks-IPv4.csv");
				flock ($IN, LOCK_SH);
				while (my $record = <$IN>) {
					chomp $record;
					$record =~ s/\"//g;
					my ($range,$geoname_id,undef) = split (/\,/,$record);
					foreach my $cc (@{$geoid{$geoname_id} || []}) {
						$dcidr{$cc}{$range} = 1;
					}
				}
				close ($IN);
				open ($IN, "<", "/var/lib/csf/Geo/GeoLite2-ASN-Blocks-IPv4.csv");
				flock ($IN, LOCK_SH);
				while (my $record = <$IN>) {
					chomp $record;
					$record =~ s/\"//g;
					my ($range,$asn,undef) = split (/\,/,$record);
					foreach my $cc (@{$ccbyasn->{$asn} || []}) {
						$dcidr{$cc}{$range} = 1;
					}
				}
				close ($IN);
				foreach my $cc (keys %cclist) {
					logfile("CC: Extracting zone from $config{cc_src} Country/ASN database for [".uc($cc)."]");
					if (keys %{$dcidr{$cc}} eq 0) {
						if (length($cc) == 2) {
							logfile("CC: No entries found for [".uc($cc)."] in /var/lib/csf/Geo/GeoLite2-Country-Blocks-IPv4.csv");
							&ccemptyzone("/var/lib/csf/zone/$cc.zone","/var/lib/csf/Geo/GeoLite2-Country-Blocks-IPv4.csv");
						} else {
							logfile("CC: No entries found for [".uc($cc)."] in /var/lib/csf/Geo/GeoLite2-ASN-Blocks-IPv4.csv");
							&ccemptyzone("/var/lib/csf/zone/$cc.zone","/var/lib/csf/Geo/GeoLite2-ASN-Blocks-IPv4.csv");
						}
					} else {
						sysopen (my $CIDROUT, "/var/lib/csf/zone/$cc.zone", O_WRONLY | O_CREAT);
						flock ($CIDROUT, LOCK_EX);
						seek ($CIDROUT, 0, 0);
						truncate ($CIDROUT, 0);
						foreach my $key (keys %{$dcidr{$cc}}) {print $CIDROUT "$key\n"}
						close ($CIDROUT);
					}
				}
			}
		} elsif ($config{CC_SRC} eq "2") {
			unless (-e "/var/lib/csf/Geo/ip2asn-combined.tsv") {$getgeo = 1}
			if (-z "/var/lib/csf/Geo/ip2asn-combined.tsv") {$getgeo = 1}

			if ($getgeo) {
				unless (-e $config{UNZIP}) {
					logfile("Error: unzip binary ($config{UNZIP}) does not exist");
					exit;
				}
				logfile("CC: Retrieving $config{asn_src} ASN database [$config{cc_asn}]");
				my ($status, $text) = $urlget->urlget("$config{cc_asn}","/var/lib/csf/Geo/ip2asn-combined.tsv.gz");
				if ($status) {
					logfile("CC Error: Unable to retrieve $config{asn_src} ASN database [$config{cc_asn}] - $text");
				} else {
					if (-e "/var/lib/csf/Geo/ip2asn-combined.tsv") { unlink "/var/lib/csf/Geo/ip2asn-combined.tsv"}
					my @data;
					eval {
						local $SIG{__DIE__} = undef;
						local $SIG{'ALRM'} = sub {die};
						alarm(180);
						@data = &syscommand(__LINE__,$config{GUNZIP},"/var/lib/csf/Geo/ip2asn-combined.tsv.gz");
						alarm(0);
					};
					alarm(0);
					if ($@) {
						logfile("CC Error: Unable to unzip $config{cc_src} Country database /var/lib/csf/Geo/ip2asn-combined.tsv.gz - timeout");
					}
					if (-z "/var/lib/csf/Geo/ip2asn-combined.tsv" or !(-e "/var/lib/csf/Geo/ip2asn-combined.tsv")) {
						logfile("CC Error: ip2asn-combined.tsv empty or missing");
					}
					foreach my $cc (split(/\,/,"$config{CC_DENY},$config{CC_ALLOW},$config{CC_ALLOW_FILTER},$config{CC_ALLOW_PORTS},$config{CC_DENY_PORTS},$config{CC_ALLOW_SMTPAUTH}")) {
						if ($cc and length($cc) > 2) {
							$cc = lc $cc;
							$cclist{$cc} = 1;
						}
					}
				}
			}

			$0 = "lfd - processing countrycode lists";
			foreach my $cc (split(/\,/,"$config{CC_DENY},$config{CC_ALLOW},$config{CC_ALLOW_FILTER},$config{CC_ALLOW_PORTS},$config{CC_DENY_PORTS},$config{CC_ALLOW_SMTPAUTH}")) {
				if ($cc) {
					$cc = lc $cc;
					if (-e "/var/lib/csf/zone/$cc.zone") {
						my $mtime = (stat("/var/lib/csf/zone/$cc.zone"))[9];
						my $days = int((time - $mtime) / 86400);
						if ($days >= $config{CC_INTERVAL}) {$getgeo = 1; $cclist{$cc} = 1}
					} else {$getgeo = 1;  $cclist{$cc} = 1}
					if (-z "/var/lib/csf/zone/$cc.zone") {$getgeo = 1;  $cclist{$cc} = 1}

					if ($cclist{$cc}) {
						if ($config{CC_DENY} =~ /\b$cc\b/i) {$redo_deny = 1}
						if ($config{CC_ALLOW} =~ /\b$cc\b/i) {$redo_allow = 1}
						if ($config{CC_ALLOW_FILTER} =~ /\b$cc\b/i) {$redo_allow_filter = 1}
						if ($config{CC_ALLOW_PORTS} =~ /\b$cc\b/i) {$redo_allow_ports = 1}
						if ($config{CC_DENY_PORTS} =~ /\b$cc\b/i) {$redo_deny_ports = 1}
						if ($config{CC_ALLOW_SMTPAUTH} =~ /\b$cc\b/i) {$redo_allow_smtpauth = 1}
					}
				}
			}

			if ($getgeo) {
				logfile("CC: Processing $config{asn_src} ASN database");
				my (undef,$ccbyasn) = &ccindex(\%cclist);
				my %dcidr;
				open ($IN, "<", "/var/lib/csf/Geo/ip2asn-combined.tsv");
				flock ($IN, LOCK_SH);
				while (my $record = <$IN>) {
					chomp $record;
					$record =~ s/\"//g;
					my ($start,$end,$asn,undef) = split (/\t/,$record);
					if (checkip($start) == 6) {last}
					foreach my $cc (@{$ccbyasn->{$asn} || []}) {
						my $ipscidr = Net::CIDR::Lite->new;
						eval {local $SIG{__DIE__} = undef; $ipscidr->add_range("$start-$end")};
						my @cidr_list = $ipscidr->list;
						foreach my $list (@cidr_list) {
							$dcidr{$cc}{$list} = 1;
						}
					}
				}
				close ($IN);
				foreach my $cc (keys %cclist) {
					if (length($cc) > 2) {
						logfile("CC: Extracting zone from $config{asn_src} ASN database for [".uc($cc)."]");
						if (keys %{$dcidr{$cc}} eq 0) {
							logfile("CC: No entries found for [".uc($cc)."] in /var/lib/csf/Geo/ip2asn-combined.tsv");
							&ccemptyzone("/var/lib/csf/zone/$cc.zone","/var/lib/csf/Geo/ip2asn-combined.tsv");
						} else {
							sysopen (my $CIDROUT, "/var/lib/csf/zone/$cc.zone", O_WRONLY | O_CREAT);
							flock ($CIDROUT, LOCK_EX);
							seek ($CIDROUT, 0, 0);
							truncate ($CIDROUT, 0);
							foreach my $key (keys %{$dcidr{$cc}}) {print $CIDROUT "$key\n"}
							close ($CIDROUT);
						}
					}
					elsif (length($cc) == 2) {
						logfile("CC: Retrieving $config{ccl_src} Country Code Zone [".uc($cc)."] from https://www.ipdeny.com");
						my ($status, $text) = $urlget->urlget("https://www.ipdeny.com/ipblocks/data/aggregated/${cc}-aggregated.zone","/var/lib/csf/zone/$cc.zone");
						if ($status) {
							logfile("CC Error: Unable to retrieve $config{ccl_src} Country Code Zone [".uc($cc)."] from https://www.ipdeny.com/ - $text");
						} else {
							logfile("CC: Country Code Zone [".uc($cc)."] retrieved");
						}
						sleep 1;
					}
				}
			}
		}
		
		if ($force) {
			$redo_deny = 1;
			$redo_allow = 1;
			$redo_allow_filter = 1;
			$redo_allow_ports = 1;
			$redo_deny_ports = 1;
			$redo_allow_smtpauth = 1;
		}

		if ($config{LF_IPSET}) {
			my $cclist;
			my $cnt = 0;
			if ($redo_deny) {$cclist .= $config{CC_DENY}.","}
			if ($redo_allow) {$cclist .= $config{CC_ALLOW}.","}
			if ($redo_allow_filter) {$cclist .= $config{CC_ALLOW_FILTER}.","}
			if ($redo_allow_ports) {$cclist .= $config{CC_ALLOW_PORTS}.","}
			if ($redo_deny_ports) {$cclist .= $config{CC_DENY_PORTS}}
			if ($config{CC_ALLOW_FILTER} and $redo_allow_filter) {&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -F CC_ALLOWF")}
			foreach my $cc (split(/\,/,$cclist)) {
				if ($cc eq "") { next }
				undef @ipset;
				$cc = lc $cc;
				if ($config{CC_ALLOW_FILTER} and $redo_allow_filter) {
					&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -A CC_ALLOWF -m set --match-set cc_$cc src -j RETURN");}
				if (-e "/var/lib/csf/zone/$cc.zone") {
					logfile("CC: Repopulating ipset cc_$cc with IP addresses from [".uc($cc)."]");
					open (my $IN, "<", "/var/lib/csf/zone/$cc.zone");
					flock ($IN, LOCK_SH);
					while (my $line = <$IN>) {
						chomp $line;
						my ($ip,undef) = split (/\s/,$line,2);
						if ($config{CC_DROP_CIDR} > 0 and $config{CC_DROP_CIDR} < 33) {
							my ($drop_ip,$drop_cidr) = split(/\//,$ip);
							if ($drop_cidr eq "") {$drop_cidr = "32"}
							if ($drop_cidr > $config{CC_DROP_CIDR}) { next }
						}
						if (cccheckip(\$ip)) {
							push @ipset,"add new_$cc $ip";
							$cnt++;
						}
					}
					&ipsetrestore("new_$cc");
					&ipsetswap("new_$cc","cc_$cc");
				}
			}
			if ($config{CC_ALLOW_FILTER} and $redo_allow_filter and $cnt > 0) {
				&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -A CC_ALLOWF -j $drop");
				if ($config{LF_SPI}) {
					my $statemodule = "-m state --state";
					if ($config{USE_CONNTRACK}) {$statemodule = "-m conntrack --ctstate"}
					if ($config{USE_FTPHELPER}) {
						&syscommand(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -I CC_ALLOWF $ethdevin $statemodule RELATED -m helper --helper ftp -j $accept");

						&syscommand(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -I CC_ALLOWF $ethdevin $statemodule ESTABLISHED -j $accept");
					} else {
						&syscommand(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -I CC_ALLOWF $ethdevin $statemodule ESTABLISHED,RELATED -j $accept");
					}
				}
			}
		} else {
			if ($config{CC_DENY} and $redo_deny) {
				if (&csflock) {&lockfail("CC_DENY")}
				if ($config{SAFECHAINUPDATE}) {
					&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -N NEWCC_DENY");
				} else {
					&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -F CC_DENY");
				}
				# Keep return traffic of server-initiated connections flowing (#119)
				my $ccdeny_chain = $config{SAFECHAINUPDATE} ? "NEWCC_DENY" : "CC_DENY";
				&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -A $ccdeny_chain -m conntrack --ctstate ESTABLISHED,RELATED --ctdir REPLY -j $accept");
				foreach my $cc (split(/\,/,$config{CC_DENY})) {
					$cc = lc $cc;
					if (-e "/var/lib/csf/zone/$cc.zone") {
						if ($config{FASTSTART}) {$faststart = 1}
						logfile("CC: Repopulating CC_DENY with IP addresses from [".uc($cc)."]");
						open (my $IN, "<", "/var/lib/csf/zone/$cc.zone");
						flock ($IN, LOCK_SH);
						while (my $line = <$IN>) {
							chomp $line;
							my ($ip,undef) = split (/\s/,$line,2);
							if (cccheckip(\$ip)) {
								if ($config{CC_DROP_CIDR} > 0 and $config{CC_DROP_CIDR} < 33) {
									my ($drop_ip,$drop_cidr) = split(/\//,$ip);
									if ($drop_cidr eq "") {$drop_cidr = "32"}
									if ($drop_cidr > $config{CC_DROP_CIDR}) { next }
								}
								if ($config{SAFECHAINUPDATE}) {
									&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -A NEWCC_DENY -s $ip -j $drop");
								} else {
									&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -A CC_DENY -s $ip -j $drop");
								}
							}
						}
						close ($IN);
						if ($config{FASTSTART}) {&faststart("CC_DENY [".uc($cc)."]")}
						logfile("CC: Finished repopulating CC_DENY with IP addresses from [".uc($cc)."]");
					}
				}
				if ($config{SAFECHAINUPDATE}) {
					&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -A LOCALINPUT $ethdevin -j NEWCC_DENY");
					&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -D LOCALINPUT $ethdevin -j CC_DENY");
					&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -F CC_DENY");
					&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -X CC_DENY");
					&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -E NEWCC_DENY CC_DENY");
				}
			}

			if ($config{CC_ALLOW} and $redo_allow) {
				if (&csflock) {&lockfail("CC_ALLOW")}
				if ($config{SAFECHAINUPDATE}) {
					&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -N NEWCC_ALLOW");
				} else {
					&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -F CC_ALLOW");
				}
				foreach my $cc (split(/\,/,$config{CC_ALLOW})) {
					$cc = lc $cc;
					if (-e "/var/lib/csf/zone/$cc.zone") {
						if ($config{FASTSTART}) {$faststart = 1}
						logfile("CC: Repopulating CC_ALLOW with IP addresses from [".uc($cc)."]");
						open (my $IN, "<", "/var/lib/csf/zone/$cc.zone");
						flock ($IN, LOCK_SH);
						while (my $line = <$IN>) {
							chomp $line;
							my ($ip,undef) = split (/\s/,$line,2);
							if (cccheckip(\$ip)) {
								if ($config{CC_DROP_CIDR} > 0 and $config{CC_DROP_CIDR} < 33) {
									my ($drop_ip,$drop_cidr) = split(/\//,$ip);
									if ($drop_cidr eq "") {$drop_cidr = "32"}
									if ($drop_cidr > $config{CC_DROP_CIDR}) { next }
								}
								if ($config{SAFECHAINUPDATE}) {
									&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -A NEWCC_ALLOW -s $ip -j $accept");
								} else {
									&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -A CC_ALLOW -s $ip -j $accept");
								}
							}
						}
						close ($IN);
						if ($config{FASTSTART}) {&faststart("CC_ALLOW [".uc($cc)."]")}
						logfile("CC: Finished repopulating CC_ALLOW with IP addresses from [".uc($cc)."]");
					}
				}
				if ($config{SAFECHAINUPDATE}) {
					&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -I LOCALINPUT $ethdevin -j NEWCC_ALLOW");
					&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -D LOCALINPUT $ethdevin -j CC_ALLOW");
					&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -F CC_ALLOW");
					&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -X CC_ALLOW");
					&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -E NEWCC_ALLOW CC_ALLOW");
				}
			}

			if ($config{CC_ALLOW_FILTER} and $redo_allow_filter) {
				my $cnt = 0;
				if (&csflock) {&lockfail("CC_ALLOW_FILTER")}
				if ($config{SAFECHAINUPDATE}) {
					&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -N NCC_ALLOWF");
				} else {
					&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -F CC_ALLOWF");
				}
				foreach my $cc (split(/\,/,$config{CC_ALLOW_FILTER})) {
					$cc = lc $cc;
					if (-e "/var/lib/csf/zone/$cc.zone") {
						if ($config{FASTSTART}) {$faststart = 1}
						logfile("CC: Repopulating CC_ALLOWF with IP addresses from [".uc($cc)."]");
						open (my $IN, "<", "/var/lib/csf/zone/$cc.zone");
						flock ($IN, LOCK_SH);
						while (my $line = <$IN>) {
							chomp $line;
							my ($ip,undef) = split (/\s/,$line,2);
							if (cccheckip(\$ip)) {
								if ($config{CC_DROP_CIDR} > 0 and $config{CC_DROP_CIDR} < 33) {
									my ($drop_ip,$drop_cidr) = split(/\//,$ip);
									if ($drop_cidr eq "") {$drop_cidr = "32"}
									if ($drop_cidr > $config{CC_DROP_CIDR}) { next }
								}
								$cnt++;
								if ($config{SAFECHAINUPDATE}) {
									&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -A NCC_ALLOWF -s $ip -j RETURN");
								} else {
									&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -A CC_ALLOWF -s $ip -j RETURN");
								}
							}
						}
						close ($IN);
						if ($config{FASTSTART}) {&faststart("CC_ALLOW_FILTER [".uc($cc)."]")}
						logfile("CC: Finished repopulating CC_ALLOWF with IP addresses from [".uc($cc)."]");
					}
				}
				if ($config{SAFECHAINUPDATE}) {
					if ($cnt > 0) {&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -A NCC_ALLOWF -j $drop")}
					&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -A LOCALINPUT $ethdevin -j NCC_ALLOWF");
					&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -D LOCALINPUT $ethdevin -j CC_ALLOWF");
					&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -F CC_ALLOWF");
					&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -X CC_ALLOWF");
					&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -E NCC_ALLOWF CC_ALLOWF");
				} else {
					if ($cnt > 0) {
						&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -A CC_ALLOWF -j $drop");
						if ($config{LF_SPI}) {
							my $statemodule = "-m state --state";
							if ($config{USE_CONNTRACK}) {$statemodule = "-m conntrack --ctstate"}
							if ($config{USE_FTPHELPER}) {
								&syscommand(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -I CC_ALLOWF $ethdevin $statemodule RELATED -m helper --helper ftp -j $accept");

								&syscommand(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -I CC_ALLOWF $ethdevin $statemodule ESTABLISHED -j $accept");
							} else {
								&syscommand(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -I CC_ALLOWF $ethdevin $statemodule ESTABLISHED,RELATED -j $accept");
							}
						}
					}
				}
			}

			if ($config{CC_ALLOW_PORTS} and $redo_allow_ports) {
				my $cnt = 0;
				if (&csflock) {&lockfail("CC_ALLOW_PORTS")}
				if ($config{SAFECHAINUPDATE}) {
					&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -N NCC_ALLOWP");
				} else {
					&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -F CC_ALLOWP");
				}
				foreach my $cc (split(/\,/,$config{CC_ALLOW_PORTS})) {
					$cc = lc $cc;
					if (-e "/var/lib/csf/zone/$cc.zone") {
						if ($config{FASTSTART}) {$faststart = 1}
						logfile("CC: Repopulating CC_ALLOWP with IP addresses from [".uc($cc)."]");
						open (my $IN, "<", "/var/lib/csf/zone/$cc.zone");
						flock ($IN, LOCK_SH);
						while (my $line = <$IN>) {
							chomp $line;
							my ($ip,undef) = split (/\s/,$line,2);
							if (cccheckip(\$ip)) {
								if ($config{CC_DROP_CIDR} > 0 and $config{CC_DROP_CIDR} < 33) {
									my ($drop_ip,$drop_cidr) = split(/\//,$ip);
									if ($drop_cidr eq "") {$drop_cidr = "32"}
									if ($drop_cidr > $config{CC_DROP_CIDR}) { next }
								}
								$cnt++;
								if ($config{SAFECHAINUPDATE}) {
									&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -A NCC_ALLOWP -s $ip -j CC_ALLOWPORTS");
								} else {
									&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -A CC_ALLOWP -s $ip -j CC_ALLOWPORTS");
								}
							}
						}
						close ($IN);
						if ($config{FASTSTART}) {&faststart("CC_ALLOW_PORTS [".uc($cc)."]")}
						logfile("CC: Finished repopulating CC_ALLOWP with IP addresses from [".uc($cc)."]");
					}
				}
				if ($config{SAFECHAINUPDATE}) {
					&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -A LOCALINPUT $ethdevin -j NCC_ALLOWP");
					&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -D LOCALINPUT $ethdevin -j CC_ALLOWP");
					&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -F CC_ALLOWP");
					&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -X CC_ALLOWP");
					&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -E NCC_ALLOWP CC_ALLOWP");
				}
			}

			if ($config{CC_DENY_PORTS} and $redo_deny_ports) {
				my $cnt = 0;
				if (&csflock) {&lockfail("CC_DENY_PORTS")}
				if ($config{SAFECHAINUPDATE}) {
					&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -N NCC_DENYP");
				} else {
					&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -F CC_DENYP");
				}
				foreach my $cc (split(/\,/,$config{CC_DENY_PORTS})) {
					$cc = lc $cc;
					if (-e "/var/lib/csf/zone/$cc.zone") {
						if ($config{FASTSTART}) {$faststart = 1}
						logfile("CC: Repopulating CC_DENYP with IP addresses from [".uc($cc)."]");
						open (my $IN, "<", "/var/lib/csf/zone/$cc.zone");
						flock ($IN, LOCK_SH);
						while (my $line = <$IN>) {
							chomp $line;
							my ($ip,undef) = split (/\s/,$line,2);
							if (cccheckip(\$ip)) {
								if ($config{CC_DROP_CIDR} > 0 and $config{CC_DROP_CIDR} < 33) {
									my ($drop_ip,$drop_cidr) = split(/\//,$ip);
									if ($drop_cidr eq "") {$drop_cidr = "32"}
									if ($drop_cidr > $config{CC_DROP_CIDR}) { next }
								}
								$cnt++;
								if ($config{SAFECHAINUPDATE}) {
									&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -A NCC_DENYP -s $ip -j CC_DENYPORTS");
								} else {
									&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -A CC_DENYP -s $ip -j CC_DENYPORTS");
								}
							}
						}
						close ($IN);
						if ($config{FASTSTART}) {&faststart("CC_DENY_PORTS [".uc($cc)."]")}
						logfile("CC: Finished repopulating CC_DENYP with IP addresses from [".uc($cc)."]");
					}
				}
				if ($config{SAFECHAINUPDATE}) {
					&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -A LOCALINPUT $ethdevin -j NCC_DENYP");
					&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -D LOCALINPUT $ethdevin -j CC_DENYP");
					&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -F CC_DENYP");
					&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -X CC_DENYP");
					&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -E NCC_DENYP CC_DENYP");
				}
			}
		}
		if ($config{CC6_LOOKUPS} and $config{IPV6}) {
			&countrycode6($force);
		}

		if ($config{CC_ALLOW_SMTPAUTH} and $config{SMTPAUTH_RESTRICT} and $redo_allow_smtpauth) {
			sysopen (my $SMTPAUTH, "/etc/exim.smtpauth", O_WRONLY | O_CREAT);
			flock ($SMTPAUTH, LOCK_EX);
			seek ($SMTPAUTH, 0, 0);
			truncate ($SMTPAUTH, 0);
			print $SMTPAUTH "# DO NOT EDIT THIS FILE\n#\n";
			print $SMTPAUTH "# Modify /etc/csf/csf.smtpauth and then restart csf and then lfd\n\n";
			print $SMTPAUTH "127.0.0.0/8\n";
			print $SMTPAUTH "\"::1\"\n";
			print $SMTPAUTH "\"::1/128\"\n";
			if (-e "/etc/csf/csf.smtpauth") {
				my @entries = slurp("/etc/csf/csf.smtpauth");
				foreach my $line ( @entries ) {
					if ( $line =~ /^Include\s*(.*)$/ ) {
						my @incfile = slurp( $1 );
						push @entries, @incfile;
					}
				}
				foreach my $line ( @entries ) {
					$line =~ s/$cleanreg//g;
					if ( $line eq "" ) { next }
					if ( $line =~ /^\s*\#|Include/ ) { next }
					my ($ip,undef) = split (/\s/,$line,2);
					my $status = checkip(\$ip);
					if ($status == 4) {print $SMTPAUTH "$ip\n"}
					elsif ($status == 6) {print $SMTPAUTH "\"$ip\"\n"}
				}
			}
			foreach my $cc (split(/\,/,$config{CC_ALLOW_SMTPAUTH})) {
				$cc = lc $cc;
				if (-e "/var/lib/csf/zone/$cc.zone") {
					print $SMTPAUTH "\n# IPv4 addresses for [".uc($cc)."]:\n";
					foreach my $line (slurp("/var/lib/csf/zone/$cc.zone")) {
						$line =~ s/$cleanreg//g;
						if ($line =~ /^(\s|\#|$)/) { next }
						my ($ip,undef) = split (/\s/,$line,2);
						if ($config{CC_DROP_CIDR} > 0 and $config{CC_DROP_CIDR} < 33) {
							my ($drop_ip,$drop_cidr) = split(/\//,$ip);
							if ($drop_cidr eq "") {$drop_cidr = "32"}
							if ($drop_cidr > $config{CC_DROP_CIDR}) { next }
						}
						my $status = cccheckip(\$ip);
						if ($status == 4) {print $SMTPAUTH "$ip\n"}
						elsif ($status == 6) {print $SMTPAUTH "\"$ip\"\n"}
					}
					logfile("CC: Finished repopulating /etc/exim.smtpauth with IPv4 addresses from [".uc($cc)."]");
				}
				if ($config{CC6_LOOKUPS} and -e "/var/lib/csf/zone/$cc.zone6") {
					print $SMTPAUTH "\n# IPv6 addresses for [".uc($cc)."]:\n";
					foreach my $line (slurp("/var/lib/csf/zone/$cc.zone6")) {
						$line =~ s/$cleanreg//g;
						if ($line =~ /^(\s|\#|$)/) { next }
						my ($ip,undef) = split (/\s/,$line,2);
						if ($config{CC_DROP_CIDR} > 0 and $config{CC_DROP_CIDR} < 33) {
							my ($drop_ip,$drop_cidr) = split(/\//,$ip);
							if ($drop_cidr eq "") {$drop_cidr = "32"}
							if ($drop_cidr > $config{CC_DROP_CIDR}) { next }
						}
						my $status = cccheckip(\$ip);
						if ($status == 4) {print $SMTPAUTH "$ip\n"}
						elsif ($status == 6) {print $SMTPAUTH "\"$ip\"\n"}
					}
					logfile("CC: Finished repopulating /etc/exim.smtpauth with IPv6 addresses from [".uc($cc)."]");
				}
			}
			close ($SMTPAUTH);
			chmod (0644,"/etc/exim.smtpauth");
		}

		&listlock("unlock");
		close ($THISLOCK );
		if ($config{DEBUG} >= 3) {$timer = &timer("stop","countrycode",$timer)}
		$0 = "lfd - child closing";
		exit;
	}
	return;
}
# end countrycode
###############################################################################
# start countrycodelookups
sub countrycodelookups {
	my $force = shift;
	if ($config{CC_LOOKUPS} == 4) {return}

	if ($config{MM_LICENSE_KEY} eq "" and $config{CC_SRC} eq "1") {
		logfile("CC Error: Country Code Filters setting MM_LICENSE_KEY must be set in /etc/csf/csf.conf to continue using the MaxMind databases");
		return;
	}

	$SIG{CHLD} = 'IGNORE';
	unless (defined ($childpid = fork)) {
		&shutdown(__LINE__,"*Error* cannot fork: $!");
	} 
	$forks{$childpid} = 1;
	unless ($childpid) {
		my $timer = time;
		if ($config{DEBUG} >= 3) {$timer = &timer("start","countrycodelookups",$timer)}
		$0 = "lfd - retrieving countrycode lookups";

		my $lockstr = "CC_LOOKUPS";
		sysopen (my $THISLOCK, "/var/lib/csf/lock/$lockstr.lock", O_RDWR | O_CREAT) or &shutdown_child("*Error* Unable to open /var/lib/csf/lock/$lockstr.lock");
		flock ($THISLOCK, LOCK_EX | LOCK_NB) or &shutdown_child("*Lock Error* [$lockstr] still active - section skipped");
		print $THISLOCK time;

		$0 = "lfd - retrieving countrycodelookups lists (waiting for list lock)";
		&listlock("lock");
		$0 = "lfd - retrieving countrycodelookups lists";

		if ($config{CC_SRC} eq "" or $config{CC_SRC} eq "1") {
			my $getgeo = 0;
			my $geofile = "/var/lib/csf/Geo/GeoLite2-Country-Blocks-IPv4.csv";
			if ($config{CC_LOOKUPS} == 2 or $config{CC_LOOKUPS} == 3) {$geofile = "/var/lib/csf/Geo/GeoLite2-City-Blocks-IPv4.csv"}
			if (-e $geofile) {
				if (-z $geofile) {$getgeo = 1}
				my $mtime = (stat($geofile))[9];
				my $days = int((time - $mtime) / 86400);
				if ($days >= $config{CC_INTERVAL}) {$getgeo = 1}

				if ($config{CC_LOOKUPS} == 3) {
					my $geofile = "/var/lib/csf/Geo/GeoLite2-ASN-Blocks-IPv4.csv";
					if (-z $geofile) {$getgeo = 1}
					my $mtime = (stat($geofile))[9];
					my $days = int((time - $mtime) / 86400);
					if ($days >= $config{CC_INTERVAL}) {$getgeo = 1}
				}
			} else {$getgeo = 1}
			if ($getgeo) {
				my $status;
				my $text;
				if ($config{CC_LOOKUPS} == 3) {
					logfile("CCL: Retrieving $config{asn_src} ASN database [$config{cc_asn}]");
					($status, $text) = $urlget->urlget("$config{cc_asn}","/var/lib/csf/Geo/GeoLite2-ASN-CSV.zip");
					logfile("CCL: Retrieving $config{cc_src} City database [$config{cc_city}]");
					($status, $text) = $urlget->urlget("$config{cc_city}","/var/lib/csf/Geo/GeoLite2-City-CSV.zip");
				}
				elsif ($config{CC_LOOKUPS} == 2) {
					logfile("CCL: Retrieving $config{cc_src} City database [$config{cc_city}]");
					($status, $text) = $urlget->urlget("$config{cc_city}","/var/lib/csf/Geo/GeoLite2-City-CSV.zip");
				}
				else {
					logfile("CCL: Retrieving $config{cc_src} Country database [$config{cc_country}]");
					($status, $text) = $urlget->urlget("$config{cc_country}","/var/lib/csf/Geo/GeoLite2-Country-CSV.zip");
				}
				if ($status) {
					if ($config{CC_LOOKUPS} == 2 or $config{CC_LOOKUPS} == 3) {
						logfile("CCL Error: Unable to retrieve $config{cc_src} City database [$config{cc_city}] - $text");
					} else {
						logfile("CCL Error: Unable to retrieve $config{cc_src} Country database [$config{cc_country}] - $text");
					}
				} else {
					my @data;
					eval {
						local $SIG{__DIE__} = undef;
						local $SIG{'ALRM'} = sub {die};
						alarm(180);
						my ($childin, $childout, $cmdpid);
						if ($config{CC_LOOKUPS} == 3) {
							@data = &syscommand(__LINE__,$config{UNZIP},"-DDjod","/var/lib/csf/Geo/","/var/lib/csf/Geo/GeoLite2-ASN-CSV.zip");
							@data = &syscommand(__LINE__,$config{UNZIP},"-DDjod","/var/lib/csf/Geo/","/var/lib/csf/Geo/GeoLite2-City-CSV.zip");
						}
						elsif ($config{CC_LOOKUPS} == 2) {
							@data = &syscommand(__LINE__,$config{UNZIP},"-DDjod","/var/lib/csf/Geo/","/var/lib/csf/Geo/GeoLite2-City-CSV.zip");
						}
						else {
							@data = &syscommand(__LINE__,$config{UNZIP},"-DDjod","/var/lib/csf/Geo/","/var/lib/csf/Geo/GeoLite2-Country-CSV.zip");
						}
						alarm(0);
					};
					alarm(0);
					if ($@) {
						if ($config{CC_LOOKUPS} == 2 or $config{CC_LOOKUPS} == 3) {
							logfile("CCL Error: Unable to unzip $config{cc_src} City database /var/lib/csf/Geo/GeoLite2-City-CSV.zip - timeout");
						} else {
							logfile("CCL Error: Unable to unzip $config{cc_src} Country database /var/lib/csf/Geo/GeoLite2-Country-CSV.zip - timeout");
						}
					}
					if (!(-e $geofile) or -z $geofile) {
						logfile("CCL Error: $geofile empty or missing");
					} else {
						my $now = time;
						utime ($now,$now,$geofile);
						logfile("CCL: Retrieved $config{cc_src} IP database");
						open (my $OUT, ">", "/var/lib/csf/csf.cclookup");
						close ($OUT);
					}
				}
				unlink glob "/var/lib/csf/Geo/*.zip";
				unlink glob "/var/lib/csf/Geo/*-Locations-de.csv";
				unlink glob "/var/lib/csf/Geo/*-Locations-es.csv";
				unlink glob "/var/lib/csf/Geo/*-Locations-fr.csv";
				unlink glob "/var/lib/csf/Geo/*-Locations-ja.csv";
				unlink glob "/var/lib/csf/Geo/*-Locations-pt-BR.csv";
				unlink glob "/var/lib/csf/Geo/*-Locations-ru.csv";
				unlink glob "/var/lib/csf/Geo/*-Locations-zh-CN.csv";
				unlink glob "/var/lib/csf/Geo/*.dat";
				unlink glob "/var/lib/csf/zone/*.zip";
				unlink glob "/var/lib/csf/zone/*.csv";
				unlink "/var/lib/csf/Geo/GeoIPv6.csv";
			}
		} elsif ($config{CC_SRC} eq "2") {
			my $getgeo = 0;
			my $geofile = "/var/lib/csf/Geo/dbip-country-lite.csv";
			if ($config{CC_LOOKUPS} == 2 or $config{CC_LOOKUPS} == 3) {$geofile = "/var/lib/csf/Geo/dbip-city-lite.csv"}
			if (-e $geofile) {
				if (-z $geofile) {$getgeo = 1}
				my $mtime = (stat($geofile))[9];
				my $days = int((time - $mtime) / 86400);
				if ($days >= $config{CC_INTERVAL}) {$getgeo = 1}

				if ($config{CC_LOOKUPS} == 3) {
					my $geofile = "/var/lib/csf/Geo/ip2asn-combined.tsv";
					if (-z $geofile) {$getgeo = 1}
					my $mtime = (stat($geofile))[9];
					my $days = int((time - $mtime) / 86400);
					if ($days >= $config{CC_INTERVAL}) {$getgeo = 1}
				}
			} else {$getgeo = 1}
			if ($getgeo) {
				unless (-e $config{GUNZIP}) {
					logfile("Error: gunzip binary ($config{GUNZIP}) does not exist");
					exit;
				}
				logfile("CCL: Retrieving CC Lookup database [$config{cc_cc}]");
				my ($status, $text) = $urlget->urlget("$config{cc_cc}","/var/lib/csf/Geo/countryInfo.txt");
				if ($status) {
					logfile("CCL Error: Unable to retrieve $config{cc_src} CC Lookup database [$config{cc_cc}] - $text");
				} else {
					if (-z "/var/lib/csf/Geo/countryInfo.txt" or !(-e "/var/lib/csf/Geo/countryInfo.txt")) {
						logfile("CC Error: countryInfo.txt empty or missing");
					}
				}
				if ($config{CC_LOOKUPS} == 2 or $config{CC_LOOKUPS} == 3) {
					logfile("CCL: Retrieving $config{cc_src} City database [$config{cc_city}]");
					my ($status, $text) = $urlget->urlget("$config{cc_city}","/var/lib/csf/Geo/dbip-city-lite.csv.gz");
					if ($status) {
						logfile("CCL Error: Unable to retrieve $config{cc_src} City database [$config{cc_city}] - $text");
					} else {
						if (-e "/var/lib/csf/Geo/dbip-city-lite.csv") { unlink "/var/lib/csf/Geo/dbip-city-lite.csv"}
						my @data;
						eval {
							local $SIG{__DIE__} = undef;
							local $SIG{'ALRM'} = sub {die};
							alarm(180);
							@data = &syscommand(__LINE__,$config{GUNZIP},"/var/lib/csf/Geo/dbip-city-lite.csv.gz");
							alarm(0);
						};
						alarm(0);
						if ($@) {
							logfile("CCL Error: Unable to gunzip $config{cc_src} City database /var/lib/csf/Geo/dbip-city-lite.csv.gz - timeout");
						}
						if (-z "/var/lib/csf/Geo/dbip-city-lite.csv" or !(-e "/var/lib/csf/Geo/dbip-city-lite.csv")) {
							logfile("CCL Error: dbip-city-lite.csv empty or missing");
						}
					}
					if ($config{CC_LOOKUPS} == 3) {
						logfile("CCL: Retrieving $config{asn_src} ASN database [$config{cc_asn}]");
						($status, $text) = $urlget->urlget("$config{cc_asn}","/var/lib/csf/Geo/ip2asn-combined.tsv.gz");
						if ($status) {
							logfile("CCL Error: Unable to retrieve $config{asn_src} ASN database [$config{cc_asn}] - $text");
						} else {
							if (-e "/var/lib/csf/Geo/ip2asn-combined.tsv") { unlink "/var/lib/csf/Geo/ip2asn-combined.tsv"}
							my @data;
							eval {
								local $SIG{__DIE__} = undef;
								local $SIG{'ALRM'} = sub {die};
								alarm(180);
								@data = &syscommand(__LINE__,$config{GUNZIP},"/var/lib/csf/Geo/ip2asn-combined.tsv.gz");
								alarm(0);
							};
							alarm(0);
							if ($@) {
								logfile("CCL Error: Unable to unzip $config{cc_src} Country database /var/lib/csf/Geo/ip2asn-combined.tsv.gz - timeout");
							}
							if (-z "/var/lib/csf/Geo/ip2asn-combined.tsv" or !(-e "/var/lib/csf/Geo/ip2asn-combined.tsv")) {
								logfile("CCL Error: ip2asn-combined.tsv empty or missing");
							}
						}
					}
				} else {
					logfile("CC: Retrieving $config{cc_src} Country database [$config{cc_country}]");
					my ($status, $text) = $urlget->urlget("$config{cc_country}","/var/lib/csf/Geo/dbip-country-lite.csv.gz");
					if ($status) {
						logfile("CCL Error: Unable to retrieve $config{cc_src} Country database [$config{cc_country}] - $text");
					} else {
						if (-e "/var/lib/csf/Geo/dbip-country-lite.csv") { unlink "/var/lib/csf/Geo/dbip-country-lite.csv"}
						my @data;
						eval {
							local $SIG{__DIE__} = undef;
							local $SIG{'ALRM'} = sub {die};
							alarm(180);
							@data = &syscommand(__LINE__,$config{GUNZIP},"/var/lib/csf/Geo/dbip-country-lite.csv.gz");
							alarm(0);
						};
						alarm(0);
						if ($@) {
							logfile("CC Error: Unable to gunzip $config{cc_src} Country database /var/lib/csf/Geo/dbip-country-lite.csv.gz - timeout");
						}
						if (-z "/var/lib/csf/Geo/dbip-country-lite.csv" or !(-e "/var/lib/csf/Geo/dbip-country-lite.csv")) {
							logfile("CC Error: dbip-country-lite.csv empty or missing");
						}
					}
				}
			}
		}

		&listlock("unlock");
		close ($THISLOCK );
		if ($config{DEBUG} >= 3) {$timer = &timer("stop","countrycodelookups",$timer)}
		$0 = "lfd - child closing";
		exit;
	}
	return;
}
# end countrycodelookups
###############################################################################
# start countrycode6
sub countrycode6 {
	my $force = shift;
	my $getgeo;
	my %cclist;
	my $redo_deny = 0;
	my $redo_allow = 0;
	my $redo_allow_filter = 0;
	my $redo_allow_ports = 0;
	my $redo_deny_ports = 0;
	my $redo_allow_smtpauth = 0;
	my $drop = $config{DROP};
	if ($config{DROP_IP_LOGGING}) {$drop = "CCDROP"}

	$config{CC_DENY} =~ s/\s//g;
	$config{CC_ALLOW} =~ s/\s//g;
	$config{CC_ALLOW_FILTER} =~ s/\s//g;
	$config{CC_ALLOW_PORTS} =~ s/\s//g;
	$config{CC_DENY_PORTS} =~ s/\s//g;
	$config{CC_ALLOW_SMTPAUTH} =~ s/\s//g;

	if ($force) {
		$redo_deny = 1;
		$redo_allow = 1;
		$redo_allow_filter = 1;
		$redo_allow_ports = 1;
		$redo_deny_ports = 1;
		$redo_allow_smtpauth = 1;
	}

	$0 = "lfd - processing countrycode6 lists";
	foreach my $cc (split(/\,/,"$config{CC_DENY},$config{CC_ALLOW},$config{CC_ALLOW_FILTER},$config{CC_ALLOW_PORTS},$config{CC_DENY_PORTS},$config{CC_ALLOW_SMTPAUTH}")) {
		if ($cc eq "") { next }
		$cc = lc $cc;
		if (-e "/var/lib/csf/zone/$cc.zone6") {
			my $mtime = (stat("/var/lib/csf/zone/$cc.zone6"))[9];
			my $days = int((time - $mtime) / 86400);
			if ($days >= $config{CC_INTERVAL}) {$getgeo = 1; $cclist{$cc} = 1}
		} else {$getgeo = 1;  $cclist{$cc} = 1}
		if (-z "/var/lib/csf/zone/$cc.zone6") {$getgeo = 1;  $cclist{$cc} = 1}

		if ($cclist{$cc}) {
			if ($config{CC_DENY} =~ /\b$cc\b/i) {$redo_deny = 1}
			if ($config{CC_ALLOW} =~ /\b$cc\b/i) {$redo_allow = 1}
			if ($config{CC_ALLOW_FILTER} =~ /\b$cc\b/i) {$redo_allow_filter = 1}
			if ($config{CC_ALLOW_PORTS} =~ /\b$cc\b/i) {$redo_allow_ports = 1}
			if ($config{CC_DENY_PORTS} =~ /\b$cc\b/i) {$redo_deny_ports = 1}
			if ($config{CC_ALLOW_SMTPAUTH} =~ /\b$cc\b/i) {$redo_allow_smtpauth = 1}
		}
	}

	if ($config{CC_SRC} eq "" or $config{CC_SRC} eq "1") {
		if ($getgeo) {
			logfile("CC: Processing $config{cc_src} Country/ASN IPv6 database");
			my ($ccbyiso,$ccbyasn) = &ccindex(\%cclist);
			my %dcidr;
			my %geoid;
			open (my $GEO, "<", "/var/lib/csf/Geo/GeoLite2-Country-Locations-en.csv");
			flock ($GEO, LOCK_SH);
			while (my $record = <$GEO>) {
				chomp $record;
				$record =~ s/\"//g;
				my ($geoname_id,undef,undef,undef,$country_iso_code,undef) = split (/\,/,$record);
				foreach my $cc (@{$ccbyiso->{uc $country_iso_code} || []}) {
					push @{$geoid{$geoname_id}}, $cc;
				}
			}
			close ($GEO);
			open (my $IN, "<", "/var/lib/csf/Geo/GeoLite2-Country-Blocks-IPv6.csv");
			flock ($IN, LOCK_SH);
			while (my $record = <$IN>) {
				chomp $record;
				$record =~ s/\"//g;
				my ($range,$geoname_id,undef) = split (/\,/,$record);
				foreach my $cc (@{$geoid{$geoname_id} || []}) {
					$dcidr{$cc}{$range} = 1;
				}
			}
			close ($IN);
			open ($IN, "<", "/var/lib/csf/Geo/GeoLite2-ASN-Blocks-IPv6.csv");
			flock ($IN, LOCK_SH);
			while (my $record = <$IN>) {
				chomp $record;
				$record =~ s/\"//g;
				my ($range,$asn,undef) = split (/\,/,$record);
				foreach my $cc (@{$ccbyasn->{$asn} || []}) {
					$dcidr{$cc}{$range} = 1;
				}
			}
			close ($IN);
			foreach my $cc (keys %cclist) {
				logfile("CC: Extracting zone from $config{cc_src} Country/ASN IPv6 database for [".uc($cc)."]");
				if (keys %{$dcidr{$cc}} eq 0) {
					if (length($cc) == 2) {
						logfile("CC: No IPv6 entries found for [".uc($cc)."] in /var/lib/csf/Geo/GeoLite2-Country-Blocks-IPv6.csv");
						&ccemptyzone("/var/lib/csf/zone/$cc.zone6","/var/lib/csf/Geo/GeoLite2-Country-Blocks-IPv6.csv");
					} else {
						logfile("CC: No IPv6 entries found for [".uc($cc)."] in /var/lib/csf/Geo/GeoLite2-ASN-Blocks-IPv6.csv");
						&ccemptyzone("/var/lib/csf/zone/$cc.zone6","/var/lib/csf/Geo/GeoLite2-ASN-Blocks-IPv6.csv");
					}
				} else {
					sysopen (my $CIDROUT, "/var/lib/csf/zone/$cc.zone6", O_WRONLY | O_CREAT);
					flock ($CIDROUT, LOCK_EX);
					seek ($CIDROUT, 0, 0);
					truncate ($CIDROUT, 0);
					foreach my $key (keys %{$dcidr{$cc}}) {print $CIDROUT "$key\n"}
					close ($CIDROUT);
				}
			}
		}
	} elsif ($config{CC_SRC} eq "2") {
		if ($getgeo) {
			logfile("CC: Processing $config{cc_src} Country/ASN IPv6 database");
			my (undef,$ccbyasn) = &ccindex(\%cclist);
			my %dcidr;
			open ($IN, "<", "/var/lib/csf/Geo/ip2asn-combined.tsv");
			flock ($IN, LOCK_SH);
			while (my $record = <$IN>) {
				chomp $record;
				$record =~ s/\"//g;
				my ($start,$end,$asn,undef) = split (/\t/,$record);
				if (checkip($start) == 4) { next }
				foreach my $cc (@{$ccbyasn->{$asn} || []}) {
					my $ipscidr = Net::CIDR::Lite->new;
					eval {local $SIG{__DIE__} = undef; $ipscidr->add_range("$start-$end")};
					my @cidr_list = $ipscidr->list;
					foreach my $list (@cidr_list) {
						$dcidr{$cc}{$list} = 1;
					}
				}
			}
			close ($IN);
			foreach my $cc (keys %cclist) {
				if (length($cc) > 2) {
					logfile("CC: Extracting IPv6 zone from $config{asn_src} ASN database for [".uc($cc)."]");
					if (keys %{$dcidr{$cc}} eq 0) {
						logfile("CC: No entries found for [".uc($cc)."] in /var/lib/csf/Geo/ip2asn-combined.tsv");
						&ccemptyzone("/var/lib/csf/zone/$cc.zone6","/var/lib/csf/Geo/ip2asn-combined.tsv");
					} else {
						sysopen (my $CIDROUT, "/var/lib/csf/zone/$cc.zone6", O_WRONLY | O_CREAT);
						flock ($CIDROUT, LOCK_EX);
						seek ($CIDROUT, 0, 0);
						truncate ($CIDROUT, 0);
						foreach my $key (keys %{$dcidr{$cc}}) {print $CIDROUT "$key\n"}
						close ($CIDROUT);
					}
				}
				elsif (length($cc) == 2) {
					logfile("CC: Retrieving $config{ccl_src} Country Code IPv6 Zone [".uc($cc)."] from https://www.ipdeny.com");
					my ($status, $text) = $urlget->urlget("https://www.ipdeny.com/ipv6/ipaddresses/aggregated/${cc}-aggregated.zone","/var/lib/csf/zone/$cc.zone6");
					if ($status) {
						logfile("CC Error: Unable to retrieve $config{ccl_src} Country Code IPv6 Zone [".uc($cc)."] from https://www.ipdeny.com - $text");
					} else {
						logfile("CC: Country Code IPv6 Zone [".uc($cc)."] retrieved");
					}
					sleep 1;
				}
			}
		}
	}

	if ($config{LF_IPSET}) {
		my $cclist;
		my $cnt = 0;
		if ($redo_deny) {$cclist .= $config{CC_DENY}.","}
		if ($redo_allow) {$cclist .= $config{CC_ALLOW}.","}
		if ($redo_allow_filter) {$cclist .= $config{CC_ALLOW_FILTER}.","}
		if ($redo_allow_ports) {$cclist .= $config{CC_ALLOW_PORTS}.","}
		if ($redo_deny_ports) {$cclist .= $config{CC_DENY_PORTS}}
		if ($config{CC_ALLOW_FILTER} and $redo_allow_filter) {&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -F CC_ALLOWF")}
		foreach my $cc (split(/\,/,$cclist)) {
			if ($cc eq "") { next }
			undef @ipset;
			$cc = lc $cc;
			if ($config{CC_ALLOW_FILTER} and $redo_allow_filter) {&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -A CC_ALLOWF -m set --match-set cc_6_$cc src -j RETURN")}
			if (-e "/var/lib/csf/zone/$cc.zone6") {
				logfile("CC: Repopulating ipset cc_6_$cc with IP addresses from [".uc($cc)."]");
				open (my $IN, "<", "/var/lib/csf/zone/$cc.zone6");
				flock ($IN, LOCK_SH);
				while (my $line = <$IN>) {
					chomp $line;
					my ($ip,undef) = split (/\s/,$line,2);
					if ($config{CC_DROP_CIDR} > 0 and $config{CC_DROP_CIDR} < 33) {
						my ($drop_ip,$drop_cidr) = split(/\//,$ip);
						if ($drop_cidr eq "") {$drop_cidr = "32"}
						if ($drop_cidr > $config{CC_DROP_CIDR}) { next }
					}
					if (cccheckip(\$ip)) {
						push @ipset,"add new_6_$cc $ip";
						$cnt++;
					}
				}
				&ipsetrestore("new_6_$cc");
				&ipsetswap("new_6_$cc","cc_6_$cc");
			}
		}
		if ($config{CC_ALLOW_FILTER} and $redo_allow_filter and $cnt > 0) {
			&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -A CC_ALLOWF -j $drop");
			if ($config{IPV6_SPI}) {
				my $statemodule = "-m state --state";
				if ($config{USE_FTPHELPER}) {
					&syscommand(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -I CC_ALLOWF $ethdevin $statemodule RELATED -m helper --helper ftp -j $accept");

					&syscommand(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -I CC_ALLOWF $ethdevin $statemodule ESTABLISHED -j $accept");
				} else {
					&syscommand(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -I CC_ALLOWF $ethdevin $statemodule ESTABLISHED,RELATED -j $accept");
				}
				&syscommand(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT}  -I CC_ALLOWF $eth6devin -p icmpv6 -j $accept");
			}
		}
	} else {
		if ($config{CC_DENY} and $redo_deny) {
			if (&csflock) {&lockfail("CC_DENY")}
			if ($config{SAFECHAINUPDATE}) {
				&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -N NEWCC_DENY");
			} else {
				&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -F CC_DENY");
			}
			foreach my $cc (split(/\,/,$config{CC_DENY})) {
				$cc = lc $cc;
				if (-e "/var/lib/csf/zone/$cc.zone6") {
					if ($config{FASTSTART}) {$faststart = 1}
					logfile("CC: Repopulating CC_DENY with IP addresses from [".uc($cc)."]");
					open (my $IN, "<", "/var/lib/csf/zone/$cc.zone6");
					flock ($IN, LOCK_SH);
					while (my $line = <$IN>) {
						chomp $line;
						my ($ip,undef) = split (/\s/,$line,2);
						if (cccheckip(\$ip)) {
							if ($config{SAFECHAINUPDATE}) {
								&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -A NEWCC_DENY -s $ip -j $drop");
							} else {
								&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -A CC_DENY -s $ip -j $drop");
							}
						}
					}
					close ($IN);
					if ($config{FASTSTART}) {&faststart("CC_DENY [".uc($cc)."]")}
					logfile("CC: Finished repopulating CC_DENY with IP addresses from [".uc($cc)."]");
				}
			}
			if ($config{SAFECHAINUPDATE}) {
				&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -A LOCALINPUT $ethdevin -j NEWCC_DENY");
				&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -D LOCALINPUT $ethdevin -j CC_DENY");
				&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -F CC_DENY");
				&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -X CC_DENY");
				&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -E NEWCC_DENY CC_DENY");
			}
		}

		if ($config{CC_ALLOW} and $redo_allow) {
			if (&csflock) {&lockfail("CC_ALLOW")}
			if ($config{SAFECHAINUPDATE}) {
				&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -N NEWCC_ALLOW");
			} else {
				&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -F CC_ALLOW");
			}
			foreach my $cc (split(/\,/,$config{CC_ALLOW})) {
				$cc = lc $cc;
				if (-e "/var/lib/csf/zone/$cc.zone6") {
					if ($config{FASTSTART}) {$faststart = 1}
					logfile("CC: Repopulating CC_ALLOW with IP addresses from [".uc($cc)."]");
					open (my $IN, "<", "/var/lib/csf/zone/$cc.zone6");
					flock ($IN, LOCK_SH);
					while (my $line = <$IN>) {
						chomp $line;
						my ($ip,undef) = split (/\s/,$line,2);
						if (cccheckip(\$ip)) {
							if ($config{SAFECHAINUPDATE}) {
								&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -A NEWCC_ALLOW -s $ip -j $accept");
							} else {
								&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -A CC_ALLOW -s $ip -j $accept");
							}
						}
					}
					close ($IN);
					if ($config{FASTSTART}) {&faststart("CC_ALLOW [".uc($cc)."]")}
					logfile("CC: Finished repopulating CC_ALLOW with IP addresses from [".uc($cc)."]");
				}
			}
			if ($config{SAFECHAINUPDATE}) {
				&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -I LOCALINPUT $ethdevin -j NEWCC_ALLOW");
				&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -D LOCALINPUT $ethdevin -j CC_ALLOW");
				&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -F CC_ALLOW");
				&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -X CC_ALLOW");
				&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -E NEWCC_ALLOW CC_ALLOW");
			}
		}

		if ($config{CC_ALLOW_FILTER} and $redo_allow_filter) {
			my $cnt = 0;
			if (&csflock) {&lockfail("CC_ALLOW_FILTER")}
			if ($config{SAFECHAINUPDATE}) {
				&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -N NCC_ALLOWF");
			} else {
				&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -F CC_ALLOWF");
			}
			foreach my $cc (split(/\,/,$config{CC_ALLOW_FILTER})) {
				$cc = lc $cc;
				if (-e "/var/lib/csf/zone/$cc.zone6") {
					if ($config{FASTSTART}) {$faststart = 1}
					logfile("CC: Repopulating CC_ALLOWF with IP addresses from [".uc($cc)."]");
					open (my $IN, "<", "/var/lib/csf/zone/$cc.zone6");
					flock ($IN, LOCK_SH);
					while (my $line = <$IN>) {
						chomp $line;
						my ($ip,undef) = split (/\s/,$line,2);
						if (cccheckip(\$ip)) {
							$cnt++;
							if ($config{SAFECHAINUPDATE}) {
								&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -A NCC_ALLOWF -s $ip -j RETURN");
							} else {
								&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -A CC_ALLOWF -s $ip -j RETURN");
							}
						}
					}
					close ($IN);
					if ($config{FASTSTART}) {&faststart("CC_ALLOW_FILTER [".uc($cc)."]")}
					logfile("CC: Finished repopulating CC_ALLOWF with IP addresses from [".uc($cc)."]");
				}
			}
			if ($config{SAFECHAINUPDATE}) {
				if ($cnt > 0) {&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -A NCC_ALLOWF -j $drop")}
				&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -A LOCALINPUT $ethdevin -j NCC_ALLOWF");
				&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -D LOCALINPUT $ethdevin -j CC_ALLOWF");
				&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -F CC_ALLOWF");
				&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -X CC_ALLOWF");
				&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -E NCC_ALLOWF CC_ALLOWF");
			} else {
				if ($cnt > 0) {
					&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -A CC_ALLOWF -j $drop");
					if ($config{IPV6_SPI}) {
						my $statemodule = "-m state --state";
						if ($config{USE_FTPHELPER}) {
							&syscommand(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -I CC_ALLOWF $ethdevin $statemodule RELATED -m helper --helper ftp -j $accept");

							&syscommand(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -I CC_ALLOWF $ethdevin $statemodule ESTABLISHED -j $accept");
						} else {
							&syscommand(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -I CC_ALLOWF $ethdevin $statemodule ESTABLISHED,RELATED -j $accept");
						}
						&syscommand(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT}  -I CC_ALLOWF $eth6devin -p icmpv6 -j $accept");
					}
				}
			}
		}

		if ($config{CC_ALLOW_PORTS} and $redo_allow_ports) {
			my $cnt = 0;
			if (&csflock) {&lockfail("CC_ALLOW_PORTS")}
			if ($config{SAFECHAINUPDATE}) {
				&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -N NCC_ALLOWP");
			} else {
				&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -F CC_ALLOWP");
			}
			foreach my $cc (split(/\,/,$config{CC_ALLOW_PORTS})) {
				$cc = lc $cc;
				if (-e "/var/lib/csf/zone/$cc.zone6") {
					if ($config{FASTSTART}) {$faststart = 1}
					logfile("CC: Repopulating CC_ALLOWP with IP addresses from [".uc($cc)."]");
					open (my $IN, "<", "/var/lib/csf/zone/$cc.zone6");
					flock ($IN, LOCK_SH);
					while (my $line = <$IN>) {
						chomp $line;
						my ($ip,undef) = split (/\s/,$line,2);
						if (cccheckip(\$ip)) {
							$cnt++;
							if ($config{SAFECHAINUPDATE}) {
								&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -A NCC_ALLOWP -s $ip -j CC_ALLOWPORTS");
							} else {
								&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -A CC_ALLOWP -s $ip -j CC_ALLOWPORTS");
							}
						}
					}
					close ($IN);
					if ($config{FASTSTART}) {&faststart("CC_ALLOW_PORTS [".uc($cc)."]")}
					logfile("CC: Finished repopulating CC_ALLOWP with IP addresses from [".uc($cc)."]");
				}
			}
			if ($config{SAFECHAINUPDATE}) {
				&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -A LOCALINPUT $ethdevin -j NCC_ALLOWP");
				&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -D LOCALINPUT $ethdevin -j CC_ALLOWP");
				&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -F CC_ALLOWP");
				&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -X CC_ALLOWP");
				&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -E NCC_ALLOWP CC_ALLOWP");
			}
		}

		if ($config{CC_DENY_PORTS} and $redo_deny_ports) {
			my $cnt = 0;
			if (&csflock) {&lockfail("CC_DENY_PORTS")}
			if ($config{SAFECHAINUPDATE}) {
				&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -N NCC_DENYP");
			} else {
				&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -F CC_DENYP");
			}
			foreach my $cc (split(/\,/,$config{CC_DENY_PORTS})) {
				$cc = lc $cc;
				if (-e "/var/lib/csf/zone/$cc.zone6") {
					if ($config{FASTSTART}) {$faststart = 1}
					logfile("CC: Repopulating CC_DENYP with IP addresses from [".uc($cc)."]");
					open (my $IN, "<", "/var/lib/csf/zone/$cc.zone6");
					flock ($IN, LOCK_SH);
					while (my $line = <$IN>) {
						chomp $line;
						my ($ip,undef) = split (/\s/,$line,2);
						if (cccheckip(\$ip)) {
							$cnt++;
							if ($config{SAFECHAINUPDATE}) {
								&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -A NCC_DENYP -s $ip -j CC_DENYPORTS");
							} else {
								&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -A CC_DENYP -s $ip -j CC_DENYPORTS");
							}
						}
					}
					close ($IN);
					if ($config{FASTSTART}) {&faststart("CC_DENY_PORTS [".uc($cc)."]")}
					logfile("CC: Finished repopulating CC_DENYP with IP addresses from [".uc($cc)."]");
				}
			}
			if ($config{SAFECHAINUPDATE}) {
				&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -A LOCALINPUT $ethdevin -j NCC_DENYP");
				&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -D LOCALINPUT $ethdevin -j CC_DENYP");
				&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -F CC_DENYP");
				&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -X CC_DENYP");
				&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -E NCC_DENYP CC_DENYP");
			}
		}
	}
	return;
}
# end countrycode6
###############################################################################
# start global
sub global {
	$SIG{CHLD} = 'IGNORE';
	unless (defined ($childpid = fork)) {
		&shutdown(__LINE__,"*Error* cannot fork: $!");
	} 
	$forks{$childpid} = 1;
	unless ($childpid) {
		my $timer = time;
		if ($config{DEBUG} >= 3) {$timer = &timer("start","global",$timer)}
		$0 = "lfd - retrieving global lists";

		my $lockstr = "LF_GLOBAL";
		sysopen (my $THISLOCK, "/var/lib/csf/lock/$lockstr.lock", O_RDWR | O_CREAT) or &shutdown_child("*Error* Unable to open /var/lib/csf/lock/$lockstr.lock");
		flock ($THISLOCK, LOCK_EX | LOCK_NB) or &shutdown_child("*Lock Error* [$lockstr] still active - section skipped");
		print $THISLOCK time;

		$0 = "lfd - retrieving global lists (waiting for list lock)";
		&listlock("lock");
		$0 = "lfd - retrieving global lists";

		if ($config{GLOBAL_ALLOW}) {
			my ($status, $text) = $urlget->urlget($config{GLOBAL_ALLOW});
			if ($status) {
				logfile("Unable to retrieve global allow list - $text");
			} else {
				if (&csflock) {&lockfail("GLOBAL_ALLOW")}
				logfile("Global Allow - retrieved and allowing IP address ranges");

				if ($config{SAFECHAINUPDATE}) {
					&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -N NEWGALLOWIN");
					&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -N NEWGALLOWOUT");
					if ($config{LF_IPSET}) {
						&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -A NEWGALLOWIN -m set --match-set chain_GALLOW src -j $accept");
						&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -A NEWGALLOWOUT -m set --match-set chain_GALLOW dst -j $accept");
						&ipsetcreate("chain_NEWGALLOW");
					}
					if ($config{IPV6}) {
						&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -N NEWGALLOWIN");
						&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -N NEWGALLOWOUT");
						if ($config{LF_IPSET}) {
							&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -A NEWGALLOWIN -m set --match-set chain_6_GALLOW src -j $accept");
							&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -A NEWGALLOWOUT -m set --match-set chain_6_GALLOW dst -j $accept");
							&ipsetcreate("chain_6_NEWGALLOW");
						}
					}
				} else {
					&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -F GALLOWIN");
					&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -F GALLOWOUT");
					if ($config{LF_IPSET}) {
						&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -A GALLOWIN -m set --match-set chain_GALLOW src -j $accept");
						&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -A GALLOWOUT -m set --match-set chain_GALLOW dst -j $accept");
						&ipsetflush("chain_GALLOW");
					}
					if ($config{IPV6}) {
						&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -F GALLOWIN");
						&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -F GALLOWOUT");
						if ($config{LF_IPSET}) {
							&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -A GALLOWIN -m set --match-set chain_6_GALLOW src -j $accept");
							&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -A GALLOWOUT -m set --match-set chain_6_GALLOW dst -j $accept");
							&ipsetflush("chain_6_GALLOW");
						}
					}
				}

                logfile( "normal", "info", "Global Allow: checking file [ csf.gallow ]" );
				sysopen (my $GALLOW, "/var/lib/csf/csf.gallow", O_WRONLY | O_CREAT) or &shutdown_child(__LINE__,"*Error* Cannot open out file: $!");
				flock ($GALLOW, LOCK_EX);
				seek ($GALLOW, 0, 0);
				truncate ($GALLOW, 0);
				if ($config{FASTSTART}) {$faststart = 1}
				foreach my $line (split (/\n/,$text)) {
					if ($line =~ /^\s*(?:\#|$)/) { next }
                    logfile( "debug:1", "info", "Global Allow: Process csf.gallow line [ $line ]" );
					my ($ip,$comment) = split (/\s/,$line,2);
					print $GALLOW "$ip\n";
					if ($config{SAFECHAINUPDATE}) {
						&linefilter($ip, "allow","NEWGALLOW");
					} else {
						&linefilter($ip, "allow","GALLOW");
					}
				}
				if ($config{FASTSTART}) {&faststart("GLOBAL_ALLOW")}
				close ($GALLOW);
				if ($config{SAFECHAINUPDATE}) {
					&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -I LOCALINPUT $ethdevin -j NEWGALLOWIN");
					&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -I LOCALOUTPUT $ethdevout -j NEWGALLOWOUT");
					&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -D LOCALINPUT $ethdevin -j GALLOWIN");
					&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -D LOCALOUTPUT $ethdevout -j GALLOWOUT");
					&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -F GALLOWIN");
					&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -F GALLOWOUT");
					&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -X GALLOWIN");
					&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -X GALLOWOUT");
					&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -E NEWGALLOWIN GALLOWIN");
					&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -E NEWGALLOWOUT GALLOWOUT");
					if ($config{IPV6}) {
						&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -I LOCALINPUT $eth6devin -j NEWGALLOWIN");
						&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -I LOCALOUTPUT $eth6devout -j NEWGALLOWOUT");
						&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -D LOCALINPUT $eth6devin -j GALLOWIN");
						&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -D LOCALOUTPUT $eth6devout -j GALLOWOUT");
						&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -F GALLOWIN");
						&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -F GALLOWOUT");
						&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -X GALLOWIN");
						&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -X GALLOWOUT");
						&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -E NEWGALLOWIN GALLOWIN");
						&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -E NEWGALLOWOUT GALLOWOUT");
					}
					if ($config{LF_IPSET}) {
						&ipsetswap("chain_NEWGALLOW","chain_GALLOW");
						if ($config{IPV6}) {
							&ipsetswap("chain_6_NEWGALLOW","chain_6_GALLOW");
						}
					}
				}
			}
		}

		if ($config{GLOBAL_DENY}) {
			my ($status, $text) = $urlget->urlget($config{GLOBAL_DENY});
			if ($status) {
				logfile("Unable to retrieve global deny list - $text");
			} else {
				if (&csflock) {&lockfail("GLOBAL_DENY")}
				logfile("Global Deny - retrieved and blocking IP address ranges");
				my $drop = $config{DROP};
				if ($config{DROP_IP_LOGGING}) {$drop = "BLOCKDROP"}

				if ($config{SAFECHAINUPDATE}) {
					&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -N NEWGDENYIN");
					&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -N NEWGDENYOUT");
					if ($config{LF_IPSET}) {
						my $pktin = $config{DROP};
						my $pktout = $config{DROP_OUT};
						if ($config{DROP_IP_LOGGING}) {$pktin = "LOGDROPIN"}
						if ($config{DROP_OUT_LOGGING}) {$pktout = "LOGDROPOUT"}
						&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -A NEWGDENYIN -m set --match-set chain_GDENY src -j $pktin");
						unless ($config{LF_BLOCKINONLY}) {&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -A NEWGDENYOUT -m set --match-set chain_GDENY dst -j $pktout")}
						&ipsetcreate("chain_NEWGDENY");
					}
					if ($config{IPV6}) {
						&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -N NEWGDENYIN");
						&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -N NEWGDENYOUT");
						if ($config{LF_IPSET}) {
							my $pktin = $config{DROP};
							my $pktout = $config{DROP_OUT};
							if ($config{DROP_IP_LOGGING}) {$pktin = "LOGDROPIN"}
							if ($config{DROP_OUT_LOGGING}) {$pktout = "LOGDROPOUT"}
							&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -A NEWGDENYIN -m set --match-set chain_6_GDENY src -j $pktin");
							unless ($config{LF_BLOCKINONLY}) {&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -A NEWGDENYOUT -m set --match-set chain_6_GDENY dst -j $pktout")}
							&ipsetcreate("chain_6_NEWGDENY");
						}
					}
				} else {
					&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -F GDENYIN");
					&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -F GDENYOUT");
					if ($config{LF_IPSET}) {
						my $pktin = $config{DROP};
						my $pktout = $config{DROP_OUT};
						if ($config{DROP_IP_LOGGING}) {$pktin = "LOGDROPIN"}
						if ($config{DROP_OUT_LOGGING}) {$pktout = "LOGDROPOUT"}
						&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -A GDENYIN -m set --match-set chain_GDENY src -j $pktin");
						unless ($config{LF_BLOCKINONLY}) {&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -A GDENYOUT -m set --match-set chain_GDENY dst -j $pktout")}
						&ipsetflush("chain_GDENY");
					}
					if ($config{IPV6}) {
						&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -F GDENYIN");
						&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -F GDENYOUT");
						if ($config{LF_IPSET}) {
							my $pktin = $config{DROP};
							my $pktout = $config{DROP_OUT};
							if ($config{DROP_IP_LOGGING}) {$pktin = "LOGDROPIN"}
							if ($config{DROP_OUT_LOGGING}) {$pktout = "LOGDROPOUT"}
							&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -A GDENYIN -m set --match-set chain_6_GDENY src -j $pktin");
							unless ($config{LF_BLOCKINONLY}) {&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -A GDENYOUT -m set --match-set chain_6_GDENY dst -j $pktout")}
							&ipsetflush("chain_6_GDENY");
						}
					}
				}
				sysopen (my $GDENY, "/var/lib/csf/csf.gdeny", O_WRONLY | O_CREAT) or &shutdown_child(__LINE__,"*Error* Cannot open out file: $!");
				flock ($GDENY, LOCK_EX);
				seek ($GDENY, 0, 0);
				truncate ($GDENY, 0);
				if ($config{FASTSTART}) {$faststart = 1}
				foreach my $line (split (/\n/,$text)) {
					if ($line =~ /^\#/) { next }
					my ($ip,$comment) = split (/\s/,$line,2);
					print $GDENY "$ip\n";
					if ($config{SAFECHAINUPDATE}) {
						&linefilter($ip, "deny","NEWGDENY");
					} else {
						&linefilter($ip, "deny","GDENY");
					}
				}
				if ($config{FASTSTART}) {&faststart("GLOBAL_DENY")}
				close ($GDENY);
				if ($config{SAFECHAINUPDATE}) {
					&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -A LOCALINPUT $ethdevin -j NEWGDENYIN");
					&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -A LOCALOUTPUT $ethdevout -j NEWGDENYOUT");
					&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -D LOCALINPUT $ethdevin -j GDENYIN");
					&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -D LOCALOUTPUT $ethdevout -j GDENYOUT");
					&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -F GDENYIN");
					&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -F GDENYOUT");
					&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -X GDENYIN");
					&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -X GDENYOUT");
					&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -E NEWGDENYIN GDENYIN");
					&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -E NEWGDENYOUT GDENYOUT");
					if ($config{IPV6}) {
						&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -A LOCALINPUT $eth6devin -j NEWGDENYIN");
						&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -A LOCALOUTPUT $eth6devout -j NEWGDENYOUT");
						&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -D LOCALINPUT $eth6devin -j GDENYIN");
						&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -D LOCALOUTPUT $eth6devout -j GDENYOUT");
						&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -F GDENYIN");
						&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -F GDENYOUT");
						&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -X GDENYIN");
						&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -X GDENYOUT");
						&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -E NEWGDENYIN GDENYIN");
						&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -E NEWGDENYOUT GDENYOUT");
					}
					if ($config{LF_IPSET}) {
						&ipsetswap("chain_NEWGDENY","chain_GDENY");
						if ($config{IPV6}) {
							&ipsetswap("chain_6_NEWGDENY","chain_6_GDENY");
						}
					}
				}
			}
		}

		if ($config{GLOBAL_IGNORE}) {
			my ($status, $text) = $urlget->urlget($config{GLOBAL_IGNORE});
			if ($status) {
				logfile("Unable to retrieve global ignore list - $text");
			} else {
				logfile("Global Ignore - retrieved and ignoring");

				sysopen (my $GIGNORE, "/var/lib/csf/csf.gignore", O_WRONLY | O_CREAT) or &shutdown_child(__LINE__,"*Error* Cannot open out file: $!");
				flock ($GIGNORE, LOCK_EX);
				seek ($GIGNORE, 0, 0);
				truncate ($GIGNORE, 0);
				foreach my $line (split (/\n/,$text)) {
					if ($line =~ /^\#/) { next }
					my ($ip,$comment) = split (/\s/,$line,2);
					print $GIGNORE "$ip\n";
				}
				close ($GIGNORE);
			}
		}

		if ($config{GLOBAL_DYNDNS}) {
			my ($status, $text) = $urlget->urlget($config{GLOBAL_DYNDNS});
			if ($status) {
				logfile("Unable to retrieve global dyndns list - $text");
			} else {
				logfile("Global DynDNS - retrieved and allowing IP addresses");

				sysopen (my $GDYNDNS, "/var/lib/csf/csf.gdyndns", O_WRONLY | O_CREAT) or &shutdown_child(__LINE__,"*Error* Cannot open out file: $!");
				flock ($GDYNDNS, LOCK_EX);
				seek ($GDYNDNS, 0, 0);
				truncate ($GDYNDNS, 0);
				foreach my $line (split (/\n/,$text)) {
					if ($line =~ /^\#/) { next }
					my ($ip,$comment) = split (/\s/,$line,2);
					print $GDYNDNS "$ip\n";
				}
				close ($GDYNDNS);
				&globaldyndns;
			}
		}

		&listlock("unlock");
		close ($THISLOCK );
		if ($config{DEBUG} >= 3) {$timer = &timer("stop","global",$timer)}
		$0 = "lfd - child closing";
		exit;
	}
	return;
}
# end global
###############################################################################
# start dyndns
sub dyndns {
	$SIG{CHLD} = 'IGNORE';
	unless (defined ($childpid = fork)) {
		&shutdown(__LINE__,"*Error* cannot fork: $!");
	} 
	$forks{$childpid} = 1;
	unless ($childpid) {
		my $timer = time;
		if ($config{DEBUG} >= 3) {$timer = &timer("start","dyndns",$timer)}
		$0 = "lfd - resolving dyndns IP addresses";

		my $lockstr = "DYNDNS";
		sysopen (my $THISLOCK, "/var/lib/csf/lock/$lockstr.lock", O_RDWR | O_CREAT) or &shutdown_child("*Error* Unable to open /var/lib/csf/lock/$lockstr.lock");
		flock ($THISLOCK, LOCK_EX | LOCK_NB) or &shutdown_child("*Lock Error* [$lockstr] still active - section skipped");
		print $THISLOCK time;

		$0 = "lfd - resolving dyndns IP addresses (waiting for list lock)";
		&listlock("lock");
		$0 = "lfd - resolving dyndns IP addresses";

		my @dyndns;
		my @entries = slurp("/etc/csf/csf.dyndns");
		foreach my $line ( @entries ) {
			if ( $line =~ /^Include\s*(.*)$/ ) {
				my @incfile = slurp( $1 );
				push @entries, @incfile;
			}
		}
		foreach my $line ( @entries ) {
			$line =~ s/$cleanreg//g;
			if ( $line eq "" ) { next }
			if ( $line =~ /^\s*\#|Include/ ) { next }
			push @dyndns, $line;
		}

		if (&csflock) {&lockfail("DYNDNS")}
		if ($config{DEBUG} >= 1) {logfile("DynDNS - update IP addresses")}
		if ($config{SAFECHAINUPDATE}) {
			&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -N NEWALLOWDYNIN");
			&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -N NEWALLOWDYNOUT");
			if ($config{LF_IPSET}) {
				&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -A NEWALLOWDYNIN -m set --match-set chain_ALLOWDYN src -j $accept");
				&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -A NEWALLOWDYNOUT -m set --match-set chain_ALLOWDYN dst -j $accept");
			}
		} else {
			&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -F ALLOWDYNIN");
			&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -F ALLOWDYNOUT");
			if ($config{LF_IPSET}) {
				&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -A ALLOWDYNIN -m set --match-set chain_ALLOWDYN src -j $accept");
				&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -A ALLOWDYNOUT -m set --match-set chain_ALLOWDYN dst -j $accept");
			}
		}
		if ($config{IPV6}) {
			if ($config{SAFECHAINUPDATE}) {
				&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -N NEWALLOWDYNIN");
				&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -N NEWALLOWDYNOUT");
			} else {
				&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -F ALLOWDYNIN");
				&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -F ALLOWDYNOUT");
			}
		}
		sysopen (my $TEMPDYN, "/var/lib/csf/csf.tempdyn", O_WRONLY | O_CREAT) or &shutdown_child(__LINE__,"*Error* Cannot open out file: $!");
		flock ($TEMPDYN, LOCK_EX);
		seek ($TEMPDYN, 0, 0);
		truncate ($TEMPDYN, 0);
		foreach my $line (@dyndns) {
			my $adport;
			my ($fqdn,undef) = split(/\s/,$line,2);
			if ($fqdn =~ /^(.*(s|d)=)(.*)$/) {$adport = $1; $fqdn = $3}
			my @results = ConfigServer::GetIPs::resolve( $fqdn );
			if (@results) {
				foreach my $ip (@results) {
					if ($adport) {$ip = $adport.$ip}
					if ($config{SAFECHAINUPDATE}) {
						&linefilter($ip, "allow","NEWALLOWDYN");
					} else {
						&linefilter($ip, "allow","ALLOWDYN");
					}
					print $TEMPDYN "$ip\n";
				}
			} else {
				logfile ("DynDNS: Lookup for [$fqdn] failed");
			}
		}
		close ($TEMPDYN);
		if ($config{SAFECHAINUPDATE}) {
			&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -I LOCALINPUT $ethdevin -j NEWALLOWDYNIN");
			&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -I LOCALOUTPUT $ethdevout -j NEWALLOWDYNOUT");
			&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -D LOCALINPUT $ethdevin -j ALLOWDYNIN");
			&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -D LOCALOUTPUT $ethdevout -j ALLOWDYNOUT");
			&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -F ALLOWDYNIN");
			&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -F ALLOWDYNOUT");
			&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -X ALLOWDYNIN");
			&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -X ALLOWDYNOUT");
			&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -E NEWALLOWDYNIN ALLOWDYNIN");
			&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -E NEWALLOWDYNOUT ALLOWDYNOUT");
		}
		if ($config{IPV6}) {
			if ($config{SAFECHAINUPDATE}) {
				&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -I LOCALINPUT $ethdevin -j NEWALLOWDYNIN");
				&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -I LOCALOUTPUT $ethdevout -j NEWALLOWDYNOUT");
				&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -D LOCALINPUT $ethdevin -j ALLOWDYNIN");
				&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -D LOCALOUTPUT $ethdevout -j ALLOWDYNOUT");
				&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -F ALLOWDYNIN");
				&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -F ALLOWDYNOUT");
				&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -X ALLOWDYNIN");
				&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -X ALLOWDYNOUT");
				&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -E NEWALLOWDYNIN ALLOWDYNIN");
				&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -E NEWALLOWDYNOUT ALLOWDYNOUT");
			}
		}

		&listlock("unlock");
		close ($THISLOCK );
		if ($config{DEBUG} >= 3) {$timer = &timer("stop","dyndns",$timer)}
		$0 = "lfd - child closing";
		exit;
	}
	return;
}
# end dyndns
###############################################################################
# start globaldyndns
sub globaldyndns {
	$SIG{CHLD} = 'IGNORE';
	unless (defined ($childpid = fork)) {
		&shutdown(__LINE__,"*Error* cannot fork: $!");
	} 
	$forks{$childpid} = 1;
	unless ($childpid) {
		my $timer = time;
		if ($config{DEBUG} >= 3) {$timer = &timer("start","globaldyndns",$timer)}
		$0 = "lfd - resolving global dyndns IP addresses";

		my $lockstr = "GLOBAL_DYNDNS_INTERVAL";
		sysopen (my $THISLOCK, "/var/lib/csf/lock/$lockstr.lock", O_RDWR | O_CREAT) or &shutdown_child("*Error* Unable to open /var/lib/csf/lock/$lockstr.lock");
		flock ($THISLOCK, LOCK_EX | LOCK_NB) or &shutdown_child("*Lock Error* [$lockstr] still active - section skipped");
		print $THISLOCK time;

		$0 = "lfd - resolving global dyndns IP addresses (waiting for list lock)";
		&listlock("lock");
		$0 = "lfd - resolving global dyndns IP addresses";

		open (my $IN, "<", "/var/lib/csf/csf.gdyndns");
		flock ($IN, LOCK_SH);
		my @dyndns = <$IN>;
		close ($IN);
		chomp @dyndns;

		if (&csflock) {&lockfail("GLOBAL_DYNDNS_INTERVAL")}
		logfile("Global DynDNS - update IP addresses");
		if ($config{SAFECHAINUPDATE}) {
			&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -N NEWGDYNIN");
			&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -N NEWGDYNOUT");
			if ($config{LF_IPSET}) {
				&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -A NEWGDYNIN -m set --match-set chain_GDYN src -j $accept");
				&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -A NEWGDYNOUT -m set --match-set chain_GDYN dst -j $accept");
			}
		} else {
			&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -F GDYNIN");
			&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -F GDYNOUT");
			if ($config{LF_IPSET}) {
				&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -A GDYNIN -m set --match-set chain_GDYN src -j $accept");
				&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -A GDYNOUT -m set --match-set chain_GDYN dst -j $accept");
			}
		}
		if ($config{IPV6}) {
			if ($config{SAFECHAINUPDATE}) {
				&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -N NEWGDYNIN");
				&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -N NEWGDYNOUT");
				if ($config{LF_IPSET}) {
					&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -A NEWGDYNIN -m set --match-set chain_6_GDYN src -j $accept");
					&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -A NEWGDYNOUT -m set --match-set chain_6_GDYN dst -j $accept");
				}
			} else {
				&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -F GDYNIN");
				&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -F GDYNOUT");
				if ($config{LF_IPSET}) {
					&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -A GDYNIN -m set --match-set chain_6_GDYN src -j $accept");
					&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -A GDYNOUT -m set --match-set chain_6_GDYN dst -j $accept");
				}
			}
		}
		sysopen (my $TEMPDYN, "/var/lib/csf/csf.tempgdyn", O_WRONLY | O_CREAT) or &shutdown_child(__LINE__,"*Error* Cannot open out file: $!");
		flock ($TEMPDYN, LOCK_EX);
		seek ($TEMPDYN, 0, 0);
		truncate ($TEMPDYN, 0);
		foreach my $line (@dyndns) {
			if ($line =~ /^\#/) { next }
			if ( $line eq "" ) { next }
			if ($line =~ /^\n/) { next }
			if ($line =~ /^\r/) { next }
			if ($line =~ /^\s/) { next }
			my $ip;
			my $adport;
			my ($fqdn,undef) = split(/\s/,$line,2);
			if ($fqdn =~ /(.*:(s|d)=)(.*)$/) {$adport = $1; $fqdn = $3}
			my @results = ConfigServer::GetIPs::resolve( $fqdn );
			if (@results) {
				foreach my $ip (@results) {
					if ($adport) {$ip = $adport.$ip}
					if ($config{SAFECHAINUPDATE}) {
						&linefilter($ip, "allow","NEWGDYN");
					} else {
						&linefilter($ip, "allow","GDYN");
					}
					print $TEMPDYN "$ip\n";
				}
			} else {
				logfile ("Global DynDNS: Lookup for [$fqdn] failed");
			}
		}
		close ($TEMPDYN);
		if ($config{SAFECHAINUPDATE}) {
			&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -I LOCALINPUT $ethdevin -j NEWGDYNIN");
			&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -I LOCALOUTPUT $ethdevout -j NEWGDYNOUT");
			&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -D LOCALINPUT $ethdevin -j GDYNIN");
			&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -D LOCALOUTPUT $ethdevout -j GDYNOUT");
			&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -F GDYNIN");
			&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -F GDYNOUT");
			&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -X GDYNIN");
			&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -X GDYNOUT");
			&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -E NEWGDYNIN GDYNIN");
			&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -E NEWGDYNOUT GDYNOUT");
		}
		if ($config{IPV6}) {
			if ($config{SAFECHAINUPDATE}) {
				&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -I LOCALINPUT $ethdevin -j NEWGDYNIN");
				&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -I LOCALOUTPUT $ethdevout -j NEWGDYNOUT");
				&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -D LOCALINPUT $ethdevin -j GDYNIN");
				&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -D LOCALOUTPUT $ethdevout -j GDYNOUT");
				&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -F GDYNIN");
				&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -F GDYNOUT");
				&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -X GDYNIN");
				&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -X GDYNOUT");
				&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -E NEWGDYNIN GDYNIN");
				&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -E NEWGDYNOUT GDYNOUT");
			}
		}

		&listlock("unlock");
		close ($THISLOCK );
		if ($config{DEBUG} >= 3) {$timer = &timer("stop","globaldyndns",$timer)}
		$0 = "lfd - child closing";
		exit;
	}
	return;
}
# end globaldyndns
###############################################################################
# start listlock
sub listlock {
	my $state = shift;
	if ($state eq "lock") {
		sysopen ($LISTLOCK, "/var/lib/csf/lock/list.lock", O_RDWR | O_CREAT) or &shutdown_child("*Error* Unable to open /var/lib/csf/lock/list.lock");
		flock ($LISTLOCK, LOCK_EX) or &shutdown_child("*Lock Error* [listlock] unable to lock");
		print $LISTLOCK time;
	} else {
		close ($LISTLOCK);
	}
	return;
}
# end listlock
###############################################################################
# start dirwatch
sub dirwatch {
	$SIG{CHLD} = 'IGNORE';
	unless (defined ($childpid = fork)) {
		&shutdown(__LINE__,"*Error* cannot fork: $!");
	} 
	$forks{$childpid} = 1;
	unless ($childpid) {
		my $timer = time;
		if ($config{DEBUG} >= 3) {$timer = &timer("start","dirwatch",$timer)}
		$0 = "lfd - checking directories";

		my $lockstr = "LF_DIRWATCH";
		sysopen (my $THISLOCK, "/var/lib/csf/lock/$lockstr.lock", O_RDWR | O_CREAT) or &shutdown_child("*Error* Unable to open /var/lib/csf/lock/$lockstr.lock");
		flock ($THISLOCK, LOCK_EX | LOCK_NB) or &shutdown_child("*Lock Error* [$lockstr] still active - section skipped");
		print $THISLOCK time;

		my $alarm = int($config{LF_DIRWATCH}/10) + 10;
		my $start = time;
		my $tfail = 0;
		undef %nofiles;
		if (! -z "/var/lib/csf/csf.tempfiles") {
			open (my $IN, "<", "/var/lib/csf/csf.tempfiles");
			flock ($IN, LOCK_SH);
			my @data = <$IN>;
			close ($IN);
			chomp @data;

			foreach my $line ( @data ) {
				my ($itemttl,$item) = split(/:/,$line);
				if (time - $itemttl < $config{LF_FLUSH}) {
					$nofiles{$item} = 1;
				}
			}
		}

		undef @suspicious;
		my @dirs = ('/tmp','/dev/shm','/usr/local/apache/proxy','/etc/cron.d','/etc/cron.daily','/etc/cron.hourly','/etc/cron.weekly');
		my $tmpino = (stat("/tmp"))[1];
		my $ino = (lstat("/var/tmp"))[1];
		if ($ino ne $tmpino) {push @dirs, '/var/tmp'}
		$ino = (lstat("/usr/tmp"))[1];
		if ($ino ne $tmpino) {push @dirs, '/usr/tmp'}
		eval {
			local $SIG{__DIE__} = undef;
			local $SIG{'ALRM'} = sub {die};
			alarm($alarm);
			find(\&dirfiles, @dirs);
			alarm(0);
		};
		alarm(0);
		if ($@) {
			logfile("Directory Watching terminated after $alarm seconds");
			$tfail = 1;
		} else {
			if (@suspicious) {
				$0 = "lfd - reporting directory watch results";

				my @alert = slurp("/usr/local/csf/tpl/filealert.txt");
				my $matches = 0;
				foreach my $file (@suspicious) {
					if ($nofiles{$file}) { next }
					unless (-e $file) { next }
					$nofiles{$file} = 1;

					my ($dev,$ino,$mode,$nlink,$uid,$gid,$rdev,$size,$atime,$mtime,$ctime,$blksize,$blocks) = stat($file);
					if (-l $file) {($dev,$ino,$mode,$nlink,$uid,$gid,$rdev,$size,$atime,$mtime,$ctime,$blksize,$blocks) = lstat($file)}

					if ($file !~/\/core\./) {
						if ($uid eq "0") { next }
					}

					my $tuid = getpwuid($uid);
					my $tgid = getgrgid($gid);
					if ($file !~ /\/core\./) {
						if (($uid eq "postgres") and ($gid eq "postgres")) { next }
						if ($skipuser{$uid}) { next }
					}

					$matches++;
					if ($matches > 10) {
						logfile("Too many hits for *LF_DIRWATCH* - Directory Watching disabled");
						sysopen (my $DWDISABLE, "/var/lib/csf/csf.dwdisable", O_WRONLY | O_APPEND | O_CREAT) or &shutdown_child(__LINE__,"*Error* Cannot append out file: $!");
						flock ($DWDISABLE, LOCK_EX);
						print $DWDISABLE "disabled\n";
						close ($DWDISABLE);

						my @newalert = @alert;
						my @message;
						foreach my $line (@newalert) {
							$line =~ s/\[file\]//ig;
							$line =~ s/\[reason\]//ig;
							$line =~ s/\[owner\]//ig;
							$line =~ s/\[action\]/Too many hits for \*LF_DIRWATCH\* - Directory Watching disabled/ig;
							push @message, $line;
						}
						ConfigServer::Sendmail::relay("", "", @message);
						
						exit;
					}

					my $owner = "$tuid:$tgid ($uid:$gid)";
					my $line = "*Suspicious File* $file [$owner] - $sfile{$file}{reason}";
					my $action = "No action taken";

					if ($config{LF_DIRWATCH_DISABLE}) {
						if (-l $file) {
							unlink ($file);
							$action = "Symlink removed";
							$line .= " - symlink removed";
							delete $nofiles{$file};
						}
						elsif (-f $file) {
							system($config{TAR},"-rf","/var/lib/csf/suspicious.tar",$file);
							unlink ($file);
							$line .= " - removed";
							$action = "Moved into /var/lib/csf/suspicious.tar";
							delete $nofiles{$file};
						}
					}
					logfile($line);
					$0 = "lfd - (child) suspicious file alert for $file";

					my @newalert = @alert;
					my @message;
					foreach my $line (@newalert) {
						$line =~ s/\[file\]/$file/ig;
						$line =~ s/\[reason\]/$sfile{$file}{reason}/ig;
						$line =~ s/\[owner\]/$owner/ig;
						$line =~ s/\[action\]/$action/ig;
						push @message, $line;
					}
					ConfigServer::Sendmail::relay("", "", @message);

					if (! $config{LF_DIRWATCH_DISABLE}) {
						sysopen (my $TEMPFILES, "/var/lib/csf/csf.tempfiles", O_WRONLY | O_APPEND | O_CREAT) or &shutdown_child(__LINE__,"*Error* Cannot append out file: $!");
						flock ($TEMPFILES, LOCK_EX);
						print $TEMPFILES time.":$file\n";
						close ($TEMPFILES);
					}
				}
			}
		}

		if ($tfail) {
			$config{LF_DIRWATCH} = $config{LF_DIRWATCH} * 3;
			sysopen (my $TEMPCONF, "/var/lib/csf/csf.tempconf", O_WRONLY | O_APPEND | O_CREAT) or &shutdown_child(__LINE__,"*Error* Cannot append out file: $!");
			flock ($TEMPCONF, LOCK_EX);
			print $TEMPCONF "LF_DIRWATCH = \"$config{LF_DIRWATCH}\"\n";
			close ( $TEMPCONF );
			logfile("LF_DIRWATCH taking $alarm seconds, temporarily throttled to run every $config{LF_DIRWATCH} seconds");
		}

		close ($THISLOCK );
		if ($config{DEBUG} >= 3) {$timer = &timer("stop","dirwatch",$timer)}
		$0 = "lfd - child closing";
		exit;
	}
	return;
}
# end dirwatch
###############################################################################
# start dirfiles
sub dirfiles {
	if ($skipfile{$File::Find::name}) {return}
	if ($nofiles{$File::Find::name}) {return}
	if ((-d $File::Find::name) and ($_ =~ /^(\.|\.\.)$/)) {return}

	my $skip = 0;
	foreach my $match (@matchfile) {
		if ($File::Find::name =~ /$match/) {
			$skip = 1;
			last;
		}
	}
	if ($skip) {return}

	if (-l $File::Find::name) {
		push @suspicious, $File::Find::name;
		$sfile{$File::Find::name}{reason} = "Suspicious symlink (->".readlink($File::Find::name).")";
		return;
	}
	elsif ((-d $File::Find::name) and ($_ =~ /^(\.|\s)/)) {
		push @suspicious, $File::Find::name;
		$sfile{$File::Find::name}{reason} = "Suspicious directory";
		return;
	}
	elsif (-f $File::Find::name) {
		if ($File::Find::name =~ /^\/etc\/cron/) {
			if ($_ =~ /^core\./) {
				push @suspicious, $File::Find::name;
				$sfile{$File::Find::name}{reason} = "Core dump found - possible root exploit attack";
				return;
			} else {return}
		}
		if ($File::Find::name =~ /[\;\|\`\\]/) {
			push @suspicious, $File::Find::name;
			$sfile{$File::Find::name}{reason} = "Suspicious file name";
			return;
		}
		if ($File::Find::name =~ /^\-/) {
			push @suspicious, $File::Find::name;
			$sfile{$File::Find::name}{reason} = "Suspicious file name";
			return;
		}
		if ($_ =~ /\.(pl|cgi|ph.*|py|sh|bash)$/) {
			push @suspicious, $File::Find::name;
			$sfile{$File::Find::name}{reason} = "Script, file extension";
			return;
		}
		if ($_ =~ /^(udp\.pl|r0nin|dc\.pl|bind|bindz|inetd|z|httpd|sshd|ssh|cron|crond|su)$/) {
			push @suspicious, $File::Find::name;
			$sfile{$File::Find::name}{reason} = "Known exploit";
			return;
		}

		open (my $FILETYPE, "<", $File::Find::name);
		flock ($FILETYPE, LOCK_SH);
		read ($FILETYPE, my $filedata, 1024);
		close ($FILETYPE);
		if ($filedata =~ m[^\177ELF]) {
			push @suspicious, $File::Find::name;
			$sfile{$File::Find::name}{reason} = "Linux Binary";
			return;
		}
		if ($filedata =~ m[^\#\!]) {
			push @suspicious, $File::Find::name;
			$sfile{$File::Find::name}{reason} = "Script, starts with \#\!";
			return;
		}
	}
	return;
}
# end dirfiles
###############################################################################
# start dirwatchfile
sub dirwatchfile {
	$SIG{CHLD} = 'IGNORE';
	unless (defined ($childpid = fork)) {
		&shutdown(__LINE__,"*Error* cannot fork: $!");
	} 
	$forks{$childpid} = 1;
	unless ($childpid) {
		my $timer = time;
		if ($config{DEBUG} >= 3) {$timer = &timer("start","dirwatchfile",$timer)}

		my $lockstr = "LF_DIRWATCH_FILE";
		sysopen (my $THISLOCK, "/var/lib/csf/lock/$lockstr.lock", O_RDWR | O_CREAT) or &shutdown_child("*Error* Unable to open /var/lib/csf/lock/$lockstr.lock");
		flock ($THISLOCK, LOCK_EX | LOCK_NB) or &shutdown_child("*Lock Error* [$lockstr] still active - section skipped");
		print $THISLOCK time;

		$0 = "lfd - checking files and directories";

		undef %nofiles;
		if (-e "/var/lib/csf/csf.tempwatch") {
			open (my $IN, "<", "/var/lib/csf/csf.tempwatch");
			flock ($IN, LOCK_SH);
			my @data = <$IN>;
			close ($IN);
			chomp @data;

			foreach my $line ( @data ) {
				my ($file,$md5sum) = split(/:/,$line);
				if ($dirwatchfile{$file}) {$dirwatchfile{$file} = $md5sum}
			}
		}

		my @alert = slurp("/usr/local/csf/tpl/watchalert.txt");
		foreach my $file (keys %dirwatchfile) {
			unless (-e $file) {
				logfile("Directory *File Watching* [$file] does not exist");
				next;
			}
			my @data;
			eval {
				local $SIG{__DIE__} = undef;
				local $SIG{'ALRM'} = sub {die};
				alarm(10);
				@data = &syscommand(__LINE__,$config{LS},"--full-time","-lARt",$file);
				alarm(0);
			};
			alarm(0);
			if ($@) {
				logfile("Directory File Watching terminated after 10 seconds for $file: ".$@);
				exit;
			}
			chomp @data;
			my $md5current = Digest::MD5->new;
			my $output;
			foreach my $line ( @data ) {
				$md5current->add($line);
				$output .= $line."\n";
			}
			my $md5sum = $md5current->b64digest;

			if ($dirwatchfile{$file} ne "1") {
				if ($md5sum ne $dirwatchfile{$file}) {
					$0 = "lfd - (child) suspicious file alert for $file";
					logfile("Directory *File Watching* has detected a change in $file");
					$dirwatchfile{$file} = $md5sum;

					my @newalert = @alert;
					my @message;
					foreach my $line (@newalert) {
						$line =~ s/\[file\]/$file/ig;
						$line =~ s/\[output\]/$output/ig;
						push @message, $line;
					}
					ConfigServer::Sendmail::relay("", "", @message);
				}
			} else {
				$dirwatchfile{$file} = $md5sum;
			}
		}
		
		sysopen (my $TEMPWATCH, "/var/lib/csf/csf.tempwatch", O_WRONLY | O_CREAT) or &shutdown_child(__LINE__,"*Error* Cannot write out file: $!");
		flock ($TEMPWATCH, LOCK_EX);
		seek ($TEMPWATCH, 0, 0);
		truncate ($TEMPWATCH, 0);
		foreach my $file (keys %dirwatchfile) {
			print $TEMPWATCH "$file:$dirwatchfile{$file}\n";
		}
		close ($TEMPWATCH);

		close ($THISLOCK );
		if ($config{DEBUG} >= 3) {$timer = &timer("stop","dirwatchfile",$timer)}
		$0 = "lfd - child closing";
		exit;
	}
	return;
}
# end dirwatchfile
###############################################################################
# start integrity
sub integrity {
	$SIG{CHLD} = 'IGNORE';
	unless (defined ($childpid = fork)) {
		&shutdown(__LINE__,"*Error* cannot fork: $!");
	} 
	$forks{$childpid} = 1;
	unless ($childpid) {
		my $timer = time;
		if ($config{DEBUG} >= 3) {$timer = &timer("start","integrity",$timer)}

		my $lockstr = "LF_INTEGRITY";
		sysopen (my $THISLOCK, "/var/lib/csf/lock/$lockstr.lock", O_RDWR | O_CREAT) or &shutdown_child("*Error* Unable to open /var/lib/csf/lock/$lockstr.lock");
		flock ($THISLOCK, LOCK_EX | LOCK_NB) or &shutdown_child("*Lock Error* [$lockstr] still active - section skipped");
		print $THISLOCK time;

		$0 = "lfd - checking system integrity";

		my $integrity = '/usr/bin/* /usr/sbin/* /bin/* /sbin/* /usr/local/bin/* /usr/local/sbin/* /etc/init.d/* /etc/xinetd.d/* /etc/rc.local';
		my $alarm = int($config{LF_INTEGRITY}/10) + 10;
		my $start = time;
		my $tfail = 0;

		my $action;
		if (-z "/var/lib/csf/csf.tempint") {$action = "start"}
		unless (-e "/var/lib/csf/csf.tempint") {$action = "start"}
		if ($action eq "start") {
			eval {
				local $SIG{__DIE__} = undef;
				local $SIG{'ALRM'} = sub {die};
				alarm($alarm);
				&syscommand(__LINE__,"$config{MD5SUM} $integrity > /var/lib/csf/csf.tempint");
				alarm(0);
			};
			alarm(0);
			if ($@) {
				logfile("System Integrity start terminated after $alarm seconds");
				$tfail = 1;
			}
		} else {
			my @data;
			eval {
				local $SIG{__DIE__} = undef;
				local $SIG{'ALRM'} = sub {die};
				alarm($alarm);
				@data = &syscommand(__LINE__,"$config{MD5SUM} --check /var/lib/csf/csf.tempint");
				alarm(0);
			};
			alarm(0);
			if ($@) {
				logfile("System Integrity check terminated after $alarm seconds");
				$tfail = 1;
			} else {
				chomp @data;
				my $report;
				my $files;
				foreach my $line ( @data ) {
					my ($file,$text) = split(/:/,$line);
					if ($text =~ /FAILED/) {
						$report .= "$line\n";
						$files .= " $file";
					}
				}

				if ($report) {
					logfile("*System Integrity* has detected modified file(s):$files");
					$0 = "lfd - (child) system integrity alert";

					my @alert = slurp("/usr/local/csf/tpl/integrityalert.txt");
					my @message;
					foreach my $line (@alert) {
						$line =~ s/\r//;
						$line =~ s/\[text\]/$report/ig;
						push @message, $line;
					}
					ConfigServer::Sendmail::relay("", "", @message);
					unlink "/var/lib/csf/csf.tempint";

					eval {
						local $SIG{__DIE__} = undef;
						local $SIG{'ALRM'} = sub {die};
						alarm($alarm);
						&syscommand(__LINE__,"$config{MD5SUM} $integrity > /var/lib/csf/csf.tempint");
						alarm(0);
					};
					alarm(0);
					if ($@) {
						logfile("System Integrity start terminated after $alarm seconds");
						$tfail = 1;
					}
				}
			}
		}

		if ($tfail) {
			$config{LF_INTEGRITY} = $config{LF_INTEGRITY} * 1.5;
			sysopen (my $TEMPCONF, "/var/lib/csf/csf.tempconf", O_WRONLY | O_APPEND | O_CREAT) or &shutdown_child(__LINE__,"*Error* Cannot append out file: $!");
			flock ($TEMPCONF, LOCK_EX);
			print $TEMPCONF "LF_INTEGRITY = \"$config{LF_INTEGRITY}\"\n";
			close ( $TEMPCONF );
			logfile("LF_INTEGRITY taking $alarm seconds, temporarily throttled to run every $config{LF_INTEGRITY} seconds");
		}

		close ($THISLOCK );
		if ($config{DEBUG} >= 3) {$timer = &timer("stop","integrity",$timer)}
		$0 = "lfd - child closing";
		exit;
	}
	return;
}
# end integrity
###############################################################################
# start logscanner
sub logscanner {
	my $hour = shift;
	if (length $hour == 1) {$hour = "0$hour:00"} else {$hour = "$hour:00"}
	$SIG{CHLD} = 'IGNORE';
	unless (defined ($childpid = fork)) {
		&shutdown(__LINE__,"*Error* cannot fork: $!");
	} 
	$forks{$childpid} = 1;
	unless ($childpid) {
		my $timer = time;
		if ($config{DEBUG} >= 3) {$timer = &timer("start","logscanner",$timer)}

		my $lockstr = "LOGSCANNER";
		sysopen (my $THISLOCK, "/var/lib/csf/lock/$lockstr.lock", O_RDWR | O_CREAT) or &shutdown_child("*Error* Unable to open /var/lib/csf/lock/$lockstr.lock");
		flock ($THISLOCK, LOCK_EX | LOCK_NB) or &shutdown_child("*Lock Error* [$lockstr] still active - section skipped");
		print $THISLOCK time;

		$0 = "lfd - log scanner";

		unless (-z "/var/lib/csf/csf.logtemp" and $config{LOGSCANNER_EMPTY} == 0) {
			my $text;
			my %loglines;
			my $total = 0;
			my $max = 0;

			sysopen (my $LOGTEMP,"/var/lib/csf/csf.logtemp", O_RDWR | O_CREAT);
			flock ($LOGTEMP, LOCK_EX);
			my @data = <$LOGTEMP>;
			seek ($LOGTEMP, 0, 0);
			truncate ($LOGTEMP, 0);
			if (-e "/var/lib/csf/csf.logmax") {
				unlink "/var/lib/csf/csf.logmax";
				$max = 1;
			}
			close ($LOGTEMP);
			chomp @data;

			if ($config{LOGSCANNER_STYLE} == "1") {
				foreach my $line ( @data ) {
					my ($logfile,$logline) = split(/\|/,$line);
					$loglines{$logfile} .= "$logline\n";
					$total++;
				}
				foreach my $logfile (keys %loglines) {
					$text .= "$logfile:\n$loglines{$logfile}\n";
				}
			} else {
				foreach my $line ( @data ) {
					my ($logfile,$logline) = split(/\|/,$line);
					$text .= "$logline\n";
					$total++;
				}
			}

			if ($max) {$text .= "\n...Report truncated as it exceeded $config{LOGSCANNER_LINES} of log lines...\n"}

			if ($text eq "") {$text = "...No log lines to report..."}

			my @alert = slurp("/usr/local/csf/tpl/logalert.txt");
			my @message;
			foreach my $line (@alert) {
				$line =~ s/\r//;
				$line =~ s/\[text\]/$text/ig;
				$line =~ s/\[lines\]/$total/ig;
				$line =~ s/\[hour\]/$hour/ig;
				push @message, $line;
			}
			ConfigServer::Sendmail::relay("", "", @message);

			if ($config{DEBUG} >= 1) {logfile("LOGSCANNER report sent")}
		}

		close ($THISLOCK );
		if ($config{DEBUG} >= 3) {$timer = &timer("stop","logscanner",$timer)}
		$0 = "lfd - child closing";
		exit;
	}
	return;
}
# end logscanner
###############################################################################
# start exploit
sub exploit {
	$SIG{CHLD} = 'IGNORE';
	unless (defined ($childpid = fork)) {
		&shutdown(__LINE__,"*Error* cannot fork: $!");
	} 
	$forks{$childpid} = 1;
	unless ($childpid) {
		my $timer = time;
		if ($config{DEBUG} >= 3) {$timer = &timer("start","exploit",$timer)}

		my $lockstr = "LF_EXPLOIT";
		sysopen (my $THISLOCK, "/var/lib/csf/lock/$lockstr.lock", O_RDWR | O_CREAT) or &shutdown_child("*Error* Unable to open /var/lib/csf/lock/$lockstr.lock");
		flock ($THISLOCK, LOCK_EX | LOCK_NB) or &shutdown_child("*Lock Error* [$lockstr] still active - section skipped");
		print $THISLOCK time;

		$0 = "lfd - checking system exploit";

		my %exploit_tests;
		foreach my $test (split(/\,/,$config{LF_EXPLOIT_IGNORE})) {$exploit_tests{$test} = 1}
		my $report = "";

		unless ($exploit_tests{SUPERUSER}) {
			while (my ($name,undef,$uid) = getpwent()) {
				if (($uid == 0) and ($name ne "root") and ($suignore{$name} != 1)) {
					$report .= "Possible root compromise: User account $name is a superuser (UID 0)\n";
					logfile("*System Exploit* has detected a possible root compromise ($name = UID 0)");
				}
			}
			endpwent();
		}

		if ($report) {
			$0 = "lfd - (child) system exploit alert";
			sysopen (my $TEMPEXPLOIT, "/var/lib/csf/csf.tempexploit", O_WRONLY | O_CREAT) or &shutdown_child(__LINE__,"*Error* Cannot open out file: $!");
			flock ($TEMPEXPLOIT, LOCK_EX);
			print $TEMPEXPLOIT time;
			close ($TEMPEXPLOIT);

			my @alert = slurp("/usr/local/csf/tpl/exploitalert.txt");
			my @message;
			foreach my $line (@alert) {
				$line =~ s/\[text\]/$report/ig;
				push @message, $line;
			}
			ConfigServer::Sendmail::relay("", "", @message);
			unlink "/var/lib/csf/csf.tempexp";
		}

		close ($THISLOCK );
		if ($config{DEBUG} >= 3) {$timer = &timer("stop","exploit",$timer)}
		$0 = "lfd - child closing";
		exit;
	}
	return;
}

# #
#	Detect network interfaces and IP addresses. Build the
#	interface settings used by firewall rules and network checks.
# #

sub getethdev
{
	my $ethdev 		= ConfigServer::GetEthDev->new();
	my %g_ifaces 	= $ethdev->ifaces;
	my %g_ipv4 		= $ethdev->ipv4;
	my %g_ipv6 		= $ethdev->ipv6;

	foreach my $key ( keys %g_ifaces )
	{
		$ifaces{$key} = 1;
	}

	foreach my $key ( keys %g_ipv4 )
	{
		$ips{$key} = 1;
	}

	if ( $config{IPV6} )
	{
		foreach my $key ( keys %g_ipv6 )
		{
			eval {
				local $SIG{__DIE__} = undef;
				$ipscidr6->add( $key );
			};
		}
	}

	( $config{ETH_DEVICE}, undef ) = split ( /:/, $config{ETH_DEVICE}, 2 );

	if ( $config{ETH_DEVICE} eq "" )
	{
		$ethdevin 		= "! -i lo";
		$ethdevout 		= "! -o lo";
	}
	else
	{
		$ethdevin 		= "-i $config{ETH_DEVICE}";
		$ethdevout 		= "-o $config{ETH_DEVICE}";
	}

	if ( $config{ETH6_DEVICE} eq "" )
	{
		$eth6devin 		= $ethdevin;
		$eth6devout 	= $ethdevout;
	} else {
		$eth6devin 		= "-i $config{ETH6_DEVICE}";
		$eth6devout 	= "-o $config{ETH6_DEVICE}";
	}
	return;
}

# #
#	lfd.pl › Shutdown
# #

sub shutdown
{
	$SIG{INT} 		= 'IGNORE';
	$SIG{TERM} 		= 'IGNORE';
	$SIG{HUP} 		= 'IGNORE';

	my $line 		= shift;
	my $message 	= shift;
	my $status 		= shift // "info";

	# #
	#   LFD Process Shutdown Ownership
	#   
	#   Controls which LFD processes are allowed to perform a full daemon
	#   shutdown when a fatal error, PID mismatch, or internal failure occurs.
	#   
	#   0   All LFD processes are allowed to validate the PID file and perform
	#       a full shutdown if an error is detected. (Default behavior)
	#   
	#   1   Only the main LFD parent process is allowed to stop the daemon.
	#       Child processes will still report errors to the log file but will
	#       exit individually without removing the PID file or terminating the
	#       main LFD process.
	# #

	my $parent_bind 	= ( defined $config{LFD_PROCESS_BIND} and $config{LFD_PROCESS_BIND} ) ? 1 : 0;
	my $is_master 		= ( defined $masterpid and $$ == $masterpid );

	# #
	#   Shutdown › Child Process
	#   
    #   Trigger when LFD_PROCESS_BIND enabled (1); and when shutdown() is called
    #   from a child process, instead of the main LFD process.
    #   
    #   Logs the shutdown reason, exit only the current child process.
    #   
    #   Doesn't remove the LFD PID file, don't terminate the main LFD process.
    #   
    #   LFD_PROCESS_BIND        Control when LFD processes are allowed to perform
    #                           a full daemon shutdown when fatal errors, PID
    #                           mismatch, or internal failures happen.
    #   
    #                           0   All LFD processes allowed to validate PID
    #                               file and perform full shutdown if error
    #                               occurs (Default)
    #   
    #                           1   Only main LFD parent process allowed to stop
    #                               the daemon. Child process still reports 
    #                               errors to log file, but exit individually
    #                               without removing PID file or killing main 
    #                               LFD process.
	# #

	if ( $parent_bind and !$is_master )
	{
		if ( ( $message eq "" ) and $line )
		{
			$message = "[SHUTDOWN] Child Process: $line";
			$line = "";
		}

		if ( $message )
		{
			if ( $line ne "" )
			{
				$message .= ", at line $line";
			}

            logfile( "all", "$status", "$message" );
		}

		exit 0;
	}

	if ( ( $message eq "" ) and $line )
	{
		$message 	= "[SHUTDOWN] Main Process: $line";
		$line 		= "";
	}

	$0 = "lfd - stopping";

	if ( $message )
	{
		if ( $line ne "" )
		{
			$message .= ", at line $line"
		}
        logfile( "all", "$status", "$message" );
	}

	if ( $PIDFILE and fileno( $PIDFILE ) )
	{
		close( $PIDFILE );
		unlink $pidfile;

        logfile( "all", "ok", "[SHUTDOWN] Closed out $pidfile" );
	}

    logfile( "all", "ok", "[SHUTDOWN] Daemon stopping; terminating process group [$$]" );
	kill ( 9, -$$ );
    exit 0;
}

# #
#   lfd.pl › Shutdown Child
# #

sub shutdown_child 
{
	$SIG{INT} 		= 'IGNORE';
	$SIG{TERM} 		= 'IGNORE';
	$SIG{HUP} 		= 'IGNORE';
	my $line 		= shift;
	my $message	 	= shift;

	if ( ( $message eq "" ) and $line ne "" )
	{
		$message 	= "[SHUTDOWN] Child Process $childproc: $line";
		$line 		= "";
	}

	$0 = "[SHUTDOWN] Child process aborting";

	if ( $message )
	{
		if ( $line ne "" )
		{
			$message .= ", at line $line"
		}

        logfile( "all", "ok", "$message" );
	}

    exit;
}

sub ignoreip
{
	my $ip      = shift;
	my $skip    = shift;

	if ( $ip eq "" )
    {
        return 0
    }

	if ( $ips{$ip} or $ipscidr->find( $ip ) or $ipscidr6->find( $ip ) )
    {
        return 1
    }

	if ( $ignoreips{$ip} )
    {
        return 1
    }

	if ( $gignoreips{$ip} )
    {
        return 1
    }

	if ( $config{CC_IGNORE} )
    {
		my ( $cc, $asn )    = iplookup( $ip,1 );
		( $asn, undef )     = split( /\s+/, $asn );

		if ( $cc ne "" and $config{CC_IGNORE} =~ /$cc/i )
        {
            return 1
        }

		if ( $asn ne "" and $config{CC_IGNORE} =~ /$asn/i )
        {
            return 1
        }
	}

	if ( $relayip{$ip} and !$skip )
    {
        return 1
    }

	if ( @cidrs )
    {
		if ( $cidr->find( $ip ) )   { return 1 }
		if ( $cidr6->find( $ip ) )  { return 1 }
	}

	if ( @gcidrs )
    {
		if ( $gcidr->find( $ip ) )  { return 1 }
		if ( $gcidr6->find( $ip ) ) { return 1 }
	}

	if ( @rdns and !$skip )
    {
		my $matchdomain;
		my $matchip;
		my $dnsip;
		my $dnsrip;
		my $dnshost;
		my $cachehit;

		open    ( my $DNS, "<", "/var/lib/csf/csf.dnscache" );
		flock   ( $DNS, LOCK_SH );

		while ( my $line = <$DNS> )
        {
			chomp $line;
			( $dnsip, $dnsrip, $dnshost ) = split( /\|/, $line );
			if ( $ip eq $dnsip )
            {
				$cachehit = 1;
				last;
			}
		}

		close   ( $DNS );
		if ( $cachehit )
        {
			$matchip        = $dnsrip;
			$matchdomain    = $dnshost;

			if ( $config{DEBUG} >= 2 )
            {
                logfile( "debug: (ignoreip) [cached] [$ip]:[$matchip] [$matchdomain]" );
            }
		}
        else
        {
			eval {
				local $SIG{__DIE__}     = undef;
				local $SIG{'ALRM'}      = sub { die };
				alarm(8);
				$matchip                = inet_aton( $ip );
				$matchdomain            = gethostbyaddr( $matchip, AF_INET );
				if ( $matchdomain ne "" )
                {
					$matchip    = gethostbyname( $matchdomain );
					$matchip    = inet_ntoa( $matchip );
				}
				alarm( 0 );
			};

			alarm(0);
			unless (checkip(\$matchip)) {$matchip = ""}
			sysopen (my $DNS, "/var/lib/csf/csf.dnscache", O_WRONLY | O_APPEND | O_CREAT);
			flock ($DNS, LOCK_EX);
			print $DNS "$ip|$matchip|$matchdomain\n";
			close ($DNS);
			if ($config{DEBUG} >= 2) {logfile("debug: (ignoreip) [not cached] [$ip]:[$matchip] [$matchdomain]")}
		}

		if ($ip eq $matchip) {
			foreach my $host (@rdns) {
				if (($host =~ /\./) and ($matchdomain =~ /$host$/)) {
					if ($config{DEBUG} >= 1) {logfile("debug: (ignoreip) [$ip]:[$matchip] [$host]:[$matchdomain]")}
					return 1;
				}
				if ($matchdomain eq $host) {
					if ($config{DEBUG} >= 1) {logfile("debug: (ignoreip) [$ip]:[$matchip] [$host]:[$matchdomain]")}
					return 1;
				}
			}
		}
	}

	return 0;
}
# end ignoreip
###############################################################################
# start linefilter
sub linefilter {
	my $line = shift;
	my $ad = shift;
	my $chain = shift;
	my $delete = shift;
	my $pktin = "$accept";
	my $pktout = "$accept";
	my $inadd = "-I";
	my $verbose = "";
	my $localin = "ALLOWIN";
	my $localout = "ALLOWOUT";
	if ($ad eq "deny") {
		$inadd = "-A";
		$pktin = $config{DROP};
		$pktout = $config{DROP_OUT};
		if ($config{DROP_IP_LOGGING}) {$pktin = "LOGDROPIN"}
		if ($config{DROP_OUT_LOGGING}) {$pktout = "LOGDROPOUT"}
		$localin = "DENYIN";
		$localout = "DENYOUT";
	}
	my $chainin = $chain."IN";
	my $chainout = $chain."OUT";

	$line =~ s/\n|\r//g;
	$line = lc $line;
	if ($line =~ /^\#/) {return}
	if ($line =~ /^Include/) {return}
	if ($line eq "") {return}

	my $checkip = checkip(\$line);
	my $iptables = $config{IPTABLES};
	my $ipv4 = 1;
	my $ipv6 = 0;
	my $linein = $ethdevin;
	my $lineout = $ethdevout;
	if ($checkip == 6) {
		if ($config{IPV6}) {
			$iptables = $config{IP6TABLES};
			$linein = $eth6devin;
			$lineout = $eth6devout;
			$ipv4 = 0;
			$ipv6 = 1;
		} else {return}
	}

	if ($checkip)
    {
        logfile( "debug:1", "info", "linefilter: [Step] Processing standalone IP or CIDR [ $line ]" );

		if ($chain) {
			if ($config{LF_IPSET}) {
				if ($ipv4) {&ipsetadd("chain_$chainin",$line)}
				else {&ipsetadd("chain_6_${chainin}",$line)}
			} else {
				&iptablescmd(__LINE__,"$iptables $config{IPTABLESWAIT} $verbose -A $chainin $linein -s $line -j $pktin");
				if (($ad eq "deny" and !$config{LF_BLOCKINONLY}) or ($ad ne "deny")) {&iptablescmd(__LINE__,"$iptables $config{IPTABLESWAIT} $verbose -A $chainout $lineout -d $line -j $pktout")}
			}
		} else {
			if ($delete) {
				if ($config{LF_IPSET}) {
					if ($ipv4) {&ipsetdel("chain_$localin",$line)}
					else {&ipsetdel("chain_6_${localin}",$line)}
				} else {
					&iptablescmd(__LINE__,"$iptables $config{IPTABLESWAIT} $verbose -D $localin $linein -s $line -j $pktin");
					if (($ad eq "deny" and !$config{LF_BLOCKINONLY}) or ($ad ne "deny")) {&syscommand(__LINE__,"$iptables $config{IPTABLESWAIT} $verbose -D $localout $lineout -d $line -j $pktout")}
				}
				if (($ad eq "deny") and ($ipv4 and $config{MESSENGER} and $config{MESSENGER_PERM})) {&domessenger($line,"D")}
				if (($ad eq "deny") and ($ipv6 and $config{MESSENGER6} and $config{MESSENGER_PERM})) {&domessenger($line,"D")}
			} else {
				if ($config{LF_IPSET}) {
					if ($ipv4) {&ipsetadd("chain_$localin",$line)}
					else {&ipsetadd("chain_6_${localin}",$line)}
				} else {
					&iptablescmd(__LINE__,"$iptables $config{IPTABLESWAIT} $verbose $inadd $localin $linein -s $line -j $pktin");
					if (($ad eq "deny" and !$config{LF_BLOCKINONLY}) or ($ad ne "deny")) {&iptablescmd(__LINE__,"$iptables $config{IPTABLESWAIT} $verbose $inadd $localout $lineout -d $line -j $pktout")}
				}
				if (($ad eq "deny") and ($ipv4 and $config{MESSENGER} and $config{MESSENGER_PERM})) {&domessenger($line,"A")}
				if (($ad eq "deny") and ($ipv6 and $config{MESSENGER6} and $config{MESSENGER_PERM})) {&domessenger($line,"A")}
			}
		}
	}
	elsif ($line =~ /\:|\|/) {
		if ($line !~ /\|/) {$line =~ s/\:/\|/g}
		my $sip;
		my $dip;
		my $sport;
		my $dport;
		my $protocol = "-p tcp";
		my $inout;
		my $from = 0;
		my $uid;
		my $gid;
		my $iptype;

		my @ll = split(/\|/,$line);
		if ($ll[0] eq "tcp") {
			$protocol = "-p tcp";
			$from = 1;
		}
		elsif ($ll[0] eq "udp") {
			$protocol = "-p udp";
			$from = 1;
		}
		elsif ($ll[0] eq "icmp") {
			$protocol = "-p icmp";
			$from = 1;
		}
		for (my $x = $from;$x < 2;$x++) {
			if (($ll[$x] eq "out")) {
				$inout = "out";
				$from = $x + 1;
				last;
			}
			elsif (($ll[$x] eq "in")) {
				$inout = "in";
				$from = $x + 1;
				last;
			}
		}
		for (my $x = $from;$x < 3;$x++) {
			if (($ll[$x] =~ /d=(.*)/)) {
				$dport = "--dport $1";
				$dport =~ s/_/:/g;
				if ($protocol eq "-p icmp") {$dport = "--icmp-type $1"}
				if ($dport =~ /,/) {$dport = "-m multiport ".$dport}
				$from = $x + 1;
				last;
			}
			elsif (($ll[$x] =~ /s=(.*)/)) {
				$sport = "--sport $1";
				$sport =~ s/_/:/g;
				if ($protocol eq "-p icmp") {$sport = "--icmp-type $1"}
				if ($sport =~ /,/) {$sport = "-m multiport ".$sport}
				$from = $x + 1;
				last;
			}
		}
		for (my $x = $from;$x < 4;$x++) {
			if (($ll[$x] =~ /d=(.*)/)) {
				my $ip = $1;
				my $status = checkip(\$ip);
				if ($status) {
					$iptype = $status;
					$dip = "-d $1";
				}
				last;
			}
			elsif (($ll[$x] =~ /s=(.*)/)) {
				my $ip = $1;
				my $status = checkip(\$ip);
				if ($status) {
					$iptype = $status;
					$sip = "-s $1";
				}
				last;
			}
		}
		for (my $x = $from;$x < 5;$x++) {
			if (($ll[$x] =~ /u=(.*)/)) {
				$uid = "--uid-owner $1";
				last;
			}
			elsif (($ll[$x] =~ /g=(.*)/)) {
				$gid = "--gid-owner $1";
				last;
			}
		}
		if (($sip or $dip) and ($dport or $sport)) {
			my $iptables = $config{IPTABLES};
			if ($iptype == 6) {
				if ($config{IPV6}) {
					$iptables = $config{IP6TABLES};
				} else {
					return;
				}
			}
			if (($inout eq "") or ($inout eq "in")) {
				my $bport = $dport;
				$bport =~ s/--dport //o;
				my $bip = $sip;
				$bip =~ s/-s //o;
				if ($chain) {
					&iptablescmd(__LINE__,"$iptables $config{IPTABLESWAIT} $verbose -A $chainin $linein $protocol $dip $sip $dport $sport -j $pktin");
				} else {
					if ($delete) {
						&iptablescmd(__LINE__,"$iptables $config{IPTABLESWAIT} $verbose -D $localin $linein $protocol $dip $sip $dport $sport -j $pktin");
						if ($messengerports{$bport} and ($ad eq "deny") and ($ipv4 and $config{MESSENGER} and $config{MESSENGER_PERM})) {&domessenger($bip,"D","$bport")}
						if ($messengerports{$bport} and ($ad eq "deny") and ($ipv6 and $config{MESSENGER6} and $config{MESSENGER_PERM})) {&domessenger($bip,"D","$bport")}
					} else {
						&iptablescmd(__LINE__,"$iptables $config{IPTABLESWAIT} $verbose $inadd $localin $linein $protocol $dip $sip $dport $sport -j $pktin");
						if ($messengerports{$bport} and ($ad eq "deny") and ($ipv4 and $config{MESSENGER} and $config{MESSENGER_PERM})) {&domessenger($bip,"A","$bport")}
						if ($messengerports{$bport} and ($ad eq "deny") and ($ipv6 and $config{MESSENGER6} and $config{MESSENGER_PERM})) {&domessenger($bip,"A","$bport")}
					}
				}
			}
			if ($inout eq "out") {
				if ($chain) {
					&iptablescmd(__LINE__,"$iptables $config{IPTABLESWAIT} $verbose -A $chainout $lineout $protocol $dip $sip $dport $sport -j $pktout");
				} else {
					if ($delete) {
						&iptablescmd(__LINE__,"$iptables $config{IPTABLESWAIT} $verbose -D $localout $lineout $protocol $dip $sip $dport $sport -j $pktout");
					} else {
						&iptablescmd(__LINE__,"$iptables $config{IPTABLESWAIT} $verbose $inadd $localout $lineout $protocol $dip $sip $dport $sport -j $pktout");
					}
				}
			}
		}
	}
	return;
}

# #
#   lfd › Iptables Command
#   
#   Supports two syntax of command inputs:
#       1. Legacy (single string shell command)
#       2. Arg Vector (argv) (prevent shell parsing)
#           Supports max of 128 args (IPTABLES_ARGS_MAX)
#   
#   Legacy:      &iptablescmd( __LINE__, "$iptables --wait -A GALLOWOUT -o eth0 -p tcp -d 192.0.2.3 -m multiport --dport 80,443 -j ACCEPT" );
#   Array ref:   &iptablescmd( __LINE__, [ $iptables, "--wait", "-A", "GALLOWOUT", "-o", "eth0", "-p", "tcp", "-d", "192.0.2.3", "-m", "multiport", "--dport", "80,443", "-j", "ACCEPT" ] );
#   
#   @todo       Deprecate legacy string commands
#   
#   @test       Note:           (Legacy) Test single string rule
#               Command:        Create Chain:   sudo /sbin/iptables --wait -F CSF_LFD_LEGACY_TEST_20261031 2>/dev/null || true; sudo /sbin/iptables --wait -X CSF_LFD_LEGACY_TEST_20261031 2>/dev/null || true; sudo /sbin/iptables --wait -N CSF_LFD_LEGACY_TEST_20261031
#                               Add Rule:       sudo perl -e 'use IPC::Open3 ( ); local $SIG{CHLD} = q{DEFAULT}; my ($in, $out); my $command = q{/sbin/iptables --wait -A CSF_LFD_LEGACY_TEST_20261031 -p tcp -d 192.0.2.123 --dport 60001 -j ACCEPT}; my $pid = IPC::Open3::open3($in, $out, $out, $command); close($in); my $text = join(q{}, <$out>); waitpid($pid, 0); my $exit = $? >> 8; chomp($text); $text = q{none} if $text eq q{}; print qq{Legacy exit [$exit] output [$text]\n};'
#                               Verify Rule:    sudo /sbin/iptables --wait -S CSF_LFD_LEGACY_TEST_20261031
#                               Cleanup Rule:   sudo /sbin/iptables --wait -F CSF_LFD_LEGACY_TEST_20261031 && sudo /sbin/iptables --wait -X CSF_LFD_LEGACY_TEST_20261031
#   
#               Note:           Test arg vector rule
#               Command:        Create Chain:   sudo /sbin/iptables --wait -F CSF_LFD_ARGV_TEST_20261031 2>/dev/null || true; sudo /sbin/iptables --wait -X CSF_LFD_ARGV_TEST_20261031 2>/dev/null || true; sudo /sbin/iptables --wait -N CSF_LFD_ARGV_TEST_20261031
#                               Add Rule:       sudo perl -e 'use IPC::Open3 ( ); local $SIG{CHLD} = q{DEFAULT}; my @argv = (q{/sbin/iptables}, q{--wait}, q{-A}, q{CSF_LFD_ARGV_TEST_20261031}, q{-p}, q{tcp}, q{-d}, q{198.51.100.123}, q{--dport}, q{60002}, q{-j}, q{ACCEPT}); my ($in, $out); my $pid = IPC::Open3::open3($in, $out, $out, @argv); close($in); my $text = join(q{}, <$out>); waitpid($pid, 0); my $exit = $? >> 8; chomp($text); $text = q{none} if $text eq q{}; print qq{Argv exit [$exit] output [$text]\n};'
#                               Verify Rule:    sudo /sbin/iptables --wait -S CSF_LFD_ARGV_TEST_20261031
#                               Cleanup Rule:   sudo /sbin/iptables --wait -F CSF_LFD_ARGV_TEST_20261031 && sudo /sbin/iptables --wait -X CSF_LFD_ARGV_TEST_20261031
#   
#   @params     line            int             Source line num
#               input           str|arrayref    Command str || argv array
#   @return     void
# #

sub iptablescmd
{
	my $line = shift;
	my $input = shift;

	local $SIG{CHLD} = 'DEFAULT';

	my ( $argv, $command );
	if (ref($input) eq "ARRAY")
	{
		my $args_i = scalar @{$input};

		logfile( "debug:1", "info", "iptables: argv count [ $args_i (current) / " . IPTABLES_ARGS_MAX . " (max) ]" );

		if ( $args_i == 0 or $args_i > IPTABLES_ARGS_MAX )
		{
			logfile( "normal", "error", "iptables: Invalid argv count [ $args_i (current) / " . IPTABLES_ARGS_MAX . " (max) ] on line [ $line ]" );
			return;
		}

		if ( !defined( $input->[0] ) or ref( $input->[0] ) or $input->[0] eq "" )
		{
			logfile( "normal", "error", "iptables: Invalid executable on line [ $line ]" );
			return;
		}
		my $arg_len_max         = IPTABLES_ARGS_EACH_LEN_MAX;
		my $arg_control_chars   = '\x{0000}-\x{001F}\x{007F}';
		my @args_valid;
		for my $arg ( @{$input} )
		{
			if ( !defined( $arg ) )
			{
				logfile( "normal", "error", "iptables: Invalid argv on line [ $line ]: undefined arg" );
				return;
			}

			if ( ref( $arg ) )
			{
				logfile( "normal", "error", "iptables: Invalid argv on line [ $line ]: arg is a ref [ " . ref( $arg ) . " ]" );
				return;
			}

			my $arg_len = length( $arg );
			if ( $arg_len > $arg_len_max )
			{
				logfile( "normal", "error", "iptables: Invalid argv on line [ $line ]: " . "arg len [ $arg_len (current) / $arg_len_max (max) ]" );
				return;
			}

			if ( $arg =~ /[$arg_control_chars]/ )
			{
				logfile( "normal", "error", "iptables: Invalid argv on line [ $line ]: arg contains ascii control chars" );
				return;
			}
			my ($arg_valid) = $arg =~ /\A([^$arg_control_chars]{0,$arg_len_max})\z/;
			push @args_valid, $arg_valid;
		}
		$argv = \@args_valid;
		$command = join(" ", @args_valid);
	}
	elsif ( defined( $input ) and !ref( $input ) and $input ne "" )
	{
		$command = $input;
		$command =~ s/;`|//g;
	}
	else
	{
        logfile( "normal", "error", "iptables: Invalid command on line [ $line ]" );
		return;
	}
	my $status = 0;
	my $iptableslock = 0;
	if ($argv)
	{
		if ($argv->[0] eq $config{IPTABLES} or $argv->[0] eq $config{IP6TABLES}) {$iptableslock = 1}
	}
	elsif ($command =~ /^($config{IPTABLES}|$config{IP6TABLES})/) {$iptableslock = 1}
	if ($faststart) {
		logfile( "debug:1", "info", "iptables: FASTSTART queue [ $command ] from line [ $line ]" );
		if ($command =~ /^$config{IPTABLES}\s+(.*)$/) {
			my $fastcmd = $1;
			$fastcmd =~ s/-v//;
			$fastcmd =~ s/--wait//;
			if ($fastcmd =~ /-t\s+nat/) {
				$fastcmd =~ s/-t\s+nat//;
				push @faststart4nat,$fastcmd;
			} else {
				push @faststart4,$fastcmd;
			}
		}
		if ($command =~ /^$config{IP6TABLES}\s+(.*)$/) {
			my $fastcmd = $1;
			$fastcmd =~ s/-v//;
			$fastcmd =~ s/--wait//;
			if ($fastcmd =~ /-t\s+nat/) {
				$fastcmd =~ s/-t\s+nat//;
				push @faststart6nat,$fastcmd;
			} else {
				push @faststart6,$fastcmd;
			}
		}
		return;
	}

	if (-e "/etc/csf/csf.error") {
		&shutdown(__LINE__,"*Error* csf reported an error (see /etc/csf/csf.error). *lfd stopped*");
		exit 1;
	}

	if ($config{VPS}) {$status = &checkvps}
	if ($status) {
		logfile($status);
	} else {
		if ($config{DEBUG} >= 2) {logfile("debug[$line]: Command:$command")}
		if (&csflock) {
            logfile( "normal", "info", "iptables: csf currently restarting - command [ $command ] skipped on line [ $line ]" );
			unless ($masterpid == $$) {exit}
		}
		if ($iptableslock) {&iptableslock("lock")}

		logfile( "debug:1", "info", "iptables: Execute [ $command ] from line [ $line ]" );

		my @output;
		my $cmd_status;
		if ($iptableslock and $config{WAITLOCK}) {
			eval {
				local $SIG{__DIE__} = undef;
				local $SIG{'ALRM'} = sub {die "alarm\n"};
				alarm($config{WAITLOCK_TIMEOUT});
				my ($childin, $childout);
                my @open3_cmd   = $argv ? @{$argv} : ($command);
				my $cmdpid      = IPC::Open3::open3( $childin, $childout, $childout, @open3_cmd );
				@output         = <$childout>;
				waitpid ($cmdpid, 0);
				$cmd_status     = $?;
				alarm(0);
			};
			alarm(0);
			if ($@ eq "alarm\n") {
				&shutdown(__LINE__,"*Error* timeout after iptables --wait for $config{WAITLOCK_TIMEOUT} seconds - WAITLOCK");
			}
		} else {
			my ($childin, $childout);
			my @open3_cmd   = $argv ? @{$argv} : ($command);
			my $cmdpid      = IPC::Open3::open3( $childin, $childout, $childout, @open3_cmd );
			@output         = <$childout>;
			waitpid ($cmdpid, 0);
			$cmd_status     = $?;
		}
		if ($iptableslock) { &iptableslock( "unlock" ) }

		chomp @output;
		if ($output[0] =~ /# Warning: iptables-legacy tables present/) {shift @output}
		if ($output[0] =~ /^deny failed\:/) {logfile("*Error*: csf output: $output[0]")}
		if ($output[0] =~ /^Error\:/) {logfile("*Error*: csf output: $output[0]")}
		if ($output[0] =~ /xtables lock/) {logfile("*Error*: Unable to check csf due to xtables lock, enable WAITLOCK in csf.conf")}

		if ($output[0] =~ /(^iptables: Unknown error 4294967295)|(xtables lock)/ and !$config{WAITLOCK}) {
			my $cnt = 0;
			my $repeat = 6;
			while ($cnt < $repeat) {
				sleep 1;
				if ($config{DEBUG} >= 1) {logfile("debug[$line]: Retry (".($cnt+1).") [$command] due to [$output[0]]")}
				if ($iptableslock) {&iptableslock("lock")}
				my ($childin, $childout);
				my @open3_cmd   = $argv ? @{$argv} : ($command);
				my $cmdpid      = IPC::Open3::open3( $childin, $childout, $childout, @open3_cmd );
				@output         = <$childout>;
				waitpid ($cmdpid, 0);
				$cmd_status     = $?;
				if ($iptableslock) {&iptableslock("unlock")}
				chomp @output;
				if ($output[0] =~ /# Warning: iptables-legacy tables present/) {shift @output}
				$cnt++;
				if ($output[0] =~ /(^iptables: Unknown error 4294967295)|(xtables lock)/ and $cnt == $repeat) {logfile("*Error* processing command for line [$line] ($repeat times): [$output[0]]");}
				unless ($output[0] =~ /(^iptables: Unknown error 4294967295)|(xtables lock)/) {$cnt = $repeat}
			}
		}
		elsif ($config{DEBUG} >= 1 and $output[0] =~ /^iptables|ip6tables|xtables|Bad|Another/) {
            logfile( "normal", "error", "iptables: Failed processing command for line [ $line ] : output [ $output[0] ]" );
		}

		if ( defined( $cmd_status ) )
		{
			my $exit_code   = $cmd_status >> 8;
			my $exit_signal = $cmd_status & 127;
			my $output_text = @output ? join( " ", @output ) : "none";

			if ( $cmd_status == -1 )
			{
				logfile( "normal", "error", "iptables: Unable to collect command status [ $command ] from line [ $line ]" );
			}
			elsif ( $cmd_status == 0 )
			{
				logfile( "debug:1", "info", "iptables: Command completed successfully [ $command ] from line [ $line ]" );
			}
			elsif ( $exit_signal )
			{
				logfile( "normal", "error", "iptables: Command terminated by signal [ $exit_signal ] output [ $output_text ] [ $command ] from line [ $line ]" );
			}
			else
			{
				logfile( "normal", "error", "iptables: Command failed with exit code [ $exit_code ] output [ $output_text ] [ $command ] from line [ $line ]" );
			}
		}
	}
	return;
}

sub syscommand
{
	my ($line, @cmd) = @_;
	my $cmdline = join( " ", @cmd );
	my $status = 0;
	my @output;

	if (-e "/etc/csf/csf.error") {
		&shutdown(__LINE__,"*Error* csf reported an error (see /etc/csf/csf.error). *lfd stopped*");
		exit 1;
	}

	if ($config{VPS}) {$status = &checkvps}
	if ($status) {
		logfile($status);
	} else {
		if ($config{DEBUG} >= 2) {logfile("debug[$line]: Command:$cmdline")}
		if (&csflock) {
			logfile("csf is currently restarting - command [$cmdline] skipped on line $line");
			unless ($masterpid == $$) {exit}
		}
		my ($childin, $childout);
		my $cmdpid = open3($childin, $childout, $childout, @cmd);
		@output = <$childout>;
		waitpid ($cmdpid, 0);
		if ($output[0] =~ /# Warning: iptables-legacy tables present/) {shift @output}
		if ($output[0] =~ /^deny failed\:/) {logfile("*Error*: csf output: $output[0]")}
		if ($output[0] =~ /^Error\:/) {logfile("*Error*: csf output: $output[0]")}
	}
	return @output;
}
# end syscommand
###############################################################################
# start iptableslock
sub iptableslock {
	my $lock = shift;
	my $iptablesx = shift;
	if ($lock eq "lock") {
		sysopen ($IPTABLESLOCK, "/var/lib/csf/lock/command.lock", O_RDWR | O_CREAT);
		flock ($IPTABLESLOCK, LOCK_EX);
		autoflush $IPTABLESLOCK 1;
		seek ($IPTABLESLOCK, 0, 0);
		truncate ($IPTABLESLOCK, 0);
		print $IPTABLESLOCK $$;
	} else {
		close ($IPTABLESLOCK);
	}
	return;
}
# end iptableslock
###############################################################################
# start timer
sub timer {
	my $status = shift;
	my $check = shift;
	my $start = shift;

	if ($status eq "start") {
		logfile("debug: TIMER start: $check");
		return Time::HiRes::gettimeofday();
	} else {
		if ($start == 0) {return}
		my $diff = sprintf '%.6f', (Time::HiRes::gettimeofday() - $start);
		logfile("debug: TIMER stop:  $check ($diff secs)");
	}
	return;
}
# end timer
###############################################################################
# start csflock
sub csflock {
	my $ret = 0;
	sysopen (my $CSFLOCKFILE, "/var/lib/csf/csf.lock", O_RDWR | O_CREAT) or &shutdown_child("*Error* Unable to open csf lock file");
	flock ($CSFLOCKFILE, LOCK_SH | LOCK_NB) or $ret = 1;
	close ($CSFLOCKFILE);

	return $ret;
}
# end csflock
###############################################################################
# start lockfail
sub lockfail {
	my $section = shift;
	logfile("csf is currently restarting - section [$section] skipped");
	exit;
}
# end lockfail
###############################################################################
# start ipblock
sub ipblock {
	my $perm = shift;
	my $message = shift;
	my $ip = shift;
	my $port = shift;
	my $inout = shift;
	my $timeout = shift;
	my $cluster = shift;
	my $logs = shift;
	my $active = shift;
	unless ($active) {$active = "other"}
	my $return = 0;

	if ($message =~ / exceeds /) {$cluster = 1}

	my @report;
	$report[0] = $ip;
	if ($port) {$report[1] = "$port"} else {$report[1] = "*"}
	if ($perm) {$report[2] = "1"} else {$report[2] = "0"}
	if ($inout) {$report[3] = "$inout"} else {$report[3] = "inout"}
	if ($timeout) {$report[4] = "$timeout"} else {$report[4] = "0"}
	if ($message) {$report[5] = "$message"} else {$report[5] = " "}
	if ($logs) {$report[6] = "$logs"} else {$report[6] = " "}
	if ($active) {$report[7] = "$active"}

	my $ipv = checkip(\$ip);
	unless ($ipv) {return 1}
	my (undef,$iscidr) = split(/\//,$ip);
	if ($iscidr and !$cluster and ($active ne "CT_SUBNET_LIMIT")) {
		if ($config{DEBUG} >= 1) {logfile("debug: IP [$ip] not blocked, contains a CIDR (ignore already blocked message)")}
		return 1;
	}

	$0 = "lfd - (child) blocking $ip";

	my $blocked = 0;
	if (!$iscidr and ($config{LF_PERMBLOCK} or $config{LF_NETBLOCK})) {
		if (&denycheck($ip)) {
			$return = 2;
		} else {
			my $ips;
			my $ipmatch;
			my $ptext;
			my $nips;
			my $ntext;
			my $nipmatch;
			my $ipblock;
			my @newdata;
			my %skipip;
			my %skipnip;
			my $block_interval = $config{LF_PERMBLOCK_INTERVAL};
			if ($config{LF_NETBLOCK_INTERVAL} > $config{LF_PERMBLOCK_INTERVAL}) {$block_interval = $config{LF_NETBLOCK_INTERVAL}}
			if ($ipv == 4) {
				if ($config{LF_NETBLOCK_CLASS} eq "A") {
					if ($ip =~ /^(\d+)/) {$ipblock = "$1\.0\.0\.0/8"}
				}
				elsif ($config{LF_NETBLOCK_CLASS} eq "B") {
					if ($ip =~ /^(\d+\.\d+)/) {$ipblock = "$1\.0\.0/16"}
				}
				elsif ($config{LF_NETBLOCK_CLASS} eq "C") {
					if ($ip =~ /^(\d+\.\d+\.\d+)/) {$ipblock = "$1\.0/24"}
				}
			}
			elsif ($ipv == 6 and $config{LF_NETBLOCK_IPV6} ne "") {
				if ($config{LF_NETBLOCK_IPV6} eq "/64" or $config{LF_NETBLOCK_IPV6} eq "/56" or $config{LF_NETBLOCK_IPV6} eq "/48" or $config{LF_NETBLOCK_IPV6} eq "/32" or $config{LF_NETBLOCK_IPV6} eq "24") {
					eval {
						local $SIG{__DIE__} = undef;
						my $netip = $ip.$config{LF_NETBLOCK_IPV6};
						my $status = checkip(\$netip);
						if ($status == 6) {$ipblock = $netip}
					};
				}
			}

			sysopen ( my $TEMPIP, "/var/lib/csf/csf.tempip", O_RDWR | O_CREAT);
			flock ( $TEMPIP, LOCK_EX );
			my @data = <$TEMPIP>;
			chomp @data;
			foreach my $line ( @data ) {
				my ($oip,$operm,$otime,$omessage) = split(/\|/,$line,4);
				if (time - $otime < $block_interval) {
					push @newdata,$line;
				}
				if ($config{LF_PERMBLOCK} and !$perm) {
					if (($ip eq $oip) and ($operm != 1) and (time - $otime < $config{LF_PERMBLOCK_INTERVAL})) {
						$ips++;
						$ptext .= localtime($otime)." $omessage\n";
						$skipip{$line} = 1;
					}
					if ($operm and ($ip eq $oip)) {
						$ipmatch = 1;
					}
				}
				if ($config{LF_NETBLOCK} and ($ipv == 4) and $ipblock) {
					if (time - $otime < $config{LF_NETBLOCK_INTERVAL}) {
						my $block = "";
						if ($config{LF_NETBLOCK_CLASS} eq "A") {
							if ($oip =~ /^(\d+)/) {$block = "$1\.0\.0\.0/8"}
						}
						elsif ($config{LF_NETBLOCK_CLASS} eq "B") {
							if ($oip =~ /^(\d+\.\d+)/) {$block = "$1\.0\.0/16"}
						}
						elsif ($config{LF_NETBLOCK_CLASS} eq "C") {
							if ($oip =~ /^(\d+\.\d+\.\d+)/) {$block = "$1\.0/24"}
						}
						if ($block ne "" and ($ipblock eq $block)) {
							unless ($oip eq $ip) {
								$nips++;
								$ntext .= localtime($otime)." $omessage\n";
								$skipnip{$line} = 1;
							}
						}
#						if ($block eq $oip) {$nipmatch = 1}
					}
				}
				if ($config{LF_NETBLOCK} and ($ipv == 6) and $config{LF_NETBLOCK_IPV6} ne "" and $ipblock) {
					if (time - $otime < $config{LF_NETBLOCK_INTERVAL}) {
						my $block = "";
						eval {
							local $SIG{__DIE__} = undef;
							my $netip = $oip.$config{LF_NETBLOCK_IPV6};
							my $status = checkip(\$netip);
							if ($status == 6) {$block = $netip}
						};
						if ($block ne "" and ($ipblock eq $block)) {
							unless ($oip eq $ip) {
								$nips++;
								$ntext .= localtime($otime)." $omessage\n";
								$skipnip{$line} = 1;
							}
						}
#						if ($block eq $oip) {$nipmatch = 1}
					}
				}
			}
			if ($ipmatch) {
				$ips = 0;
				undef %skipip;
				if ($config{DEBUG} >= 1) {logfile("debug: $message - already PERM blocked")}
			} else {
				$ips++;
				$ptext .= localtime(time)." $message\n";
			}
			if ($nipmatch) {
				$nips = 0;
				undef %skipnip;
				if ($config{DEBUG} >= 1) {logfile("debug: $message - already NET blocked")}
			} else {
				$nips++;
				$ntext .= localtime(time)." $message\n";
			}

			if ($nips > $config{LF_NETBLOCK_COUNT}) {
				my $status = 0;
				if ($config{VPS}) {$status = &checkvps}
				if ($status) {
					logfile($status);
				} else {
					my $tip = iplookup($ipblock);
					$message = "(NETBLOCK) $tip has had more than $config{LF_NETBLOCK_COUNT} blocks in the last $config{LF_NETBLOCK_INTERVAL} secs";
					&syscommand(__LINE__,"/usr/sbin/csf","-d",$ipblock,"lfd: $message");
					logfile("$message - *Blocked in csf* [$active]");
					if ($config{CLUSTER_BLOCK} and $config{CLUSTER_SENDTO} and !$cluster) {&lfdclient(1,$message,$ipblock,"","inout","0")}
					if ($config{BLOCK_REPORT}) {&block_report($ipblock,"*","1","inout","0",$message,"","LF_NETBLOCK_COUNT")}
					if ($config{ST_ENABLE}) {&stats_report($ipblock,"*","1","inout","0",$message,"","LF_NETBLOCK_COUNT")}
					$blocked = 1;
				}

				if ($config{LF_NETBLOCK_ALERT}) {
					$0 = "lfd - (child) sending alert email for $ipblock";

					my @alert = slurp("/usr/local/csf/tpl/netblock.txt");
					my @message;
					my $tip = iplookup($ipblock);
					foreach my $line (@alert) {
						$line =~ s/\[block\]/$tip/ig;
						$line =~ s/\[count\]/$nips/ig;
						if (checkip(\$ipblock) == 4) {
							$line =~ s/\[class\]/$config{LF_NETBLOCK_CLASS}/ig;
						} else {
							$line =~ s/\[class\]/$config{LF_NETBLOCK_IPV6}/ig;
						}
						$line =~ s/\[ips\]/$ntext/ig;
						push @message, $line;
					}
					ConfigServer::Sendmail::relay("", "", @message);
				}

				$ip = $ipblock;
				$perm = 1;
				$blocked = 1;
			}
			elsif ($ips > $config{LF_PERMBLOCK_COUNT}) {
				my $status = 0;
				if ($config{VPS}) {$status = &checkvps}
				if ($status) {
					logfile($status);
				} else {
					my $tip = iplookup($ip);
					$message = "(PERMBLOCK) $tip has had more than $config{LF_PERMBLOCK_COUNT} temp blocks in the last $config{LF_PERMBLOCK_INTERVAL} secs";
					&syscommand(__LINE__,"/usr/sbin/csf","-tr",$ip);
					&syscommand(__LINE__,"/usr/sbin/csf","-d",$ip,"lfd: $message");
					logfile("$message - *Blocked in csf* [$active]");
					if ($config{CLUSTER_BLOCK} and $config{CLUSTER_SENDTO} and !$cluster) {&lfdclient(1,$message,$ip,"","inout","0")}
					if ($config{BLOCK_REPORT}) {&block_report($ip,"*","1","inout","0",$message,"","LF_PERMBLOCK_COUNT")}
					if ($config{ST_ENABLE}) {&stats_report($ip,"*","1","inout","0",$message,"","LF_PERMBLOCK_COUNT")}
					$blocked = 1;
				}
				if ($config{LF_PERMBLOCK_ALERT}) {
					$0 = "lfd - (child) sending alert email for $ip";

					my @alert = slurp("/usr/local/csf/tpl/permblock.txt");
					my $tip = iplookup($ip);
					my @message;
					foreach my $line (@alert) {
						$line =~ s/\[ip\]/$tip/ig;
						$line =~ s/\[count\]/$ips/ig;
						$line =~ s/\[blocks\]/$ptext/ig;
						push @message, $line;
					}
					ConfigServer::Sendmail::relay("", "", @message);
				}
				$perm = 1;
				$blocked = 1;
			}
			seek ( $TEMPIP, 0, 0 );
			truncate ( $TEMPIP, 0 );
			foreach my $line (@newdata) {
				if (($ips > $config{LF_PERMBLOCK_COUNT}) and ($skipip{$line})) { next }
				if (($nips > $config{LF_NETBLOCK_COUNT}) and ($skipnip{$line})) { next }
				print $TEMPIP "$line\n";
			}
			print $TEMPIP "$ip|$perm|".time."|$message\n";
			close ($TEMPIP);
		}
	}
	if (!$blocked and !$return) {
		if ($perm) {
			if ($port) {
				foreach my $dport (split(/\,/,$port)) {
					my $status = 0;
					if ($config{VPS}) {$status = &checkvps}
					if ($status) {
						logfile($status);
					} else {
						if (&denycheck("tcp|in|d=$dport|s=$ip",undef,$perm)) {
							$return = 2;
						} else {
							my ($tport,$proto) = split(/\;/,$dport);
							$dport = $tport;
							if ($proto eq "") {$proto = "tcp"}
							&syscommand(__LINE__,"/usr/sbin/csf","-d","$proto|in|d=$dport|s=$ip","lfd: $message");
							logfile("$message - *Blocked in csf* port=$dport [$active]");
							$blocked = 1;
						}
					}
				}
				if ($blocked) {$return = 0}
			} else {
				my $status = 0;
				if ($config{VPS}) {$status = &checkvps}
				if ($status) {
					logfile($status);
				} else {
					if (&denycheck($ip,undef,$perm)) {
						$blocked = 0;
						$return = 2;
					} else {
						$blocked = 1;
						&syscommand(__LINE__,"/usr/sbin/csf","-d",$ip,"lfd: $message");
						logfile("$message - *Blocked in csf* [$active]");
					}
				}
			}
			if ($blocked) {
				if ($config{CLUSTER_BLOCK} and $config{CLUSTER_SENDTO} and !$cluster) {&lfdclient(1,$message,$ip,$port,$inout,"0")}
				if ($config{BLOCK_REPORT}) {&block_report(@report)}
				if ($config{ST_ENABLE}) {&stats_report(@report)}
			}
		} else {
			if (&denycheck($ip,$port,$perm)) {
				$return = 2;
			} else {
				my $dropin = $config{DROP};
				my $dropout = $config{DROP_OUT};
				if ($config{DROP_IP_LOGGING}) {$dropin = "LOGDROPIN"}
				if ($config{DROP_OUT_LOGGING}) {$dropout = "LOGDROPOUT"}
				if ($timeout < 2) {$timeout = 3600}
				my $iptype = checkip(\$ip);

				if ($inout =~ /in/) {
					if ($port) {
						foreach my $dport (split(/\,/,$port)) {
							my ($tport,$proto) = split(/\;/,$dport);
							$dport = $tport;
							if ($proto eq "") {$proto = "tcp"}
							if ($iptype == 6) {
								&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -A DENYIN $eth6devin -p $proto --dport $dport -s $ip -j $dropin");
								if ($messengerports{$dport} and $config{MESSENGER6} and $config{MESSENGER_TEMP}) {&domessenger($ip,"A",$dport)}
							} else {
								&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -A DENYIN $ethdevin -p $proto --dport $dport -s $ip -j $dropin");
								if ($messengerports{$dport} and $config{MESSENGER} and $config{MESSENGER_TEMP}) {&domessenger($ip,"A",$dport)}
							}
						}
					} else {
						if ($iptype == 6) {
							&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -A DENYIN $eth6devin -s $ip -j $dropin");
							if ($config{MESSENGER6} and $config{MESSENGER_TEMP}) {&domessenger($ip,"A")}
						} else {
							&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -A DENYIN $ethdevin -s $ip -j $dropin");
							if ($config{MESSENGER} and $config{MESSENGER_TEMP}) {&domessenger($ip,"A")}
						}
					}
				}
				if ($inout =~ /out/) {
					if ($port) {
						foreach my $dport (split(/\,/,$port)) {
							my ($tport,$proto) = split(/\;/,$dport);
							$dport = $tport;
							if ($proto eq "") {$proto = "tcp"}
							if ($iptype == 6) {
								&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -A DENYOUT $eth6devout -p $proto --dport $dport -d $ip -j $dropout");
							} else {
								&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -A DENYOUT $ethdevout -p $proto --dport $dport -d $ip -j $dropout");
							}
						}
					} else {
						if ($iptype == 6) {
							&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -A DENYOUT $eth6devout -d $ip -j $dropout");
						} else {
							&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -A DENYOUT $ethdevout -d $ip -j $dropout");
						}
					}
				}
				sysopen (my $TEMPBAN, "/var/lib/csf/csf.tempban", O_WRONLY | O_APPEND | O_CREAT) or &shutdown_child(__LINE__,"*Error* Cannot append out file: $!");
				flock ($TEMPBAN, LOCK_EX);
				print $TEMPBAN time."|$ip|$port|$inout|$timeout|lfd - $message\n";
				close ($TEMPBAN);

				if ($message) {logfile("$message - *Blocked in csf* for $timeout secs [$active]")}
				if ($config{CLUSTER_BLOCK} and $config{CLUSTER_SENDTO} and !$cluster) {&lfdclient($perm,$message,$ip,$port,$inout,$timeout)}
				if ($config{BLOCK_REPORT}) {&block_report(@report)}
				if ($config{ST_ENABLE}) {&stats_report(@report)}
			}
		}
	}
	return $return;
}
# end ipblock
###############################################################################
# start ipunblock
sub ipunblock {
	if (! -z "/var/lib/csf/csf.tempban") {
		$SIG{CHLD} = 'IGNORE';
		unless (defined ($childpid = fork)) {
			&shutdown(__LINE__,"*Error* cannot fork: $!");
		} 
		$forks{$childpid} = 1;
		unless ($childpid) {
			$0 = "lfd - processing temporary bans";
			my $timer = time;
			if ($config{DEBUG} >= 3) {$timer = &timer("start","ipunblock",$timer)}
			sysopen (my $TEMPBAN, "/var/lib/csf/csf.tempban", O_RDWR | O_CREAT) or &shutdown_child(__LINE__,"Unable to open /var/lib/csf/csf.tempban: $!");
			unless (flock ($TEMPBAN, LOCK_EX | LOCK_NB)) {
				if ($config{DEBUG} >= 3) {logfile("debug: Unable to lock csf.tempban in ipunblock")}
			} else {
				my @data = <$TEMPBAN>;
				chomp @data;

				my $cnt = @data;
				my @newdata;
				foreach my $line ( @data ) {
					my $unblock = 0;
					my $logmess = "";
					if ($config{DENY_TEMP_IP_LIMIT} and ($cnt > $config{DENY_TEMP_IP_LIMIT})) {
						$unblock = 1;
						$logmess = "(too many temporary bans in list)";
					}
					my ($time,$ip,$port,$inout,$timeout,$message) = split(/\|/,$line);
					my $iptype = checkip(\$ip);
					if ((((time - $time) >= $timeout) and $ip) or $unblock) {
						my $dropin = $config{DROP};
						my $dropout = $config{DROP_OUT};
						if ($config{DROP_IP_LOGGING}) {$dropin = "LOGDROPIN"}
						if ($config{DROP_OUT_LOGGING}) {$dropout = "LOGDROPOUT"}

						if ($inout =~ /in/) {
							if ($port) {
								foreach my $dport (split(/\,/,$port)) {
									my ($tport,$proto) = split(/\;/,$dport);
									$dport = $tport;
									if ($proto eq "") {$proto = "tcp"}
									if ($iptype == 6) {
										&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -D DENYIN $eth6devin -p $proto --dport $dport -s $ip -j $dropin");
										if ($messengerports{$dport} and $config{MESSENGER6} and $config{MESSENGER_TEMP}) {&domessenger($ip,"D",$dport)}
									} else {
										&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -D DENYIN $ethdevin -p $proto --dport $dport -s $ip -j $dropin");
										if ($messengerports{$dport} and $config{MESSENGER} and $config{MESSENGER_TEMP}) {&domessenger($ip,"D",$dport)}
									}
									logfile("Incoming IP $ip:$dport temporary block removed");
									if ($config{UNBLOCK_REPORT}) {&unblock_report($ip,$dport)};
								}
							} else {
								if ($iptype == 6) {
									&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -D DENYIN $eth6devin -s $ip -j $dropin");
									if ($config{MESSENGER6} and $config{MESSENGER_TEMP}) {&domessenger($ip,"D")}
								} else {
									&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -D DENYIN $ethdevin -s $ip -j $dropin");
									if ($config{MESSENGER} and $config{MESSENGER_TEMP}) {&domessenger($ip,"D")}
								}
								logfile("Incoming IP $ip temporary block removed");
								if ($config{UNBLOCK_REPORT}) {&unblock_report($ip)};
							}
						}
						if ($inout =~ /out/) {
							if ($port) {
								foreach my $dport (split(/\,/,$port)) {
									my ($tport,$proto) = split(/\;/,$dport);
									$dport = $tport;
									if ($proto eq "") {$proto = "tcp"}
									if ($iptype == 6) {
										&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -D DENYOUT $eth6devout -p $proto --dport $dport -d $ip -j $dropout");
									} else {
										&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -D DENYOUT $ethdevout -p $proto --dport $dport -d $ip -j $dropout");
									}
									logfile("Outgoing IP $ip:$dport temporary block removed");
									if ($config{UNBLOCK_REPORT}) {&unblock_report($ip,$dport)};
								}
							} else {
								if ($iptype == 6) {
									&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -D DENYOUT $eth6devout -d $ip -j $dropout");
								} else {
									&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -D DENYOUT $ethdevout -d $ip -j $dropout");
								}
								logfile("Outgoing IP $ip temporary block removed");
							}
							if ($config{UNBLOCK_REPORT}) {&unblock_report($ip)};
						}
						if ($config{CF_ENABLE} and $message =~ /\(CF_ENABLE\)/) {&cloudflare("remove",$ip,$config{CF_BLOCK})}
					} else {
						push @newdata, $line;
					}
					$cnt--;
				}
				eval {
					local $SIG{__DIE__} = undef;
					local $SIG{'ALRM'} = sub {die};
					alarm(60);
					local $SIG{INT} = 'IGNORE';
					local $SIG{TERM} = 'IGNORE';
					local $SIG{HUP} = 'IGNORE';
					seek ($TEMPBAN, 0, 0);
					truncate ($TEMPBAN, 0);
					foreach my $line (@newdata) {print $TEMPBAN "$line\n"}
				};
				alarm(0);
			}
			close ($TEMPBAN);
			if ($config{DEBUG} >= 3) {$timer = &timer("stop","ipunblock",$timer)}
			$0 = "lfd - (child) closing";
			exit;
		}
	}
	if (! -z "/var/lib/csf/csf.tempallow") {
		$SIG{CHLD} = 'IGNORE';
		unless (defined ($childpid = fork)) {
			&shutdown(__LINE__,"*Error* cannot fork: $!");
		} 
		$forks{$childpid} = 1;
		unless ($childpid) {
			$0 = "lfd - processing temporary allows";
			my $timer = time;
			if ($config{DEBUG} >= 3) {$timer = &timer("start","ipunblock",$timer)}
			sysopen (my $TEMPALLOW, "/var/lib/csf/csf.tempallow", O_RDWR | O_CREAT) or &shutdown_child(__LINE__,"Enable to open /var/lib/csf/csf.tempallow: $!");
			unless (flock ($TEMPALLOW, LOCK_EX | LOCK_NB)) {
				if ($config{DEBUG} >= 3) {logfile("debug: Unable to lock csf.tempallow in ipunblock")}
			} else {
				my @data = <$TEMPALLOW>;
				chomp @data;

				my $cnt = @data;
				my @newdata;
				foreach my $line ( @data ) {
					my ($time,$ip,$port,$inout,$timeout,$message) = split(/\|/,$line);
					my $iptype = checkip(\$ip);
					if ((((time - $time) >= $timeout) and $ip)) {
						if ($inout =~ /in/) {
							if ($port) {
								foreach my $dport (split(/\,/,$port)) {
									my ($tport,$proto) = split(/\;/,$dport);
									$dport = $tport;
									if ($proto eq "") {$proto = "tcp"}
									if ($iptype == 6) {
										&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -D ALLOWIN $eth6devin -p $proto --dport $dport -s $ip -j $accept");
									} else {
										&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -D ALLOWIN $ethdevin -p $proto --dport $dport -s $ip -j $accept");
									}
									logfile("Incoming IP $ip:$dport temporary allow removed");
								}
							} else {
								if ($iptype == 6) {
									&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -D ALLOWIN $eth6devin -s $ip -j $accept");
								} else {
									&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -D ALLOWIN $ethdevin -s $ip -j $accept");
								}
								logfile("Incoming IP $ip temporary allow removed");
							}
						}
						if ($inout =~ /out/) {
							if ($port) {
								foreach my $dport (split(/\,/,$port)) {
									my ($tport,$proto) = split(/\;/,$dport);
									$dport = $tport;
									if ($proto eq "") {$proto = "tcp"}
									if ($iptype == 6) {
										&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -D ALLOWOUT $eth6devout -p $proto --dport $dport -d $ip -j $accept");
									} else {
										&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -D ALLOWOUT $ethdevout -p $proto --dport $dport -d $ip -j $accept");
									}
									logfile("Outgoing IP $ip:$dport temporary allow removed");
								}
							} else {
								if ($iptype == 6) {
									&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -D ALLOWOUT $eth6devout -d $ip -j $accept");
								} else {
									&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -D ALLOWOUT $ethdevout -d $ip -j $accept");
								}
								logfile("Outgoing IP $ip temporary allow removed");
							}
						}
						if ($config{CF_ENABLE} and $message =~ /\(CF_ENABLE\)/) {&cloudflare("remove",$ip,"whitelist")}
					} else {
						push @newdata, $line;
					}
					$cnt--;
				}
				eval {
					local $SIG{__DIE__} = undef;
					local $SIG{'ALRM'} = sub {die};
					alarm(60);
					local $SIG{INT} = 'IGNORE';
					local $SIG{TERM} = 'IGNORE';
					local $SIG{HUP} = 'IGNORE';
					seek ($TEMPALLOW, 0, 0);
					truncate ($TEMPALLOW, 0);
					foreach my $line (@newdata) {print $TEMPALLOW "$line\n"}
				};
				alarm(0);
			}
			close ($TEMPALLOW);
			if ($config{DEBUG} >= 3) {$timer = &timer("stop","ipunblock",$timer)}
			$0 = "lfd - (child) closing";
			exit;
		}
	}
	return;
}
# end ipunblock
###############################################################################
# start cloudflare
sub cloudflare {
	my $action = shift;
	my $ip = shift;
	my $mode = shift;
	my $domains = shift;;

	$SIG{CHLD} = 'IGNORE';
	unless (defined ($childpid = fork)) {
		&shutdown(__LINE__,"*Error* cannot fork: $!");
	} 
	$forks{$childpid} = 1;
	unless ($childpid) {
		my $timer = time;
		if ($config{DEBUG} >= 3) {$timer = &timer("start","cloudflare",$timer)}
		$0 = "lfd - (child) CloudFlare $action...";

		if ($action eq "remove") {
			ConfigServer::CloudFlare::action("remove",$ip,$mode);
		}
		elsif ($action eq "deny") {
			ConfigServer::CloudFlare::action("deny",$ip,$config{CF_BLOCK},"",$domains,1);
		}

		if ($config{DEBUG} >= 3) {$timer = &timer("stop","cloudflare",$timer)}
		$0 = "lfd - (child) closing";
		exit;
	}
	return;
}
# end cloudflare
###############################################################################
# start block_report
sub block_report {
	my @report = @_;
	$SIG{CHLD} = 'IGNORE';
	unless (defined ($childpid = fork)) {
		&shutdown(__LINE__,"*Error* cannot fork: $!");
	} 
	$forks{$childpid} = 1;
	unless ($childpid) {
		my $timer = time;
		if ($config{DEBUG} >= 3) {$timer = &timer("start","block_report",$timer)}
		$0 = "lfd - (child) Block Report...";

		eval {
			local $SIG{__DIE__} = undef;
			local $SIG{'ALRM'} = sub {die};
			alarm(10);
			if ($config{DEBUG} >= 1) {&logfile("debug: BLOCK_REPORT [$config{BLOCK_REPORT}] triggered")}
			system($config{BLOCK_REPORT},@report);
			alarm(0);
		};
		alarm(0);
		if ($@) {
			logfile("BLOCK_REPORT timed out after 10 seconds");
		} else {
			if ($config{DEBUG} >= 3) {logfile("debug: BLOCK_REPORT [$config{BLOCK_REPORT}] for ['$report[0]' '$report[1]' '$report[2]' '$report[3]' '$report[4]' '$report[5]']")}
		}

		if ($config{DEBUG} >= 3) {$timer = &timer("stop","block_report",$timer)}
		$0 = "lfd - (child) closing";
		exit;
	}
	return;
}
# end block_report
###############################################################################
# start unblock_report
sub unblock_report {
	my $ip = shift;
	my $port = shift;
	$SIG{CHLD} = 'IGNORE';
	unless (defined ($childpid = fork)) {
		&shutdown(__LINE__,"*Error* cannot fork: $!");
	} 
	$forks{$childpid} = 1;
	unless ($childpid) {
		my $timer = time;
		if ($config{DEBUG} >= 3) {$timer = &timer("start","unblock_report",$timer)}
		$0 = "lfd - (child) Block Report...";

		eval {
			local $SIG{__DIE__} = undef;
			local $SIG{'ALRM'} = sub {die};
			alarm(10);
			system($config{UNBLOCK_REPORT},$ip,$port);
			alarm(0);
		};
		alarm(0);
		if ($@) {
			logfile("UNBLOCK_REPORT timed out after 10 seconds");
		} else {
			if ($config{DEBUG} >= 3) {logfile("debug: UNBLOCK_REPORT [$config{UNBLOCK_REPORT}] for [$ip] [$port]")}
		}

		if ($config{DEBUG} >= 3) {$timer = &timer("stop","unblock_report",$timer)}
		$0 = "lfd - (child) closing";
		exit;
	}
	return;
}
# end unblock_report
###############################################################################
# start stats_report
sub stats_report {
	my @report = @_;
	$SIG{CHLD} = 'IGNORE';
	unless (defined ($childpid = fork)) {
		&shutdown(__LINE__,"*Error* cannot fork: $!");
	} 
	$forks{$childpid} = 1;
	unless ($childpid) {
		my $timer = time;
		if ($config{DEBUG} >= 3) {$timer = &timer("start","stats_report",$timer)}
		$0 = "lfd - (child) Stats Report...";

		my $lockstr = "ST_ENABLE_report";
		sysopen (my $THISLOCK, "/var/lib/csf/lock/$lockstr.lock", O_RDWR | O_CREAT) or &shutdown_child("*Error* Unable to open /var/lib/csf/lock/$lockstr.lock");
		unless (flock ($THISLOCK, LOCK_EX | LOCK_NB)) {
			if ($config{DEBUG} >= 1) {
				&shutdown_child("debug: *Lock Error* [$lockstr] still active - section skipped");
			} else {
				&shutdown_child;
			}
		}
		print $THISLOCK time;

		#[0-23] hour, [24-54] day, [55-57] month
		my $STATS;
		if (-e "/var/lib/csf/stats/lfdstats") {
			sysopen ($STATS,"/var/lib/csf/stats/lfdstats", O_RDWR | O_CREAT);
		}
		elsif (-e "/var/lib/csf/stats/lfdmain") {
			sysopen (my $OLDSTATS,"/var/lib/csf/stats/lfdmain", O_RDWR | O_CREAT);
			flock ($OLDSTATS, LOCK_EX);
			my @stats = <$OLDSTATS>;
			chomp @stats;

			my @newstats;
			my $cnt = 0;
			foreach my $line (@stats) {
				if ($cnt == 55) {push @newstats,""}
				push @newstats,$line;
				$cnt++;
			}
			sysopen (my $STATS,"/var/lib/csf/stats/lfdstats", O_RDWR | O_CREAT);
			flock ($STATS, LOCK_EX);
			seek ($STATS, 0, 0);
			truncate ($STATS, 0);
			foreach my $line (@newstats) {
				print $STATS "$line\n";
			}
			close ($STATS);

			rename "/var/lib/csf/stats/lfdmain", "/var/lib/csf/stats/lfdmain.".time;
			close ($OLDSTATS);
			sysopen ($STATS,"/var/lib/csf/stats/lfdstats", O_RDWR | O_CREAT);
		} else {
			sysopen ($STATS,"/var/lib/csf/stats/lfdstats", O_RDWR | O_CREAT);
		}
		flock ($STATS, LOCK_EX);
		my @stats = <$STATS>;
		chomp @stats;

		my $perm = $report[2];
		my $trigger = $report[7];
		my $time = time;
		my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime($time);
		my @line;
		my %triggers;
		my $permdate;
		my $permcount;
		my $tempdate;
		my $tempcount;
		my $loop;

		@line = split(/\,/,$stats[$hour]);
		$permdate = $line[0];
		$permcount = $line[1];
		$tempdate = $line[2];
		$tempcount = $line[3];
		for ($loop = 4; $loop < @line; $loop+=2) {
			if ($time - $line[$loop] > (24 * 60 * 60)) { next }
			my ($triggerstat,$triggercount) = split(/\:/,$line[$loop+1]);
			$triggers{$triggerstat}{date} = $line[$loop];
			$triggers{$triggerstat}{count} = $triggercount;
		}
		$triggers{$trigger}{date} = $time;
		$triggers{$trigger}{count}++;
		if ($time - $permdate > (24 * 60 * 60)) {$permdate = 0; $permcount = 0}
		if ($time - $tempdate > (24 * 60 * 60)) {$tempdate = 0; $tempcount = 0}
		if ($perm) {$permdate = $time; $permcount++} else {$tempdate = $time; $tempcount++}
		$stats[$hour] = "$permdate,$permcount,$tempdate,$tempcount";
		foreach my $key (keys %triggers) {$stats[$hour] .= ",$triggers{$key}{date},$key:$triggers{$key}{count}"}
		
		@line = split(/\,/,$stats[$mday+24]);
		undef %triggers;
		$permdate = $line[0];
		$permcount = $line[1];
		$tempdate = $line[2];
		$tempcount = $line[3];
		for ($loop = 4; $loop < @line; $loop+=2) {
			if ($time - $line[$loop] > (29 * 24 * 60 * 60)) { next }
			my ($triggerstat,$triggercount) = split(/\:/,$line[$loop+1]);
			$triggers{$triggerstat}{date} = $line[$loop];
			$triggers{$triggerstat}{count} = $triggercount;
		}
		$triggers{$trigger}{date} = $time;
		$triggers{$trigger}{count}++;
		if ($time - $permdate > (29 * 24 * 60 * 60)) {$permdate = 0; $permcount = 0}
		if ($time - $tempdate > (29 * 24 * 60 * 60)) {$tempdate = 0; $tempcount = 0}
		if ($perm) {$permdate = $time; $permcount++} else {$tempdate = $time; $tempcount++}
		$stats[$mday+24] = "$permdate,$permcount,$tempdate,$tempcount";
		foreach my $key (keys %triggers) {$stats[$mday+24] .= ",$triggers{$key}{date},$key:$triggers{$key}{count}"}

		@line = split(/\,/,$stats[$mon+56]);
		undef %triggers;
		$permdate = $line[0];
		$permcount = $line[1];
		$tempdate = $line[2];
		$tempcount = $line[3];
		for ($loop = 4; $loop < @line; $loop+=2) {
			if ($time - $line[$loop] > (364 * 24 * 60 * 60)) { next }
			my ($triggerstat,$triggercount) = split(/\:/,$line[$loop+1]);
			$triggers{$triggerstat}{date} = $line[$loop];
			$triggers{$triggerstat}{count} = $triggercount;
		}
		$triggers{$trigger}{date} = $time;
		$triggers{$trigger}{count}++;
		if ($time - $permdate > (364 * 24 * 60 * 60)) {$permdate = 0; $permcount = 0}
		if ($time - $tempdate > (364 * 24 * 60 * 60)) {$tempdate = 0; $tempcount = 0}
		if ($perm) {$permdate = $time; $permcount++} else {$tempdate = $time; $tempcount++}
		$stats[$mon+56] = "$permdate,$permcount,$tempdate,$tempcount";
		foreach my $key (keys %triggers) {$stats[$mon+56] .= ",$triggers{$key}{date},$key:$triggers{$key}{count}"}

		if ($config{CC_LOOKUPS}) {
			my $cc = "**";
			my %ccs;
			@line = split(/\,/,$stats[69]);
			if ($report[5] =~ /\s\((\w\w)\//) {$cc = $1}
			for (my $x = 0; $x < @line; $x+=2) {$ccs{$line[$x]} = $line[$x+1]}
			$ccs{$cc}++;
			$stats[69] = "";
			foreach my $key (keys %ccs) {$stats[69] .= "$key,$ccs{$key},"}
		}

		seek ($STATS, 0, 0);
		truncate ($STATS, 0);
		foreach my $line (@stats) {
			print $STATS "$line\n";
		}
		close ($STATS);

		close ($THISLOCK);

		if ($config{DEBUG} >= 3) {$timer = &timer("stop","stats_report",$timer)}
		$0 = "lfd - (child) closing";
		exit;
	}
	return;
}
# end stats_report
###############################################################################
# start checkvps
sub checkvps {
	if (-e "/proc/user_beancounters" and !(-e "/proc/vz/version")) {
		open (my $INVPS, "<", "/proc/user_beancounters");
		flock ($INVPS, LOCK_SH);
		my @data = <$INVPS>;
		close ($INVPS);
		chomp @data;

		foreach my $line ( @data ) {
			if ($line =~ /^\s*numiptent\s+(\d*)\s+(\d*)\s+(\d*)\s+(\d*)/) {
				if ($1 > $4 - 10) {return "The VPS iptables rule limit (numiptent) is too low ($1/$4) - *IP not blocked*"}
			}
		}
	}
	return 0;
}

# #
#   Messenger › ReCaptcha
#   
#   All reCAPTCHA files are stored in the $homedir of the user
#   configured in csf.conf as:
#       MESSENGER_USER = "csf"
#   
#   If MESSENGER_USER blank "" in csf.conf; LFD throws:
#       [ConfigServer::Messenger] Configured account [none] is invalid. 
#       Must create a dedicated user! MESSENGER service *disabled*
#   
#   To define $homedir, LFD uses getpwnam() on MESSENGER_USER.
#   This retrieves the same account info shown by:
#       getent passwd csf
#   
#   Eg:
#       csf:x:974:974::/home/csf:/usr/sbin/nologin
#   
#   getpwnam() returns separated account args, LFD can get values 
#   such as UID, GID, and homedir.
#   
#   When starting CSF, LFD checks $homedir for the files required
#   by reCAPTCHA. The following files/folders are created as part 
#   of the CSF startup process:
#       /home/csf/en.php
#       /home/csf/public_html
#       /home/csf/recaptcha.php
#   
#   unblock.txt file is not created during startup. It is created
#   after a user completes a reCAPTCHA challenge on a CSF page. We
#   can use the local test page to trigger this:
#       https://localhost:8887/
#   
#   After the challenge is completed, the user's IP is temp written
#   inside unblock.txt. This file acts as a queue, not a log.
#   
#   LFD then periodically scans unblock.txt (5s) and validates each
#   queued line to see if it's a valid IP. For each valid IP address,
#   LFD runs:
#       csf -dr <ip_address>    Remove IP from /etc/csf/csf.deny
#       csf -tr <ip_address>    Remove IP from temporary IP lists
#   
#   After all valid entries are processed, unblock.txt is truncated
#   and waits for the next batch.
#   
#   @note           localhost (127.0.0.1) is intentionally not seen
#                   as a valid IP by checkip(); will reject.
# #

sub messengerrecaptcha
{
	my $timer = time;
	my ( undef, undef, $uid, $gid, undef, undef, undef, $homedir ) = getpwnam( $config{MESSENGER_USER} );

    # #
    #   unblock.txt › Get Current State
    # #

	if ( !-e "$homedir/unblock.txt" )
    {
        logfile( "DEBUG:0", "warn", "$homedir/unblock.txt - File missing" );
        return
    }
	elsif ( -z "$homedir/unblock.txt" )
    {
        logfile( "DEBUG:2", "info", "$homedir/unblock.txt - File empty with no queued entries" );
        return
    }
    else
    {
        logfile( "DEBUG:0", "info", "$homedir/unblock.txt - Contains queued entries. LFD will process the queue in approximately $config{LF_PARSE} seconds." );
    }

    # #
    #   Fork; if fork() returns undef, shutdown().
    #   Child process could not be created.
    # #

	$SIG{CHLD} = 'IGNORE';
	unless ( defined ( $childpid = fork ) )
    {
		&shutdown( __LINE__,"*Error* cannot fork: $!" );
	} 

	$forks{$childpid} = 1;
	unless ($childpid)
    {
		if ( $config{DEBUG} >= 3 )
        {
            $timer = &timer( "start", "messengerrecaptcha", $timer )
        }
    
		$0 = "lfd - reCAPTCHA csf...";
		$childproc      = "Messenger (Recaptcha)";
		$SIG{INT}       = \&shutdown_child;
		$SIG{TERM}      = \&shutdown_child;
		$SIG{HUP}       = \&shutdown_child;
		$SIG{__DIE__}   = sub {&shutdown_child(@_);};

		if ( -f "$homedir/unblock.txt" )
        {
            logfile( "DEBUG:1", "ok", "$homedir/unblock.txt - File found" );

			my @alert   = slurp( "/usr/local/csf/tpl/recaptcha.txt" );
			sysopen     ( my $UNBLOCK, "$homedir/unblock.txt", O_RDWR | O_CREAT );
			flock       ( $UNBLOCK, LOCK_EX );
    
			while ( my $line = <$UNBLOCK> )
            {
				chomp $line;
				my ( $unblockip, $host, $hostip ) = split( /;/, $line );
                logfile( "DEBUG:1", "ok", "$homedir/unblock.txt - Entry found: [$unblockip ($host:$hostip)]" );

                # #
                #   Unblock › Intentionally block localhost
                # #

                if ( $unblockip eq "127.0.0.1" || $unblockip eq "::1" )
                {
                    logfile( "DEBUG:1", "warn", "$homedir/unblock.txt - Entry skipped checkip(): [$unblockip ($host:$hostip)] - loopback addresses are intentionally excluded by checkip()" );
                }

                # #
                #   Unblock › Unblock IP accepted as valid IP
                #   
                #   checkip     (CheckIP.pm) accepts string or scalar reference.
                #               Accepts CIDR notation (CIDR must contain only digits).
                #   
                #   @ranges         ipv4        /1 - /32
                #                   ipv6        /1 - /128
                #   
                #   @examples       127.0.0.1           0               (reject)
                #                   ::1                 0               (reject)
                #                   192.168.1.1/33      0               (reject)
                #                   127.0.0.2           4               (accept)
                #                   127.1.2.3           4               (accept)
                #                   127.255.255.255     4               (accept)
                #                   2001:db8::1         6               (accept)
                #                   2001:db8::1/64      6               (accept)
                #   
                #   @returns        numeric     status
                #                   0           invalid/rejected
                #                   4           Valid ipv4
                #                   6           Valid ipv6
                # #

                elsif ( checkip(\$unblockip) )
                {
                    logfile( "DEBUG:1", "ok", "$homedir/unblock.txt - Entry passed checkip(): [$unblockip ($host:$hostip)] is a valid IP address." );

					&logfile( "reCAPTCHA: Unblocking client [$unblockip] on domain [$host ($hostip)]" );
					&syscommand(__LINE__,"/usr/sbin/csf","-dr",$unblockip);
					&syscommand(__LINE__,"/usr/sbin/csf","-tr",$unblockip);

					if ( $config{RECAPTCHA_ALERT} )
                    {
						my $tip = iplookup( $unblockip );
						my @message;
						foreach my $line ( @alert )
                        {
							$line =~ s/\[ip\]/$tip/ig;
							$line =~ s/\[host\]/$host ($hostip)/ig;
							push @message, $line;
						}

						ConfigServer::Sendmail::relay( "", "", @message );
                        logfile( "DEBUG:1", "ok", "$homedir/unblock.txt - Email sent for reCAPTCHA entry unblocked: [$unblockip]" );
					}
                }

                # #
                #   Unblock › Unblock IP denied; not valid IP
                # #

                else
                {
                    logfile( "DEBUG:1", "warn", "$homedir/unblock.txt - Entry failed checkip(): [$unblockip ($host:$hostip)] is not a valid IP address." );
				}
			}

			seek        ( $UNBLOCK, 0, 0    );
			truncate    ( $UNBLOCK, 0       );
			close       ( $UNBLOCK          );
		}

		if ( $config{DEBUG} >= 3 )
        {
            $timer = &timer( "stop", "messengerrecaptcha", $timer )
        }

		exit;
	}
	return;
}

# #
#	Messenger › Audit Log
#   
#   Validate the messenger user, such as the uid/gid, and prepare the
#   audit log with the correct ownership
#   
#   @account                csf !! 974 974    /home/csf /usr/sbin/nologin
#   $messenger_user         csf
#   $messenger_uid          974
#   $messenger_gid          974 
#   $log_ok                 1
# #

sub _prepare_messenger_audit_log
{
	my ( $messenger_user ) = @_;

	return ( undef, "Invalid Messenger account" )
		if !defined( $messenger_user ) or ref( $messenger_user ) or $messenger_user eq "";

	my @account = getpwnam( $messenger_user );
	return ( undef, "Invalid Messenger account" )
		if !@account;

	my ( $messenger_uid, $messenger_gid ) = @account[ 2, 3 ];
	return ( undef, "Invalid Messenger account" )
		if !defined( $messenger_uid ) or !defined( $messenger_gid ) or $messenger_uid <= 0 or $messenger_gid <= 0;

	my ( $log_ok, $log_error ) = ConfigServer::Logger::msngr_log_prepare( $messenger_uid, $messenger_gid );
	$log_error = "Unable to prepare the Messenger audit log"
		if !$log_ok and !defined( $log_error );

	return ( $log_ok, $log_error );
}

# #
#	Messenger › Service Disable
#   
#   Terminate any active Messenger processes, disable every Messenger mode
#   when its audit log cannot be prepared.
# #

sub _disable_messenger_services
{
	my ( $log_error ) = @_;

	$log_error = "Unknown Messenger audit log failure"
		if !defined( $log_error );

	logfile( "normal", "error", "[Messenger] Secure audit log check failed " . "[$log_error]; service disabled" );

    # #
    #   Terminate every active Messenger child processes
    # #

	for my $messenger_pid ( values %messengerips )
	{
		next
			if !defined( $messenger_pid ) or $messenger_pid !~ /\A[0-9]+\z/ or $messenger_pid <= 1;

		kill( "TERM", $messenger_pid );
	}

    # #
    #   Runs messengerstop( ); which requires you to specify version number.
    #       &messengerstop( 2 );
    #       &messengerstop( 3 );
    # #

	%messengerips = ();
	@config{
		qw(
			MESSENGER
			MESSENGER6
			MESSENGERV2
			MESSENGERV3
		)
	} = ( 0 ) x 4;

	for my $messenger_version ( 2, 3 )
	{
		messengerstop( $messenger_version );
	}

	return;
}

# #
#   Messenger › Service Monitoring
#   
#   Restart configured Messenger listeners whose recorded processes are
#   no longer running.
#   
#   $messenger_pid          916094
#   $incoming_ports         21
#   $service_type           TEXT
#   $messenger_user         csf
# #

sub _restart_failed_messenger_services
{
	my ( $messenger_user ) = @_;

	for my $service_type ( keys %messengerips )
	{
		my $messenger_pid   = $messengerips{$service_type};
		my $incoming_ports  = $config{"MESSENGER_${service_type}_IN"};

        # #
        #   Skip bad process ids; all numeric
        # #

		next
			if !defined( $messenger_pid ) or
			   $messenger_pid !~ /\A[0-9]+\z/ or
			   $messenger_pid <= 1;

        # #
        #   Skip $incoming_ports missing
        # #

		next
			if !defined( $incoming_ports ) or
			   $incoming_ports eq "";

        # #
        #   Skip if service process is still running
        # #

		next
			if kill( 0, $messenger_pid );

        # #
        #   Start a Messenger service in a child process, track the PID,
        #   and temp disable service if startup fails
        # #

		messenger( $config{"MESSENGER_${service_type}"}, $messenger_user, $service_type, );
		logfile( "Messenger $service_type Service died, restarted" );
	}

	return;
}

sub messengerstop
{
	my $version = shift;
	if ( $version == 1 )
	{
		return;
	}
	elsif ($version == 2)
	{
		if ( -e "/etc/apache2/conf.d/csf.messenger.conf" )
		{
			unlink( "/etc/apache2/conf.d/csf.messenger.conf" );
			system( "/scripts/restartsrv_httpd" );
            logfile( "DEBUG:1", "info", "[MessengerV2] Found file /etc/apache2/conf.d/csf.messenger.conf; removing" );
		}
	}
	elsif ($version == 3)
	{
		if ( -d $config{MESSENGERV3LOCATION} )
		{
			if ( -e $config{MESSENGERV3LOCATION} . "/csf.messenger.conf" )
			{
				unlink( $config{MESSENGERV3LOCATION} . "/csf.messenger.conf" );
				system( $config{MESSENGERV3RESTART} );

                logfile( "DEBUG:1", "info", "[MessengerV3] Found configuration file [" . $config{MESSENGERV3LOCATION} . "/csf.messenger.conf]; removing" );

			}
		}
		elsif (-f $config{MESSENGERV3LOCATION}) {
			my @conf = slurp($config{MESSENGERV3LOCATION});
			if (grep {$_ =~ m[^Include /var/lib/csf/csf.conf]i} @conf) {
				sysopen (my $FILE, $config{MESSENGERV3LOCATION}, O_WRONLY | O_CREAT | O_TRUNC);
				flock ($FILE, LOCK_EX);
	
				foreach my $line (@conf)
				{
			        $line =~ s/$cleanreg//g;
					if ($line =~ m[^Include /var/lib/csf/csf.conf]i) { next }
					print $FILE $line."\n";
				}

				close ($FILE);
				system($config{MESSENGERV3RESTART});

                logfile( "DEBUG:1", "info", "[MessengerV3] Found Include directive in [" . $config{MESSENGERV3LOCATION} . "]; removing" );
			}
		}
	}
	
	return;
}

sub messenger
{
	my $port = shift;
	my $user = shift;
	my $type = shift;
	my $timer = time;

	$SIG{CHLD} = 'IGNORE';
	unless (defined ($childpid = fork)) {
		&shutdown(__LINE__,"*Error* cannot fork: $!");
	} 

	$forks{$childpid} 		= 1;
	$messengerips{$type} 	= $childpid;
	unless ( $childpid )
	{
		if ( $config{DEBUG} >= 3 )
		{
			$timer = &timer( "start", "messenger", $timer)
		}

		$0 				= "lfd - messenger csf...";
		$SIG{INT} 		= \&shutdown_child;
		$SIG{TERM} 		= \&shutdown_child;
		$SIG{HUP} 		= \&shutdown_child;
		$SIG{__DIE__} 	= sub {&shutdown_child(@_);};
		$childproc 		= "Messenger ($type)";

		my ( $status, $reason ) = $messenger1->start( $port, $user, $type );
		if ( $status )
		{
            logfile( "all", "error", "[MessengerV1] Failed to start $type service: $reason" );

			sysopen     (my $TEMPCONF, "/var/lib/csf/csf.tempconf", O_WRONLY | O_APPEND | O_CREAT) or &shutdown_child(__LINE__,"*Error* Cannot append out file: $!");
			flock       ($TEMPCONF, LOCK_EX);
			print       $TEMPCONF "MESSENGER_${type}_IN = \"\"\n";
			close       ( $TEMPCONF );

            logfile( "all", "error", "[MessengerV1] Temporarily disabled $type service after startup failure" );
		}

		if ( $config{DEBUG} >= 3 )
		{
			$timer = &timer( "stop", "messenger", $timer )
		}

		exit;
	}
	return;
}

sub messengerv2
{
	my $timer   = time;
	$SIG{CHLD}  = 'IGNORE';

	unless (defined ($childpid = fork))
    {
		&shutdown(__LINE__,"*Error* cannot fork: $!");
	} 

	$forks{$childpid} = 1;
	unless ($childpid)
    {
		if ($config{DEBUG} >= 3) {$timer = &timer("start","messengerv2",$timer)}
		$0 = "lfd - messenger csf...";

		my ($status,$reason) = $messenger2->start();
		if ($status)
        {
            logfile( "all", "error", "[MessengerV2] Failed to start service: $reason" );
		}

		if ($config{DEBUG} >= 3) {$timer = &timer("stop","messengerv2",$timer)}
		exit;
	}
	return;
}

sub messengerv3
{
	my $timer = time;
	$SIG{CHLD} = 'IGNORE';

	unless (defined ($childpid = fork))
	{
		&shutdown(__LINE__,"*Error* cannot fork: $!");
	} 

	$forks{$childpid} = 1;
	unless ($childpid)
	{
		if ($config{DEBUG} >= 3) {$timer = &timer("start","messengerv3",$timer)}
		$0 = "lfd - messenger csf...";

		my ($status,$reason) = $messenger3->start();
		if ($status)
        {
			logfile( "[" . PACKAGE_NAME . "] [" . ConfigServer::Messenger::SUB_MESSENGER_V3( ) . "] Error: $reason");
		}

		if ($config{DEBUG} >= 3) {$timer = &timer("stop","messengerv3",$timer)}
		exit;
	}
	return;
}

sub domessenger
{
	my $ip = shift;
	my $delete = shift;
	my $ports = shift;
	if ($ports eq "") {$ports = "$config{MESSENGER_HTTPS_IN},$config{MESSENGER_HTML_IN},$config{MESSENGER_TEXT_IN}"}
	my $iptype = checkip(\$ip);

	if ($config{CC_MESSENGER_ALLOW} or $config{CC_MESSENGER_DENY}) {
		my ($cc,$asn) = iplookup($ip,1);
		($asn,undef) = split(/\s+/,$asn);

		if ($config{CC_MESSENGER_ALLOW}) {
			my $allow = 0;
			if ($cc ne "" and $config{CC_MESSENGER_ALLOW} =~ /$cc/i) {$allow = 1}
			if ($asn ne "" and $config{CC_MESSENGER_ALLOW} =~ /$asn/i) {$allow = 1}
			unless ($allow) {return 1}
		}

		if ($config{CC_MESSENGER_DENY}) {
			if ($cc ne "" and $config{CC_MESSENGER_DENY} =~ /$cc/i) {return 1}
			if ($asn ne "" and $config{CC_MESSENGER_DENY} =~ /$asn/i) {return 1}
		}
	}

	my $del = "-A";
	if ($delete eq "D") {$del = "-D"}

	my %textin;
	my %htmlin;
	my %httpsin;
	foreach my $port (split(/\,/,$config{MESSENGER_HTTPS_IN})) {$httpsin{$port} = 1}
	foreach my $port (split(/\,/,$config{MESSENGER_HTML_IN})) {$htmlin{$port} = 1}
	foreach my $port (split(/\,/,$config{MESSENGER_TEXT_IN})) {$textin{$port} = 1}

	my $textports;
	my $htmlports;
	my $httpsports;
	foreach my $port (split(/\,/,$ports)) {
		if ($httpsin{$port}) {
			if ($httpsports eq "") {$httpsports = "$port"} else {$httpsports .= ",$port"}
		}
		if ($htmlin{$port}) {
			if ($htmlports eq "") {$htmlports = "$port"} else {$htmlports .= ",$port"}
		}
		if ($textin{$port}) {
			if ($textports eq "") {$textports = "$port"} else {$textports .= ",$port"}
		}
	}

	if ($config{LF_IPSET}) {
		if ($delete eq "D") {
			if ($iptype == 4) {
				&ipsetdel("MESSENGER",$ip);
			}
			if ($iptype == 6 and $config{MESSENGER6}) {
				&ipsetdel("MESSENGER_6",$ip);
			}
		} else {
			if ($iptype == 4) {
				&ipsetadd("MESSENGER",$ip);
			}
			if ($iptype == 6 and $config{MESSENGER6}) {
				&ipsetadd("MESSENGER_6",$ip);
			}
		}
	} else {
		if ($httpsports ne "") {
			if ($iptype == 4) {
				&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -t nat $del PREROUTING $ethdevin -p tcp -s $ip -m multiport --dports $httpsports -j REDIRECT --to-ports $config{MESSENGER_HTTPS}");
			}
			if ($iptype == 6 and $config{MESSENGER6}) {
				&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -t nat $del PREROUTING $ethdevin -p tcp -s $ip -m multiport --dports $httpsports -j REDIRECT --to-ports $config{MESSENGER_HTTPS}");
			}
		}
		if ($htmlports ne "") {
			if ($iptype == 4) {
				&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -t nat $del PREROUTING $ethdevin -p tcp -s $ip -m multiport --dports $htmlports -j REDIRECT --to-ports $config{MESSENGER_HTML}");
			}
			if ($iptype == 6 and $config{MESSENGER6}) {
				&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -t nat $del PREROUTING $ethdevin -p tcp -s $ip -m multiport --dports $htmlports -j REDIRECT --to-ports $config{MESSENGER_HTML}");
			}
		}
		if ($textports ne "") {
			if ($iptype == 4) {
				&iptablescmd(__LINE__,"$config{IPTABLES} $config{IPTABLESWAIT} -t nat $del PREROUTING $ethdevin -p tcp -s $ip -m multiport --dports $textports -j REDIRECT --to-ports $config{MESSENGER_TEXT}");
			}
			if ($iptype == 6 and $config{MESSENGER6}) {
				&iptablescmd(__LINE__,"$config{IP6TABLES} $config{IPTABLESWAIT} -t nat $del PREROUTING $ethdevin -p tcp -s $ip -m multiport --dports $textports -j REDIRECT --to-ports $config{MESSENGER_TEXT}");
			}
		}
	}
	return;
}

# #
#	Interface
# #

sub ui
{
	$SIG{CHLD} = 'IGNORE';
	unless (defined ($childpid = fork))
	{
		&shutdown(__LINE__,"*Error* cannot fork: $!");
	} 

	$forks{$childpid} = 1;
	$uiip = $childpid;
	unless ($childpid)
	{
		$0 = "lfd UI";
		$SIG{INT} = \&shutdown_child;
		$SIG{TERM} = \&shutdown_child;
		$SIG{HUP} = \&shutdown_child;
		$SIG{__DIE__} = sub {&shutdown_child(@_);};
		$childproc = "UI";

		my @alert = slurp("/usr/local/csf/tpl/uialert.txt");
		my $server;

		if ($config{IPV6})
		{
			$server = IO::Socket::SSL->new(
						Domain => AF_INET6,
						LocalAddr => $config{UI_IP},
						LocalPort => $config{UI_PORT},
						Type => SOCK_STREAM,
						ReuseAddr => 1,
						Listen => $config{UI_CHILDREN},
						SSL_server => 1,
						SSL_use_cert => 1,
						SSL_cipher_list => $config{UI_CIPHER},
						SSL_honor_cipher_order => 1,
						SSL_version => $config{UI_SSL_VERSION},
						SSL_key_file => '/etc/csf/ui/server.key',
						SSL_cert_file => '/etc/csf/ui/server.crt',
			) or &shutdown_child(__LINE__,"UI: *Error* cannot open server on port $config{UI_PORT}: ".IO::Socket::SSL->errstr);
		}
		else
		{
			$server = IO::Socket::SSL->new(
						Domain => AF_INET,
						LocalAddr => $config{UI_IP},
						LocalPort => $config{UI_PORT},
						Type => SOCK_STREAM,
						ReuseAddr => 1,
						Listen => $config{UI_CHILDREN},
						SSL_server => 1,
						SSL_use_cert => 1,
						SSL_cipher_list => $config{UI_CIPHER},
						SSL_honor_cipher_order => 1,
						SSL_version => $config{UI_SSL_VERSION},
						SSL_key_file => '/etc/csf/ui/server.key',
						SSL_cert_file => '/etc/csf/ui/server.crt',
			) or &shutdown_child(__LINE__,"UI: *Error* cannot open server on port $config{UI_PORT}: ".IO::Socket::SSL->errstr);
		}

		my $looperrors;
		while (1)
		{
			my $client = $server->accept();
			unless ($client)
			{
				$looperrors++;
				if ($looperrors > 1000)
				{
					logfile( "UI: *Error* looping process" );
					last;
				}
	
				if ($config{DEBUG} >= 1)
				{
					logfile( "UI debug: [loop:$looperrors] [$@]" )
				}

				next;
			}

			$SIG{CHLD} = 'IGNORE';

			my $pid = fork;
			if ($pid == 0)
			{
				eval {
					local $SIG{__DIE__} = undef;
					local $SIG{'ALRM'} = sub {die "Connection timeout!\n"};

					alarm(10);
					close $server;

					our %FORM;
					our $myv;
					our $script;
					our $images;
					our $fileinc;

					my $input;
					my $session;
					my $file;
					my $cookie;
					my %header;
					my %fails;
					my $application = "csf";
					my $buffer;
					my $clientcnt;
					my $request;
					my @chars = ('0'..'9','a'..'z','A'..'Z');
					my $valid = "login";
					my $maxheader = 64;
					my $maxbody = 64 * 1024 * 1024;
					my $maxline = 1024 * 1024;
					my $peeraddress = $client->peerhost;

					if ($peeraddress =~ /^::ffff:(\d+\.\d+\.\d+\.\d+)$/) {$peeraddress = $1}
					if ($peeraddress eq "")
					{
						close ($client);
						alarm(0);
						exit;
					}

					# #
					#	Get user peer address
					# #

					$ENV{REMOTE_ADDR} = $peeraddress; ##no critic

					if ($config{UI_BLOCK_PRIVATE_NET} == 1)
					{
						if ($ips{$peeraddress})
						{
							logfile("UI: Login attempt from local IP address denied [$peeraddress]");
							if ($config{UI_ALERT} >= 4)
							{
								my @message;
								my $tip = iplookup($peeraddress);
								foreach my $line (@alert)
								{
									$line =~ s/\[ip\]/$tip/ig;
									$line =~ s/\[alert\]/Login attempt from local IP/ig;
									$line =~ s/\[text\]/Login attempt from local IP address $tip - denied/ig;
									push @message, $line;
								}
								ConfigServer::Sendmail::relay("", "", @message);
							}

							close ($client);
							alarm(0);
							exit;
						}
					}
					else
					{
						# #
						#	[Dangerous] 	User has modified settings to allow external and internal connections.
						# #

						logfile( "UI: [ WARNING ] UI_BLOCK_PRIVATE_NET in /etc/csf/csf.conf set to 0. Accepting both internal and external attempts to UI through IP [$peeraddress]" );
					}

					if ($config{"UI_BAN"})
					{
						open (my $UIBAN,"<","/etc/csf/ui/ui.ban");
						flock ($UIBAN, LOCK_SH);
						my @records = <$UIBAN>;
						chomp @records;
						close ($UIBAN);

						foreach my $record (@records)
						{
							if ($record =~ /^(\#|\s|\r|\n)/) { next }
							my ($rip,undef) = split(/\s/,$record);

							if ($rip eq $peeraddress)
							{
								logfile( "UI: Access attempt from a banned IP address in /etc/csf/ui/ui.ban - denied [$peeraddress]" );
								if ($config{UI_ALERT} >= 4)
								{
									my @message;
									my $tip = iplookup($peeraddress);
									foreach my $line (@alert)
									{
										$line =~ s/\[ip\]/$tip/ig;
										$line =~ s/\[alert\]/Access attempt from banned IP/ig;
										$line =~ s/\[text\]/Access attempt from a banned IP $tip in \/etc\/csf\/ui\/ui\.ban - denied/ig;
										push @message, $line;
									}
									ConfigServer::Sendmail::relay("", "", @message);
								}
								close ($client);
								alarm(0);
								exit;
							}
						}
					}

					if ($config{"UI_ALLOW"}) {
						my $allow = 0;
						sysopen (my $UIALLOW,"/etc/csf/ui/ui.allow", O_RDWR | O_CREAT);
						flock ($UIALLOW, LOCK_SH);
						my @records = <$UIALLOW>;
						chomp @records;
						close ($UIALLOW);
						foreach my $record (@records) {
							if ($record =~ /^(\#|\s|\r|\n)/) { next }
							my ($rip,undef) = split(/\s/,$record);
							if ($rip eq $peeraddress) {
								$allow = 1;
								last;
							}
							my (undef,$cidr) = split(/\//,$rip);
							if ($cidr) {
								my $uicidr = Net::CIDR::Lite->new;
								eval {local $SIG{__DIE__} = undef; $uicidr->add($rip)};
								if ($uicidr->find($peeraddress)) {
									$allow = 1;
									last;
								}
							}
						}
						unless ($allow) {
							logfile("UI: Access attempt from an IP not in /etc/csf/ui/ui.allow - denied [$peeraddress]");
							if ($config{UI_ALERT} >= 4) {
								my @message;
								my $tip = iplookup($peeraddress);
								foreach my $line (@alert) {
									$line =~ s/\[ip\]/$tip/ig;
									$line =~ s/\[alert\]/Login attempt/ig;
									$line =~ s/\[text\]/Access attempt from an IP $tip not in \/etc\/csf\/ui\/ui\.allow - denied/ig;
									push @message, $line;
								}
								ConfigServer::Sendmail::relay("", "", @message);
							}
							close ($client);
							alarm(0);
							exit;
						}
					}

					select $client; ##no critic
					$| = 1;

					$clientcnt = 0;
					while ($request !~ /\n$/) {
						my $char;
						$client->read($char,1);
						$request .= $char;
						$clientcnt++;
						if ($char eq "") {
							if ($config{DEBUG} >= 2) {logfile("UI debug: Child [request] finished")}
							close ($client);
							alarm(0);
							exit;
						}
						if ($clientcnt > $maxline) {
							&ui_413;
							close ($client);
							alarm(0);
							exit;
						}
					}
					$request =~ s/\r\n$//;
					if ($request =~ /^(GET|POST)\s(\S+)\sHTTP/) {
						($file,undef) = split(/\?/,$2);
						if ($file =~ /^\/(\w+)(\/.*)/) {
							$session = $1;
							$file = $2;
						}
					}
					else
					{
						close ($client);
						alarm(0);
						exit;
					}

					my $linecnt;
					while (1) {
						my $line;
						$clientcnt = 0;
						while ($line !~ /\n$/)
						{
							my $char;
							$client->read($char,1);
							$line .= $char;
							$clientcnt++;

							if ($char eq "")
							{
								if ($config{DEBUG} >= 2) {logfile("UI debug: Child [header] finished")}
								close ($client);
								alarm(0);
								exit;
							}

							if ($clientcnt > $maxline)
							{
								&ui_413;
								close ($client);
								alarm(0);
								exit;
							}
						}

						if ($line =~ /^\r\n$/) {last}
						$line =~ s/\r\n$//;
						my ($field,$value) = split(/\:\s/,$line);
						$field = lc($field);
						$header{$field} = $value;

						if ($config{DEBUG} >= 2)
						{
							logfile("UI debug: header [$field] [$value]")
						}
	
						$linecnt++;
						if ($linecnt > $maxheader)
						{
							&ui_413;
							close ($client);
							alarm(0);
							exit;
						}
					}

					if ($header{'content-length'} > 0)
					{
						if ($header{'content-length'} > $maxbody) {
							&ui_413;
							close ($client);
							alarm(0);
							exit;
						} else {
							if ($header{'content-type'} =~ /multipart\/form-data/i) {
								$client->read($fileinc,$header{'content-length'});
							} else {
								$client->read($buffer,$header{'content-length'});
							}
						}
					}

					if ($request =~ /^GET\s(\S+)\sHTTP/) {if ($1 =~ /\?([^\?]*)$/) {$buffer = $1}}
					if ($config{DEBUG} >= 2) {logfile("UI debug: request [$request] buffer [$buffer]")}
					my @pairs = split(/&/,$buffer);
					foreach my $pair ( @pairs )
					{
						my ($name, $value) = split(/=/, $pair);
						$value =~ tr/+/ /;
						$value =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
						$FORM{$name} = html_escape($value);
					}
					if ($header{cookie} =~ /csfsession=(\w+)/) {$cookie = $1}

					if (($session ne "" and $cookie ne "") or defined $FORM{csflogin}) {
						sysopen (my $SESSION,"/var/lib/csf/ui/ui.session", O_RDWR | O_CREAT) or &shutdown_child(__LINE__,"UI: unable to open csf.session: $!");
						flock ($SESSION, LOCK_EX);
						my @records = <$SESSION>;
						chomp @records;
						seek ($SESSION, 0, 0);
						truncate ($SESSION, 0);

						my $md5current = Digest::MD5->new;
						$md5current->add($header{'user-agent'});
						my $md5sum = $md5current->b64digest;
						foreach my $record (@records) {
							my ($rtype,$rstart,$rtime,$rsession,$rcookie,$rip,$rhead,$rapp) = split(/\|/,$record,8);
							if ($rtype eq "login" and $rip eq $peeraddress and $rsession eq $session) {
								if ((time - $rtime) > $config{UI_TIMEOUT}) {
									$valid = "login";
									$record = "";
									($rstart,$rtime,$rsession,$rcookie,$rip,$rhead) = "";
									logfile("UI: *Invalid session* $peeraddress [timeout]");
								}
								elsif ($rcookie eq $cookie) {
									if ($rhead eq $md5sum) {
										if ($FORM{csfaction} eq "csflogout") {
											$valid = "login";
											$record = "";
											logfile("UI: Successful logout from $peeraddress");
										} else {
											$valid = "session";
											$application = $rapp;
											$rtime = time;
											$record = "$rtype|$rstart|$rtime|$rsession|$rcookie|$rip|$rhead|$rapp";
										}
									} else {
										$valid = "fail";
										$record = "";
										logfile("UI: *Invalid session* $peeraddress [session-header]");
									}
								} else {
									$valid = "fail";
									$record = "";
									logfile("UI: *Invalid session* $peeraddress [session-cookie]");
								}
							} else {
								if ($rtype eq "login") {
									if ((time - $rtime) > $config{UI_TIMEOUT}) {
										$record = "";
										($rstart,$rtime,$rsession,$rcookie,$rip,$rhead) = "";
									}
								}
								elsif ($rtype eq "fail") {
									if ((time - $rstart) > 86400) {
										$record = "";
									} else {
										$fails{$rip}++;
									}
								}
							}
							if ($record ne "") {print $SESSION "$record\n"}
						}
						close ($SESSION);
					} else {
						$valid = "login";
					}
					if (defined $FORM{csflogin} and $valid ne "fail") {
						if ($FORM{csflogin} eq $config{UI_USER} and $FORM{csfpassword} eq $config{UI_PASS}) {
							$valid = "yes";
						} else {
							$valid = "fail";
						}
					}

					if ($valid eq "fail") {
						$fails{$peeraddress}++;
						if ($fails{$peeraddress} > $config{UI_RETRY}) {
							if ($config{UI_BAN}) {
								sysopen (my $SESSIONBAN,"/etc/csf/ui/ui.ban", O_WRONLY | O_APPEND | O_CREAT) or &shutdown_child(__LINE__,"UI: unable to open csf.session: $!");
								flock ($SESSIONBAN, LOCK_EX);
								print $SESSIONBAN "$peeraddress - Banned for too many login failures ".localtime()."\n";
								close ($SESSIONBAN);
								logfile("UI: *Invalid login* attempts from $peeraddress [$fails{$peeraddress}/$config{UI_RETRY}] - Banned in /etc/csf/ui/ui.ban");
							} else {
								logfile("UI: *Invalid login* attempts from $peeraddress [$fails{$peeraddress}/$config{UI_RETRY}] - Not Banned");
							}
							sysopen (my $SESSION,"/var/lib/csf/ui/ui.session", O_RDWR | O_CREAT) or &shutdown_child(__LINE__,"UI: unable to open csf.session: $!");
							flock ($SESSION, LOCK_EX);
							my @records = <$SESSION>;
							chomp @records;
							seek ($SESSION, 0, 0);
							truncate ($SESSION, 0);
							foreach my $record (@records) {
								my ($rtype,$rstart,$rtime,$rsession,$rcookie,$rip,$rhead,$rapp) = split(/\|/,$record,8);
								if ($rip eq $peeraddress) { next }
								print $SESSION "$record\n"
							}
							close ($SESSION);
							if ($config{UI_BLOCK}) {
								my $perm = 0;
								if ($config{UI_BLOCK} == 1) {$perm = 1}
								my $tip = iplookup($peeraddress);
								&ipblock("1","UI: Invalid login attempts from $tip",$peeraddress,"","in",$config{UI_BLOCK},0,"UI: *Invalid login* attempts from $peeraddress [$fails{$peeraddress}/$config{UI_RETRY}] - Banned","UI_RETRY");
							}
							if ($config{UI_ALERT} >= 1) {
								my @message;
								my $tip = iplookup($peeraddress);
								my $text;
								if ($config{UI_BAN}) {$text .= "Banned in ui.ban"}
								if ($config{UI_BLOCK}) {
									if ($text ne "") {$text .= ", "}
									$text .= "Blocked in csf";
								}
								foreach my $line (@alert) {
									$line =~ s/\[ip\]/$tip/ig;
									$line =~ s/\[alert\]/Login failure \[$fails{$peeraddress}\/$config{UI_RETRY}]/ig;
									$line =~ s/\[text\]/Login failure from IP address $tip \[$fails{$peeraddress}\/$config{UI_RETRY}] - $text/ig;
									push @message, $line;
								}
								ConfigServer::Sendmail::relay("", "", @message);
							}
							&ui_403;
							close ($client);
							alarm(0);
							exit;
						}
						else
						{
							my $time = time;
							sysopen (my $SESSION,"/var/lib/csf/ui/ui.session", O_WRONLY | O_APPEND | O_CREAT) or &shutdown_child(__LINE__,"UI: unable to open csf.session: $!");
							flock ($SESSION, LOCK_EX);
							print $SESSION "fail|$time||||$peeraddress||\n";
							close ($SESSION);
							$valid = "login-retry";
							logfile("UI: *Invalid login* attempt from $peeraddress [$fails{$peeraddress}/$config{UI_RETRY}]");
							if ($config{UI_ALERT} >= 2)
							{
								my @message;
								my $tip = iplookup($peeraddress);
								foreach my $line (@alert)
								{
									$line =~ s/\[ip\]/$tip/ig;
									$line =~ s/\[alert\]/Login failure \[$fails{$peeraddress}\/$config{UI_RETRY}]/ig;
									$line =~ s/\[text\]/Login failure from IP address $tip \[$fails{$peeraddress}\/$config{UI_RETRY}] - denied/ig;
									push @message, $line;
								}
								ConfigServer::Sendmail::relay("", "", @message);
							}
						}
					}

					if ($valid eq "yes")
					{
						srand;
						$session = join '', map {$chars[rand(@chars)]} (1..(15 + int(rand(15))));
						$cookie = join '', map {$chars[rand(@chars)]} (1..(15 + int(rand(15))));

						my $md5current = Digest::MD5->new;
						$md5current->add($header{'user-agent'});
						my $md5sum = $md5current->b64digest;
						my $time = time;
						sysopen (my $SESSION,"/var/lib/csf/ui/ui.session", O_RDWR | O_CREAT) or &shutdown_child(__LINE__,"UI: unable to open csf.session: $!");
						flock ($SESSION, LOCK_EX);
						my @records = <$SESSION>;
						chomp @records;
						seek ($SESSION, 0, 0);
						truncate ($SESSION, 0);
						foreach my $record (@records) {
							my ($rtype,$rstart,$rtime,$rsession,$rcookie,$rip,$rhead) = split(/\|/,$record,8);
							if ($rtype eq "fail" and $rip eq $peeraddress) { next }
							print $SESSION "$record\n"
						}
						print $SESSION "login|$time|$time|$session|$cookie|$peeraddress|$md5sum|$application\n";
						close ($SESSION);

						print "HTTP/1.0 301 Moved Permanently\r\n";
						print "Location: /$session/\r\n";
						print "Set-Cookie: csfsession=$cookie; secure\r\n";
						print "\r\n";

						logfile("UI: Successful login from $peeraddress");
						if ($config{UI_ALERT} >= 3) {
							my @message;
							my $tip = iplookup($peeraddress);
							foreach my $line (@alert) {
								$line =~ s/\[ip\]/$tip/ig;
								$line =~ s/\[alert\]/Login success/ig;
								$line =~ s/\[text\]/Login success from IP address $tip/ig;
								push @message, $line;
							}
							ConfigServer::Sendmail::relay("", "", @message);
						}
					}

					if ( $valid eq "login" || $valid eq "login-retry" )
					{
						print "HTTP/1.0 200 OK\r\n";
						print "Content-type: text/html\r\n";
						print "\r\n";
						print "<!DOCTYPE html>\n";
						print "<html>\n";
						print "<head>";
						print "<meta charset=\"UTF-8\">\n";
						if ($config{UI_CSP_ENABLED} == 1 && $csp_rule ne '' )
						{
							print "<meta http-equiv=\"Content-Security-Policy\" content=\"$csp_rule\">\n";
						}
						print '<script>
						(function()
						{
							var theme = localStorage.getItem("theme") || "light";
							document.documentElement.setAttribute("data-theme", theme);
						})();
						</script>' . "\n";
						print "<title>ConfigServer Security & Firewall</title>\n";
						print <<EOF;

<link rel='icon' type='image/svg+xml' href='$svg_logo'>

<style>

\@-webkit-keyframes fade-in
{
    from { opacity: 0.6; }
    to { opacity: 1; }
}

\@-moz-keyframes fade-in
{
    from { opacity: 0.6; }
    to { opacity: 1; }
}

\@keyframes fade-in
{
    from { opacity: 0.6; }
    to { opacity: 1; }
}

.fade
{
	animation-name:             fade-in, scale-in;
	animation-duration:         1s, 0.5s;
	animation-timing-function:  ease-in, linear;
	animation-direction:        alternate, alternate;
	animation-iteration-count:  infinite, 1;
	transition: 				all 0.2s;
	transform: 					scale(1);
}

\@keyframes scale-in
{
    from {
        transform: scale(1, 1);
    }
    to {
        transform: scale(1.1, 1.1);
    }
}

/*
	Animations › Pulsate
*/

\@-webkit-keyframes pulsate
{
    0% { transform: scale(0.8); opacity: 0.5; }
    50% { transform: scale(1); opacity: 1; }
    100% { transform: scale(0.8); opacity: 0.5; }
}

\@keyframes pulsate
{
    0% { transform: scale(0.8); opacity: 0.5; }
    50% { transform: scale(1); opacity: 1; }
    100% { transform: scale(0.8); opacity: 0.5; }
}

.pulsate
{
    -webkit-animation: pulsate 3s ease-out;
    -webkit-animation-iteration-count: infinite; 
    animation: pulsate 3s ease-out;
    animation-iteration-count: infinite;
    opacity: 0.5;
}

:root,
[data-theme="light"]
{
    --main-bg: 						#dedede;
	--main-text:					#242424;
	--login-container-bg: 			#dedede;
	--login-container-border:		#e3e3e31a;
	--login-footer-text-n: 			#868686;
	--login-footer-text-l:			#dd761c;
	--login-footer-text-h:			#ffa354;

	--input-normal-text: 			#8D8D8D;
	--input-normal-bg: 				#FFFFFF;
	--input-normal-border: 			#f7f7f7;
	--input-focus-line: 			#1F85DE;
	--input-focus-bg: 				#FFFFFF;
	--input-focus-border: 			#FFFFFF;
	--input-focus-text: 			#353535;
	--input-hover-line: 			#F82561;
	--input-placeholder-text-n:		#707070;
	--input-placeholder-text-f:		#000;
	--theme-icon-svg:				#000;
	--theme-icon-btn-bg-n:			#CCC;
	--theme-icon-btn-bg-h:			#2168C5;
	--theme-icon-btn-icon-n:		#fff;
	--theme-icon-btn-icon-h:		#FFFFFF;
	--login-failed-bg: 				#DD6969;
	--login-failed-border: 			#e3e3e31a;
	--login-failed-text: 			#FFF;
	--login-failed-icon-warning: 	#FFF;
	--login-failed-text-count: 		#FFF;
	--login-btn-bg: 				#ca2956;
	--login-btn-text: 				#FFFFFF;
	--login-btn-border: 			#e3e3e31a;

	.global-container-main
	{
		height:						100%;
		background:					url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 1123 258'><path d='M327 115c95-9 218 57 337 39C778 136 803 90 912 41c51-19 141-38 195-38C1122 2 1137 2 1152 2c253-1 326 236 0 256l-1125 0L-31 257l-36-74c-34-60 43 23 104 24 116 0 198-83 290-92' fill='%23e4e4e4'/></svg>") no-repeat bottom center, linear-gradient(to bottom, #FFF 0%, #FFF 100%);
		background-size: 			cover;
		background-attachment: 		fixed;
	}
}

[data-theme="dark"]
{
	--main-bg: 						#1c1c1c;
	--main-text:					#FFFFFF;
	--login-container-bg: 			#282828;
	--login-container-border:		#e3e3e31a;
	--login-footer-text-n: 			#868686;
	--login-footer-text-l:			#dd761c;
	--login-footer-text-h:			#ffa354;

	--input-normal-text: 			#C4C4C4;
	--input-normal-bg: 				#393939;
	--input-normal-border: 			#e3e3e31a;
	--input-focus-line: 			#1F85DE;
	--input-focus-bg: 				#393939;
	--input-focus-border: 			#e3e3e31a;
	--input-focus-text: 			#F5F5F5;
	--input-hover-line: 			#F82561;
	--input-placeholder-text-n:		#707070;
	--input-placeholder-text-f:		#919191;
	--theme-icon-svg:				#FFF;
	--theme-icon-btn-bg-n:			#383838;
	--theme-icon-btn-bg-h:			#F11C63;
	--theme-icon-btn-icon-n:		#707070;
	--theme-icon-btn-icon-h:		#FFFFFF;
	--login-failed-bg: 				#991b3f;
	--login-failed-border: 			#e3e3e31a;
	--login-failed-text: 			#FFF;
	--login-failed-icon-warning: 	#FFF;
	--login-failed-text-count: 		#FFF;
	--login-btn-bg: 				#ca2956;
	--login-btn-text: 				#FFFFFF;
	--login-btn-border: 			#e3e3e31a;

	.global-container-main
	{
		height: 					100%;
		background: 				url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 1123 258'><path d='M327 115c95-9 218 57 337 39C778 136 803 90 912 41c51-19 141-38 195-38C1122 2 1137 2 1152 2c253-1 326 236 0 256l-1125 0L-31 257l-36-74c-34-60 43 23 104 24 116 0 198-83 290-92' fill='%230f0f0f'/></svg>") no-repeat bottom center, linear-gradient(to bottom, #151515 0%, #2f2f2f 100%);
		background-size: 			cover;
		background-attachment: 		fixed;
	}
}

html, body
{
	height: 						100%;
	margin:							0px;
}

body
{
	background-color: 				var( --main-bg );
	color:							var( --main-text );
	font-family:					"Ubuntu", "Corbel", "Calibri", "Segoe UI", "Helvetica Neue", Arial, sans-serif;
}

.login-container
{
	background-color: 				var( --login-container-bg );
	border:							1px solid var( --login-container-border );
	border-radius:					4px;
	padding:						15px;
	min-width: 260px;
}

.login-footer
{
	font-size: 						clamp(10px, 1.5vw, 14px);
	padding-top: 					20px;
	color: 							var( --login-footer-text-n );
}

.login-footer a
{
	color: 							var( --login-footer-text-l );
	text-decoration: 				none;
}

.login-footer a:hover
{
	color: 							var( --login-footer-text-h );
	transition: 					all 0.3s;
}

.btn-login
{
	background-color: 				var( --login-btn-bg );
	color: 							var( --login-btn-text );
	border: 						1px solid var( --login-btn-border );
	border-radius: 					4px;
	padding-left: 					4px;
	padding-right: 					4px;
	padding-top: 					7px;
	padding-bottom: 				7px;
	min-width: 						100px;
	margin-top: 					15px;
	cursor: 						pointer;
	font-size: 						10pt;
	font-weight: 					400;
}

.btn-login:hover
{
	transition: 					all 0.3s;
	border: 						1px solid var( --login-btn-bg );
	background:						var( --login-btn-bg );
	filter: 						brightness( 120% );
}

input:not(.btn-login)
{
    width:                          clamp(200px, 35vw, 400px);
    max-width:                      400px;
    min-width:                      200px;
    padding:                        4px 10px;
    color:                          var( --input-normal-text );
    font-size:                      16pt;
    font-family:                    "Ubuntu", "Corbel", "Calibri", "Segoe UI", "Helvetica Neue", Arial, sans-serif;
    font-weight:                    300;
    cursor:                         pointer;
    text-align:                     center;
    background-image:               linear-gradient( var( --input-hover-line ), var( --input-hover-line ) ), none;
    background-repeat:              no-repeat;
    background-position:            50% 100%;
    background-size:                0% 2px;
    background-color:               var( --input-normal-bg );
    border:                         1px solid var( --input-normal-border );
    transition:
        background-size 0.3s ease,
        background-position 0.3s ease,
        color 0.3s ease,
        border-color 0.3s ease;
}

input:hover
{
    background-size:                100% 2px;
    background-position:            50% 100%;
    background-color:               var( --input-hover-bg, var( --input-normal-bg ) );
}

input:focus
{
    color:                          var( --input-focus-text );
    background-color:               var( --input-focus-bg );
    background-image:               linear-gradient(var( --input-focus-line ), var( --input-focus-line ) ), none;
    background-size:                100% 2px;
    background-position:            50% 100%;
    border-color:                   var( --input-focus-border );
    outline:                        none;
}

input::placeholder
{
    font-weight:                    lighter;
    opacity:                        0.8;
    color:                          var( --input-placeholder-text-n );
}

input:focus::placeholder
{
    opacity:                        0.2;
    color:                          var( --input-placeholder-text-f );
    transition:                     0.7s;
}

img.login-logo, svg.login-logo
{
	width: 							100px;
	animation-name:             	fade-in, scale-in;
	animation-duration:         	1s, 0.5s;
	animation-timing-function:  	ease-in, linear;
	animation-direction:        	alternate, alternate;
	animation-iteration-count:  	infinite, 1;
	transition: 					all 0.3s;
	opacity: 						0.5;
	transform: 						scale( 1.1 );
}

img.login-logo:not(:hover), svg.login-logo:not(:hover)
{
	transition: 					all 0.3s;
	opacity: 						1;
	transform: 						scale( 1 );
}

img.login-logo:hover, svg.login-logo:hover
{
	animation-name:             	fade-in, scale-in;
	animation-duration:         	1s, 0.5s;
	animation-timing-function:  	ease-in, linear;
	animation-direction:        	alternate, alternate;
	animation-iteration-count:  	infinite, 1;
	transition: 					all 0.3s;
	opacity: 						0.5;
	transform: 						scale( 1.1 );
}

.login-form
{
	display: 						flex;
	flex-direction: 				column;
	align-items: 					center;
}

.login-container-logo
{
	margin-top: 					-75px;
	margin-bottom:					20px;
}

.login-container-main
{
	position: 						fixed;
	top: 							50%;
	left: 							50%;
	transform: 						translate( -50%, -50% );
}

.login-notify-failure
{
	background-color: 				var( --login-failed-bg );
	border: 						0px solid var( --login-failed-border );
	border-radius: 					4px;
	display: 						flex;
	justify-content: 				center;
	align-items: 					center;
	width: 							clamp( 150px, 35vw, 350px );
	margin: 						0 auto;
	color: 							var( --login-failed-text );
	padding-top: 					clamp( 5px, 40vh, 8px );
	padding-bottom: 				clamp( 5px, 40vh, 8px );
	padding-left: 					clamp( 0.1em, 0.5vw, 1.5em );
	padding-right: 					clamp( 0.1em, 0.5vw, 1.5em );
	position: 						relative;
	top: 							20px;
}

.login-notify-failure-icon
{
	text-align: 					left;
	position: 						absolute;
	left: 							5px;
	width: 							18px;
	padding: 						5px;
	fill: 							var( --login-failed-icon-warning );
	height: 						18px;
	animation-name:             	fade-in, scale-in;
	animation-duration:         	1s, 0.5s;
	animation-timing-function:  	ease-in, linear;
	animation-direction:        	alternate, alternate;
	animation-iteration-count:  	infinite, 1;
	transition: 					all 0.3s;
	opacity: 						0.5;
}

.login-notify-failure-text
{
	font-size: 						0.9rem;
	font-weight: 					300;
}

.login-notify-failure-count
{
	color: 							var( --login-failed-text-count );
	right: 							10px;
	font-size: 						0.8rem;
	opacity: 						0.8;
	position: 						absolute;
}

#theme-toggle
{
    position: 						fixed;
    top: 							16px;
    right: 							20px;
	width: 							40px;
	height: 						40px;
    border: 						none;
    border-radius: 					50%;
    background-color: 				var( --theme-icon-btn-bg-n );
    cursor: 						pointer;
    display:						flex;
    align-items: 					center;
    justify-content: 				center;
    z-index: 						1000;
    transition: 					background-color 0.3s;
}

#theme-toggle:hover
{
    background-color: 				var( --theme-icon-btn-bg-h );
}

#theme-toggle svg
{
	width: 							20px;
	height: 						20px;
    pointer-events: 				none;
    transition: 					transform 0.3s;
	fill: 							var( --theme-icon-btn-icon-n );
}

#theme-toggle:hover svg
{
	width: 							20px;
	height: 						20px;
    pointer-events: 				none;
    transition: 					transform 0.3s;
	fill: 							var( --theme-icon-btn-icon-h );
}

</style>
EOF
						print "</head>\n";
						print "<body onload='document.getElementById(\"user\").focus()'>\n";

						print '<button id="theme-toggle">
							<svg id="theme-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="48" height="48" fill="currentColor">
								<!-- placeholder icon -->
							</svg>
						</button>';

						print '<script>
						(function()
						{
							const sunPath 	= `<path d="M361.5 1.2c5 2.1 8.6 6.6 9.6 11.9L391 121l107.9 19.8c5.3 1 9.8 4.6 11.9 9.6s1.5 10.7-1.6 15.2L446.9 256l62.3 90.3c3.1 4.5 3.7 10.2 1.6 15.2s-6.6 8.6-11.9 9.6L391 391 371.1 498.9c-1 5.3-4.6 9.8-9.6 11.9s-10.7 1.5-15.2-1.6L256 446.9l-90.3 62.3c-4.5 3.1-10.2 3.7-15.2 1.6s-8.6-6.6-9.6-11.9L121 391 13.1 371.1c-5.3-1-9.8-4.6-11.9-9.6s-1.5-10.7 1.6-15.2L65.1 256 2.8 165.7c-3.1-4.5-3.7-10.2-1.6-15.2s6.6-8.6 11.9-9.6L121 121 140.9 13.1c1-5.3 4.6-9.8 9.6-11.9s10.7-1.5 15.2 1.6L256 65.1 346.3 2.8c4.5-3.1 10.2-3.7 15.2-1.6zM160 256a96 96 0 1 1 192 0 96 96 0 1 1 -192 0zm224 0a128 128 0 1 0 -256 0 128 128 0 1 0 256 0z"></path>`;
							const moonPath 	= `<path d="M223.5 32C100 32 0 132.3 0 256S100 480 223.5 480c60.6 0 115.5-24.2 155.8-63.4c5-4.9 6.3-12.5 3.1-18.7s-10.1-9.7-17-8.5c-9.8 1.7-19.8 2.6-30.1 2.6c-96.9 0-175.5-78.8-175.5-176c0-65.8 36-123.1 89.3-153.3c6.1-3.5 9.2-10.5 7.7-17.3s-7.3-11.9-14.3-12.5c-6.3-.5-12.6-.8-19-.8z"></path><path class="fa-secondary" d=""></path>`;
							const button 	= document.getElementById( "theme-toggle" );
							const icon 		= document.getElementById( "theme-icon" );

							function setTheme( theme )
							{
								document.documentElement.setAttribute( "data-theme", theme );
								localStorage.setItem( "theme", theme );
								icon.innerHTML = theme === "dark" ? sunPath : moonPath;
							}

							let currentTheme = localStorage.getItem( "theme" ) || "light";
							setTheme( currentTheme );

							button.addEventListener( "click", () =>
							{
								const newTheme = document.documentElement.getAttribute( "data-theme" ) === "dark" ? "light" : "dark";
								setTheme( newTheme );
							});
						})();
						</script>';

						print "<div class='global-container-main'>";

						# #
						#	Login failed
						# #

						if ($valid eq "fail" || $valid eq "login-retry")
						{
							my $retryAttempt = $config{UI_RETRY_SHOW_REMAINING} == 1 ? "$fails{$peeraddress} / $config{UI_RETRY}" : "";

							print "<div class='login-notify-failure'>\n";
							print "    <span class='login-notify-failure-icon'><svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 576 512'><path d='M569.517 440.013C587.975 472.007 564.806 512 527.94 512H48.054c-36.937 0-59.999-40.055-41.577-71.987L246.423 23.985c18.467-32.009 64.72-31.951 83.154 0l239.94 416.028zM288 354c-25.405 0-46 20.595-46 46s20.595 46 46 46 46-20.595 46-46-20.595-46-46-46zm-43.673-165.346l7.418 136c.347 6.364 5.609 11.346 11.982 11.346h48.546c6.373 0 11.635-4.982 11.982-11.346l7.418-136c.375-6.874-5.098-12.654-11.982-12.654h-63.383c-6.884 0-12.356 5.78-11.981 12.654z'/></svg></span>\n";
							print "    <span class='login-notify-failure-text'>Authentication failed</span>\n";
							print "    <span class='login-notify-failure-count'>$retryAttempt</span>\n";
							print "</div>\n";
						}

						print "<div class='login-container-main'>";
						print "<form action='/' method='post'><div class='login-form' align='center'>\n";

print <<"SVG_EOF";
<div class='login-container-logo'>
	<a href='$app_github_url' target='_blank'>
		$app_svg_logo_raw
	</a>
</div>
SVG_EOF
						print "<table align='center' cellspacing='0' cellpadding='4' class='login-container'>\n";
						print "<tr><td><input placeholder='Username' id='user' name='csflogin' type='text' class='input' size='25'></td></tr>\n";
						print "<tr><td><input placeholder='Password' name='csfpassword' type='password' class='input' size='25'></td></tr>\n";
						print "<tr><td colspan='2' align='center'><input type='submit' value='Enter' class='btn-login'></td></tr>\n";
						print "<", "/table>";
						print "<div class='login-footer'><a href='$app_github_url'>ConfigServer Firewall</a> v$version</div>";
						print "</div></form>\n";
						print "</div>";
						print "</div>";
						print "\n</body>\n</html>\n";
					}

					if ($valid eq "session")
					{
						if (defined $FORM{csfapp} and ($FORM{csfapp} ne $application)) {
							my $newapp = $application;
							if ($FORM{csfapp} eq "csf") {$newapp = "csf"}
							elsif ($FORM{csfapp} eq "cxs" and $config{UI_CXS}) {$newapp = "cxs"}
							elsif ($FORM{csfapp} eq "cse" and $config{UI_CSE}) {$newapp = "cse"}
							if ($newapp ne $application) {
								sysopen (my $SESSION,"/var/lib/csf/ui/ui.session", O_RDWR | O_CREAT) or &shutdown_child(__LINE__,"UI: unable to open csf.session: $!");
								flock ($SESSION, LOCK_EX);
								my @records = <$SESSION>;
								chomp @records;
								seek ($SESSION, 0, 0);
								truncate ($SESSION, 0);
								foreach my $record (@records) {
									my ($rtype,$rstart,$rtime,$rsession,$rcookie,$rip,$rhead,$rapp) = split(/\|/,$record,8);
									if ($rip eq $peeraddress and $rsession eq $session) {
										$record = "$rtype|$rstart|$rtime|$rsession|$rcookie|$rip|$rhead|$newapp";
										$application = $newapp;
									}
									print $SESSION "$record\n"
								}
								close ($SESSION);
							}
						}
						if ($file eq "/") {
							print "HTTP/1.0 200 OK\r\n";
							if ($application eq "csf")
							{
								open ( my $IN, "<", "/etc/csf/version.txt" ) or die $!;
								flock ( $IN, LOCK_SH );
								$myv = <$IN>;
								close ( $IN );
								chomp $myv;
				
								$script 			= "/$session/";
								$images 			= "/$session/images";
								$config{THIS_UI} 	= 1;

								my $csfjs = qq{
									<script>
										var csfCodename = "$codename";
									</script>
									<script src="$images/csf.min.js?v=$myv"></script>
								};

								my $bootstrapcss 	= "<link rel='stylesheet' href='$images/bootstrap/css/bootstrap.min.css?v=$myv'>";
								my $csfnt 			= "<script src='$images/csfont.min.js?v=$myv'></script>";
								my $jqueryjs 		= "<script src='$images/jquery.min.js?v=$myv'></script>";
								my $bootstrapjs 	= "<script src='$images/bootstrap/js/bootstrap.min.js?v=$myv'></script>";
								my $htmltag 		= "data-post='$FORM{action}'";
								my @header;
								my @footer;

								if (-e "/etc/csf/csf.header")
								{
									open (my $HEADER, "<", "/etc/csf/csf.header");
									flock ($HEADER, LOCK_SH);
									@header = <$HEADER>;
									close ($HEADER);
								}

								if (-e "/etc/csf/csf.footer")
								{
									open (my $FOOTER, "<", "/etc/csf/csf.footer");
									flock ($FOOTER, LOCK_SH);
									@footer = <$FOOTER>;
									close ($FOOTER);
								}

								unless ($config{STYLE_CUSTOM})
								{
									undef @header;
									undef @footer;
									$htmltag = "";
								}

								print "Content-type: text/html\r\n";
								print "\r\n";
								unless ($FORM{action} eq "tailcmd" or $FORM{action} =~ /^cf/ or $FORM{action} eq "logtailcmd" or $FORM{action} eq "loggrepcmd") {
									print <<EOF;
<!doctype html>
<html lang='en' $htmltag>
<head>
	<script>
		(function()
		{
			var theme = localStorage.getItem('theme') || 'light';
			document.documentElement.setAttribute('data-theme', theme);
		})();
	</script>

	$bootstrapcss

	<link rel="preload" href="$images/configserver.css" as="style" onload="this.onload=null;this.rel='stylesheet'">
	<noscript><link rel="stylesheet" href="$images/configserver.css"></noscript>
	<link rel="icon" type="image/x-icon" href="$images/csf.png">
	<link href='https://fonts.googleapis.com/css?family=Raleway:400,700' rel='stylesheet' type='text/css'>
	<title>ConfigServer Security &amp; Firewall</title>
	<meta charset='utf-8'>
	<meta name='viewport' content='width=device-width, initial-scale=1'>

	$csfjs
	$jqueryjs
	$csfnt
	$bootstrapjs

<style>
.mobilecontainer {
display:none;
}
.normalcontainer {
display:block;
}
EOF
									if ($config{STYLE_MOBILE}) {
	print <<EOF;
\@media (max-width: 480px) {
.mobilecontainer {
	display:block;
}
.normalcontainer {
	display:none;
}
}
EOF
									}
									print "</style>\n";
									print @header;
									print <<EOF;
</head>
<body>
<div id="loader"></div>
<a id='toplink' class='toplink' title='Go to bottom'><span class='glyphicon glyphicon-hand-down'></span></a>
<div class='container-fluid'>


<div class="section-header">
    <div class="header-left">
        <a href="/$session/">
            <img class="logo" src="$images/csf.png" alt="ConfigServer Firewall">
        </a>
        <div class="app-info">
            <span class="app-name">ConfigServer Firewall</span>
            <span class="app-version"><code>v$version</code></span>
        </div>
    </div>

    <div class="header-right">
EOF
								}

								unless ( $FORM{action} eq "tailcmd" or $FORM{action} =~ /^cf/ or $FORM{action} eq "logtailcmd" or $FORM{action} eq "loggrepcmd")
								{
									print "<div class='pull-right' style='margin:8px'>\n";
									if ( $config{UI_CXS} or $config{UI_CSE} )
									{
										print "<form action='$script' method='post'><select name='csfapp'><option>csf</option>";

										if ( $config{UI_CXS} )
										{
											print "<option>cxs</option>"
										}

										if ( $config{UI_CSE} )
										{
											print "<option>cse</option>"
										}
									
										print "<", "/select> <input class='btn btn-default' type='submit' value='Switch'></form>\n";
									}

									print "</div>\n";
									print <<EOF;
									
        <button class="header-btn"><a class='btn-settings-base btn-logout' href='/$session/?csfaction=csflogout'>Logout</a></button>
    </div>
</div>
EOF
								}

								ConfigServer::DisplayUI::main(\%FORM, $script, 0, $images, $myv, $config{THIS_UI});
								unless ($FORM{action} eq "tailcmd" or $FORM{action} =~ /^cf/ or $FORM{action} eq "logtailcmd" or $FORM{action} eq "loggrepcmd") {
									print <<EOF;
<a class='botlink' id='botlink' title='Go to top'><span class='glyphicon glyphicon-hand-up'></span></a>
<script>
function getCookie(cname)
{
	var name = cname + "=";
	var ca = document.cookie.split(';');
	for(var i = 0; i <ca.length; i++)
	{
		var c = ca[i];
		while (c.charAt(0)==' ')
		{
			c = c.substring(1);
		}
		if (c.indexOf(name) == 0)
		{
			return c.substring(name.length,c.length);
		}
	}
	return "";
}

\$("#loader").hide();
\$.fn.scrollBottom = function()
{
  return \$(document).height() - this.scrollTop() - this.height(); 
};

\$('#botlink').on("click",function()
{
	\$('html,body').animate({ scrollTop: 0 }, 'slow', function () {});
});

\$('#toplink').on("click",function()
{
	var window_height = \$(window).height();
	var document_height = \$(document).height();
	\$('html,body').animate({ scrollTop: window_height + document_height }, 'slow', function () {});
});

\$(document).ready(function()
{
	\$('[data-tooltip="tooltip"]').tooltip();
	\$(window).scroll(function ()
	{
		if (\$(this).scrollTop() > 500)
		{
			\$('#botlink').fadeIn();
		} else {
			\$('#botlink').fadeOut();
		}

		if (\$(this).scrollBottom() > 500)
		{
			\$('#toplink').fadeIn();
		} else {
			\$('#toplink').fadeOut();
		}
	});
EOF
									if ($config{STYLE_MOBILE})
									{
									print <<EOF;
	var csfview = getCookie('csfview');
	if (csfview == 'mobile')
	{
		\$(".mobilecontainer").css('display','block');
		\$(".normalcontainer").css('display','none');
		\$("#csfreturn").addClass('btn-primary btn-lg btn-block').removeClass('btn-default');
	}
	else if (csfview == 'desktop')
	{
		\$(".mobilecontainer").css('display','none');
		\$(".normalcontainer").css('display','block');
		\$("#csfreturn").removeClass('btn-primary btn-lg btn-block').addClass('btn-default');
	}
EOF
}
									print "});\n";
									if ($config{STYLE_MOBILE}) {
										print <<EOF;
\$("#NormalView").click(function()
{
	document.cookie = "csfview=desktop; path=/";
	\$(".mobilecontainer").css('display','none');
	\$(".normalcontainer").css('display','block');
});
\$("#MobileView").click(function()
{
	document.cookie = "csfview=mobile; path=/";
	\$(".mobilecontainer").css('display','block');
	\$(".normalcontainer").css('display','none');
});
EOF
}
									print "</script>\n";
									print @footer;
									print "</body>\n";
									print "</html>\n";
								}
							}
							elsif ($application eq "cxs" and $config{UI_CXS})
							{
								my @data = &syscommand(__LINE__,"/usr/sbin/cxs","--version");
								chomp @data;
						
								if ($data[0] =~ /v(.*)$/)
								{
									$myv = $1
								}

								my %ajaxsubs =
								(
									"cc_body" => 1,
									"cc_dbody" => 1,
									"cc_restore" => 1,
									"cc_report" => 1,
									"cc_showreports" => 1,
									"cc_ignore" => 1,
									"cc_blockip" => 1,
									"cc_delete" => 1,
									"cc_edelete" => 1,
									"tailcmd" => 1,
									"tailscancmd" => 1,
								);

								my %fullsubs =
								(
									"cc_setup" => 1,
									"cc_setup1" => 1,
									"cc_setup2" => 1,
									"cc_setup3" => 1,
									"cc_setup4" => 1,
									"cc_setup5" => 1,
									"cc_setup6" => 1,
									"cc_delreport" => 1,
									"cc_reports" => 1,
									"cc_stats" => 1,
									"cc_file" => 1,
								);

								$script = "/$session/";
								$images = "/$session/images/cxs";
								$config{THIS_UI} = 1;

								my $csfjs = qq{
									<script>
										var csfCodename = "$codename";
									</script>
									<script src="$images/csf.min.js?v=$myv"></script>
								};

								my $bootstrapcss 	= "<link rel='stylesheet' href='$images/bootstrap/css/bootstrap.min.css?v=$myv'>";
								my $csfnt 			= "<script src='$images/csfont.min.js?v=$myv'></script>";
								my $jqueryjs		= "<script src='$images/jquery.min.js?v=$myv'></script>";
								my $bootstrapjs 	= "<script src='$images/bootstrap/js/bootstrap.min.js?v=$myv'></script>";
								my $fontawesome 	= "<link rel='stylesheet' href='https://use.fontawesome.com/releases/v5.0.10/css/all.css?v=$myv'>";

								if ($FORM{action} eq "cc_body" or $FORM{action} eq "cc_dbody" or $FORM{action} eq "cc_showreports")
								{
								}
								elsif ($ajaxsubs{$FORM{action}} or $FORM{action} eq "tailcmd" or $FORM{action} eq "tailscancmd")
								{
									print "content-type: text/plain\n\n";
								}
								else
								{
									print "Content-type: text/html\n\n";
									unless ($FORM{action} eq "RunScan" or ($FORM{action} =~ /^cc_/ and !$fullsubs{$FORM{action}} and $FORM{action} !~ /^cc_\w+bulk$/) or $FORM{action} eq "Run Scan" or $FORM{action} eq "viewq" or $FORM{action} eq "tailcmd" or $FORM{action} eq "tailscancmd") 
									{
										print <<EOF;
<!doctype html>
<html lang='en'>
<head>
	<script>
		(function()
		{
			var theme = localStorage.getItem('theme') || 'light';
			document.documentElement.setAttribute('data-theme', theme);
		})();
	</script>

	$bootstrapcss

	<link rel="preload" href="$images/configserver.css" as="style" onload="this.onload=null;this.rel='stylesheet'">
	<noscript><link rel="stylesheet" href="$images/configserver.css"></noscript>
	<link rel="icon" type="image/x-icon" href="$images/csf.png">
	<link href='https://fonts.googleapis.com/css?family=Raleway:400,700' rel='stylesheet' type='text/css'>
	<title>ConfigServer eXploit Scanner</title>
	<meta charset='utf-8'>
	<meta name='viewport' content='width=device-width, initial-scale=1'>

	$csfjs
	$fontawesome
	$jqueryjs
	$csfnt
	$bootstrapjs

</head>
<body>
<div id="loader"></div>
<a id='toplink' class='toplink' title='Go to bottom'><span class='glyphicon glyphicon-hand-down'></span></a>
<div class='container-fluid'>
EOF
										print "<div class='pull-right' style='margin:8px'>\n";
										if ($config{UI_CXS} or $config{UI_CSE}) {
											print "<form action='$script' method='post'><select name='csfapp'><option>csf</option>";
											if ($config{UI_CXS}) {print "<option selected>cxs</option>"}
											if ($config{UI_CSE}) {print "<option>cse</option>"}
											print "<", "/select> <input class='btn btn-default' type='submit' value='Switch'></form>\n";
										}
										print " <a class='btn btn-default' href='/$session/?csfaction=csflogout'>cxs Logout</a>\n";
										print "</div>\n";
										print <<EOF;
<div class='panel panel-default panel-body'>
<img align='absmiddle' src='$images/cxs_small.png' alt='ConfigServer eXploit Scanner' style='float:left'>
<h3>ConfigServer eXploit Scanner - cxs v$myv</h3>
</div>
EOF
									} # end unless
									else
									{
										print <<EOF;
<!doctype html>
<html lang='en'>
<head>
	<script>
		(function()
		{
			var theme = localStorage.getItem('theme') || 'light';
			document.documentElement.setAttribute('data-theme', theme);
		})();
	</script>

	$bootstrapcss

	<link rel="preload" href="$images/configserver.css" as="style" onload="this.onload=null;this.rel='stylesheet'">
	<noscript><link rel="stylesheet" href="$images/configserver.css"></noscript>

	$jqueryjs
	$bootstrapjs
</head>
<body>
<div class='container-fluid'>
<style>
pre {
	overflow: initial;
}
</style>
EOF
									}
								}

								ConfigServer::cxsUI::displayUI(\%FORM,\%ajaxsubs,$script,"",$images,$myv, "cpsess".$session);

								unless ($ajaxsubs{$FORM{action}})
								{
									print <<EOF;
<script>
	\$("#loader").hide();
</script>
</body>
</html>
EOF
								}
							}
							elsif ($application eq "cse" and $config{UI_CSE})
							{
								$script = "/$session/";
								$images = "/$session/images";
								$config{THIS_UI} = 1;
								ConfigServer::cseUI::main(\%FORM, $fileinc, $script, 0, $images, $myv, $config{THIS_UI});
							}
						}
						elsif ($file =~ /^\/images\/(\w+\/)?(\w+\/)?(\w+\/)?([\w\-]+\.(gif|png|jpg|[\w\-]+\.js|[\w\-]+\.css|css|[\w\-]+\.woff2|woff2|[\w\-]+\.woff|woff|[\w\-]+\.tff|tff))/i)
						{
							my $type = $2;
							if ($type eq "jpg") {$type = "jpeg"}
							print "HTTP/1.0 200 OK\r\n";
							if ($file =~ /^\/images\/((\w+\/)?(\w+\/)?(\w+\/)?[\w\-]+\.(gif|png|jpg))/i) {
								print "Content-type: image/$type\r\n";
							}
							elsif ($file =~ /^\/images\/((\w+\/)?(\w+\/)?(\w+\/)?[\w\-]+\.([\w\-]+\.css|css))/i) {
								print "Content-type: text/css\r\n";
							}
							elsif ($file =~ /^\/images\/((\w+\/)?(\w+\/)?(\w+\/)?[\w\-]+\.([\w\-]+\.js))/i) {
								print "Content-type: text/plain\r\n";
							}
							elsif ($file =~ /^\/images\/((\w+\/)?(\w+\/)?(\w+\/)?[\w\-]+\.([\w\-]+\.woff2|woff2))/i) {
								print "Content-type: application/font-woff2\r\n";
							}
							elsif ($file =~ /^\/images\/((\w+\/)?(\w+\/)?(\w+\/)?[\w\-]+\.([\w\-]+\.woff|woff))/i) {
								print "Content-type: application/font-woff\r\n";
							}
							elsif ($file =~ /^\/images\/((\w+\/)?(\w+\/)?(\w+\/)?[\w\-]+\.([\w\-]+\.tff|tff))/i) {
								print "Content-type: application/octet-stream\r\n";
							}
							print "\r\n";
							open (my $IMAGE, "<", "/etc/csf/ui/images/$1");
							flock ($IMAGE, LOCK_SH);
							while (<$IMAGE>) {print $_}
							close ($IMAGE);
						}
						else
						{
							&ui_403;
						}
					}
					alarm(0);
				};

				if ($@)
				{
					logfile("*UI* child: [$!] [$@]")
				}
	
				$client->close();
				alarm(0);
				exit;
			}
			$client->close(SSL_no_shutdown => 1);
		}
		exit;
	}
	return;
}

sub ui_403
{
	print "HTTP/1.0 403 Forbidden\r\n";
	print "Content-type: text/html\r\n";
	print "\r\n";
	print "<html>\n<head>\n<title>403 Forbidden</title>\n</head>\n<body>\n";
	print "<h1>403 Forbidden</h1>\n";
	print "You don't have permission to access this resource\n";
	print "<", "/body>\n</html>\n";
	return;
}

sub ui_413
{
	print "HTTP/1.0 413 Request Entity Too Large\r\n";
	print "Content-type: text/html\r\n";
	print "\r\n";
	print "<html>\n<head>\n<title>413 Request Entity Too Large</title>\n</head>\n<body>\n";
	print "<h1>413 Request Entity Too Large</h1>\n";
	print "The Request Data is too large for this server to handle";
	print "<", "/body>\n</html>\n";
	return;
}

sub lfdserver
{
	$SIG{CHLD} = 'IGNORE';
	unless (defined ($childpid = fork)) {
		&shutdown(__LINE__,"*Error* cannot fork: $!");
	} 
	$forks{$childpid} = 1;
	$clusterip = $childpid;
	unless ($childpid) {
		$childproc = "Cluster";
		my $cipher = Crypt::CBC->new( -key => $config{CLUSTER_KEY}, -cipher => 'Blowfish_PP');
		my %cmembers;
		foreach my $cip (split(/\,/,$config{CLUSTER_RECVFROM})) {$cmembers{$cip} = 1}
		if ($config{CLUSTER_MASTER}) {$cmembers{$config{CLUSTER_MASTER}} = 1}

		$0 = "lfd Cluster Server";
		$SIG{INT} = \&shutdown_child;
		$SIG{TERM} = \&shutdown_child;
		$SIG{HUP} = \&shutdown_child;
		$SIG{__DIE__} = sub {&shutdown_child(@_);};

		my $server = IO::Socket::INET->new(
			LocalPort => $config{CLUSTER_PORT},
			Type => SOCK_STREAM,
			ReuseAddr => 1,
			Listen => $config{CLUSTER_CHILDREN},
		) or &shutdown_child(__LINE__,"*Error* cannot open server on port $config{CLUSTER_PORT}: $!");

		while (1) {
			while (my ($client, $c_addr) = $server->accept()) {
				$SIG{CHLD} = 'IGNORE';
				my $pid = fork;
				if ($pid == 0) {
					eval {
						local $SIG{__DIE__} = undef;
						local $SIG{'ALRM'} = sub {die};
						alarm(10);
						close $server;

						my ($cport,$iaddr) = sockaddr_in($c_addr);
						my $peeraddress = inet_ntoa($iaddr);
						my $pip = iplookup($peeraddress);

						if ($cmembers{$peeraddress}) {
							binmode $client;
							$| = 1;
							my $line;
							my $grep;
							my $tip;
							while ($line !~ /END\n$/) {
								my $char;
								$client->read($char,1) or last;
								$line .= $char;
							}
							$line =~ s/END\n$//;

							my $decrypted = $cipher->decrypt($line);
							if ($config{DEBUG} >= 2) {logfile("debug: Cluster member $peeraddress said [$decrypted]")}
							my ($command,$ip,$perm,$ports,$inout,$timeout,$message) = split(/\s/,$decrypted,7);
							if ($perm eq "") {$perm = 1}
							if ($ports eq "*") {$ports = ""}
							if (checkip(\$ip)) {$tip = iplookup($ip)}
							if ($message eq "") {$message = "Not provided - $tip"}

							if ($command eq "D") {
								&ipblock($perm,"Cluster member $pip said, DENY $ip, Reason:[$message]",$ip,$ports,$inout,$timeout,1,"","LF_CLUSTER");
							}
							elsif ($command eq "TD") {
								&ipblock($perm,"Cluster member $pip said, TEMPDENY $ip, Reason:[$message]",$ip,$ports,$inout,$timeout,1,"","LF_CLUSTER");
							}
							elsif ($command eq "A" and checkip(\$ip)) {
								logfile("Cluster member $pip said, ALLOW $ip, [$message]");
								&syscommand(__LINE__,"/usr/sbin/csf","-a",$ip,"Cluster member $pip said, ALLOW $ip, Reason:[$message]");
							}
							elsif ($command eq "TA") {
								logfile("Cluster member $pip said, TEMPALLOW $ip, Reason:[$message]");
								&syscommand(__LINE__,"/usr/sbin/csf","-ta",$ip,$timeout,"-p",$ports,"-d",$inout,"Cluster member $pip said, TEMPALLOW $ip, Reason:[$message]");
							}
							elsif ($command eq "AR" and checkip(\$ip)) {
								logfile("Cluster member $pip said, REMOVE ALLOW $tip");
								&syscommand(__LINE__,"/usr/sbin/csf","-ar",$ip);
								&syscommand(__LINE__,"/usr/sbin/csf","-tr",$ip);
							}
							elsif ($command eq "R" and checkip(\$ip)) {
								logfile("Cluster member $pip said, REMOVE DENY $tip");
								&syscommand(__LINE__,"/usr/sbin/csf","-dr",$ip);
								&syscommand(__LINE__,"/usr/sbin/csf","-tr",$ip);
							}
							elsif ($command eq "I" and checkip(\$ip)) {
								my $ignorematches;
								my @ignore = slurp("/etc/csf/csf.ignore");
								foreach my $line (@ignore) {
									if ( $line =~ /^Include\s*(.*)$/ ) {
										my @incfile = slurp( $1 );
										push @ignore,@incfile;
									}
								}
								foreach my $line (@ignore) {
									$line =~ s/$cleanreg//g;
									if ( $line eq "" ) { next }
									if ( $line =~ /^\s*\#|Include/ ) { next }
									my ($ipd,$commentd) = split (/\s/,$line,2);
									checkip(\$ipd);
									if ($ipd eq $ip) {
										$ignorematches = 1;
										last;
									}
								}
								sysopen (my $IGNORE, "/etc/csf/csf.ignore", O_RDWR | O_CREAT);
								flock ($IGNORE, LOCK_EX);
								my $text = join("", <$IGNORE>);
								@ignore = split(/$slurpreg/,$text);
								chomp @ignore;
								unless ($ignorematches) {
									print $IGNORE "$ip # Cluster member $pip said, IGNORE $ip, Reason:[$message] - ".localtime(time)."\n";
									logfile("Cluster member $pip said, IGNORE $ip, [$message]");
									logfile("Cluster - lfd restarting...");
									open (my $LFDOUT, ">", "/var/lib/csf/lfd.restart");
									close ($LFDOUT);
								} else {
									logfile("Cluster member $pip said, IGNORE $ip, [$message], however it is already being ignored");
								}
								close ($IGNORE);
							}
							elsif ($command eq "IR" and checkip(\$ip)) {
								my $hit;
								sysopen (my $IGNORE, "/etc/csf/csf.ignore", O_RDWR | O_CREAT);
								flock ($IGNORE, LOCK_EX);
								my $text = join("", <$IGNORE>);
								my @ignore = split(/$slurpreg/,$text);
								chomp @ignore;
								seek ($IGNORE, 0, 0);
								truncate ($IGNORE, 0);
								foreach my $line (@ignore) {
									$line =~ s/$cleanreg//g;
									my ($ipd,$commentd) = split (/\s/,$line,2);
									checkip(\$ipd);
									if ($ipd eq $ip) {
										$hit = 1;
										next;
									} else {
										print $IGNORE $line."\n";
									}
								}
								close ($IGNORE);
								if ($hit) {
									logfile("Cluster member $pip said, REMOVE IGNORE $tip");
									logfile("Cluster - lfd restarting...");
									open (my $LFDOUT, ">", "/var/lib/csf/lfd.restart");
									close ($LFDOUT);
								} else {
									logfile("Cluster member $pip said, REMOVE IGNORE $tip, however it is not in csf.ignore");
								}
							}
							elsif ($command eq "PING") {
								logfile("Cluster member $pip said PING!");
							}
							elsif ($command eq "G") {
								logfile("Cluster member $pip said GREP $tip");
								my @output = &syscommand(__LINE__,"/usr/sbin/csf","-g",$ip);
								$grep = join("",@output);
							}
							elsif ($command eq "C") {
								my (undef,$name,$value) = split(/\s/,$decrypted,3);
								if ($config{CLUSTER_MASTER} and ($config{CLUSTER_MASTER} eq $peeraddress)) {
									$value =~ s/\"|\=//g;
									$value =~ s/(^\s*)|(\s*$)//g;
									if ($config{CLUSTER_CONFIG}) {
										logfile("Cluster member $pip said set [$name = \"$value\"]");
										&updateconfig($name,$value);
									} else {
										logfile("Cluster member $pip said set [$name = \"$value\"], however CLUSTER_CONFIG disabled");
									}
								} else {
									logfile("*Cluster* member $pip said set [$name = \"$value\"], however it is not the CLUSTER_MASTER");
								}
							}
							elsif ($command eq "FILE") {
								my (undef,$filename) = split(/\s/,$decrypted);
								my ($file, $filedir) = fileparse($filename);
								if ($config{CLUSTER_MASTER} and ($config{CLUSTER_MASTER} eq $peeraddress)) {
									if ($config{CLUSTER_CONFIG}) {
										my (undef,$content) = split(/\n/,$decrypted,2);
										logfile("Cluster member $pip said store file [$file]");
										open (my $FH, ">", "/etc/csf/$file");
										flock ($FH, LOCK_EX);
										binmode ($FH);
										print $FH $content;
										close ($FH);
									} else {
										logfile("*Cluster* member $pip said store file [$file], however CLUSTER_CONFIG disabled");
									}
								} else {
									logfile("*Cluster* member $pip said store file [$file], however it is not the CLUSTER_MASTER");
								}
							}
							elsif ($command eq "RESTART") {
								if ($config{CLUSTER_MASTER} and ($config{CLUSTER_MASTER} eq $peeraddress)) {
									if ($config{CLUSTER_CONFIG}) {
										logfile("Cluster member $pip said restart csf and lfd");
										logfile("Cluster - csf restarting...");
										&syscommand(__LINE__,"/usr/sbin/csf","-sf");
										logfile("Cluster - lfd restarting...");
										open (my $LFDOUT, ">", "/var/lib/csf/lfd.restart");
										close ($LFDOUT);
									} else {
										logfile("*Cluster* member $pip said restart csf and lfd, however CLUSTER_CONFIG disabled");
									}
								} else {
									logfile("*Cluster* member $pip said restart csf and lfd, however it is not the CLUSTER_MASTER");
								}
							}
							else {
								logfile("*WARNING* Cluster member $pip talking nonsense");
							}

							if ($command eq "PING") {
								print $client "PONG!\n";
							}
							elsif ($command eq "G") {
								print $client "$grep\n";
							}
							else {
								print $client "Received\n";
							}
						} else {
							logfile("*WARNING* $pip attempted to connect to the Cluster but not a member!");
						}
						alarm(0);
					};
					alarm(0);
					shutdown ($client,2);
					$client->close();
					exit;
				}
				$client->close();
			}
		}
	}
	return;
}

sub lfdclient
{
	my $perm = shift;
	my $message = shift;
	my $ip = shift;
	my $port = shift;
	my $inout = shift;
	my $timeout = shift;
	if ($port eq "") {$port = "*"}

	$SIG{CHLD} = 'IGNORE';
	unless (defined ($childpid = fork)) {
		&shutdown(__LINE__,"*Error* cannot fork: $!");
	} 
	$forks{$childpid} = 1;
	unless ($childpid) {
		my $timer = time;
		if ($config{DEBUG} >= 3) {$timer = &timer("start","lfdclient",$timer)}
		$0 = "lfd - Cluster client";

		my $cipher = Crypt::CBC->new( -key => $config{CLUSTER_KEY}, -cipher => 'Blowfish_PP');
		my $text;
		if ($perm) {
			$text = "D $ip $perm $port $inout $timeout $message";
		} else {
			$text = "TD $ip $perm $port $inout $timeout $message";
		}
		my $encrypted = $cipher->encrypt($text)."END\n";

		foreach my $cip (split(/\,/,$config{CLUSTER_SENDTO})) {
			if ($ips{$cip} or $ipscidr->find($cip) or $ipscidr6->find($cip) or ($cip eq $config{CLUSTER_NAT})) { next }
			my $localaddr = "0.0.0.0";
			if ($config{CLUSTER_LOCALADDR}) {$localaddr = $config{CLUSTER_LOCALADDR}}
			my $tip = iplookup($cip);
			my $sock;
			eval {$sock = IO::Socket::INET->new(PeerAddr => $cip, PeerPort => $config{CLUSTER_PORT}, LocalAddr => $localaddr, Timeout => '10');};
			unless (defined $sock) {
				logfile("Cluster: Failed to connect to $tip");
			} else {
				my $status = send($sock,$encrypted,0);
				unless ($status) {
					logfile("Cluster: Failed for $tip - $status");
				} else {
					if ($perm) {
						logfile("Cluster: DENY $ip sent to $tip");
					} else {
						logfile("Cluster: TEMPDENY $ip sent to $tip");
					}
				}
				shutdown($sock,2);
			}
		}
		if ($config{DEBUG} >= 3) {$timer = &timer("stop","lfdclient",$timer)}
		$0 = "lfd - (child) closing";
		exit;
	}
	return;
}

# #
#	WHM
#	
#	Read WHM/cPanel Apache server-status access key from 
#		/var/cpanel/whm_server_status_key
#	Return as single cleaned string
#	
#	@ref		https://docs.cpanel.net/knowledge-base/cpanel-product/the-cpanel-log-files/
# #

sub _whm_get_apache_key
{
	my $whm_server_status_key_file = '/var/cpanel/whm_server_status_key';

	# No key file present (or unreadable) => just act like there is no key
	return unless -r $whm_server_status_key_file;

	my $key;
	eval
	{
		local $SIG{__DIE__} = undef;
		sysopen ( my $IN, $whm_server_status_key_file, O_RDONLY ) or die;
		flock ( $IN, LOCK_SH );
		$key = <$IN>;
		close ( $IN );
	};

	unless ( defined $key )
	{
		logfile('Unable to read Apache server-status key file');
		return;
	}

	chomp $key;
	$key =~ s/\s+//g;

	return unless length $key;

	# Basic sanity check to avoid injecting unexpected characters into URLs/logs
	if ( length($key) > 256 or $key =~ /[^A-Za-z0-9_\-]/ )
	{
		logfile( 'Invalid Apache server-status key file contents' );
		return;
	}

	return $key;
}

# #
#	Ensures that keys aren't leaked into logs.
#	Builds two versions of an Apache server-status URL:
#		1) real URL to request ($url)
#		2) log-safe URL ($log_url) with key redacted
# #

sub _get_apache_status_url
{
	my $base_url = shift;
	my $url = $base_url;

	if ( $codename eq "cpanel" )
	{
		my $key = _whm_get_apache_key();
		if ( defined $key )
		{
			my $keyenc = uriClean($key);
			$url .= ( $url =~ /\?/ ? "&" : "?" ) . "key=$keyenc";
		}
	}

	my $log_url = $url;
	$log_url =~ s/([?&])key=[^&]*/$1key=REDACTED/;

	return ( $url, $log_url );
}

# #
#	lfd.pl › Update csf.conf
# #

sub updateconfig
{
	my $chname 		= shift;
	my $chvalue 	= shift;

	sysopen ( my $OUT, "/etc/csf/csf.conf", O_RDWR | O_CREAT );
	flock ( $OUT, LOCK_EX );
	my @confdata = <$OUT>;
	chomp @confdata;
	seek ( $OUT, 0, 0 );
	truncate ( $OUT, 0 );

	for ( my $x = 0; $x < @confdata;$x++ )
	{
		if ( ( $confdata[$x] !~ /^\#/ ) and ( $confdata[$x] =~ /=/ ) )
		{
			my ( $name, $value ) = split ( /=/,$confdata[$x], 2 );
			$name =~ s/\s*//g;
			if ( $name eq $chname )
			{
				print $OUT "$name = \"$chvalue\"\n";
			}
			else
			{
				print $OUT "$confdata[$x]\n";
			}
		}
		else
		{
			print $OUT "$confdata[$x]\n";
		}
	}

	close ( $OUT );
	return;
}

sub stats
{
	my $line = shift;
	my $type = shift;

	$SIG{CHLD} = 'IGNORE';
	unless ( defined ($childpid = fork) )
	{
		&shutdown( __LINE__, "*Error* cannot fork: $!" );
	}

	$forks{$childpid} = 1;
	unless ( $childpid )
	{
		my $timer = time;
		if ( $config{DEBUG} >= 3 )
		{
			$timer = &timer( "start","stats", $timer )
		}
	
		$0 = "lfd - (child) Statistics...";

		eval
		{
			local $SIG{__DIE__} 	= undef;
			local $SIG{'ALRM'} 		= sub {die};
	
			alarm(15);
	
			if ( $type eq "iptables" )
			{
				my ( $in, $out, $src, $dst, $text );
	
				if ( $line =~ /IN=(\S+)/ ) 		{ $in = $1 }
				if ( $line =~ /OUT=(\S+)/ ) 	{ $out = $1 }
				if ( $line =~ /SRC=(\S+)/ ) 	{ $src = $1 }
				if ( $line =~ /DST=(\S+)/ ) 	{ $dst = $1 }

				if ( $config{ST_LOOKUP} )
				{
					if ( $in and $src ) 	{ $text	= iplookup( $src ) }
					elsif ( $out and $dst )	{ $text	= iplookup( $dst ) }
				}

				sysopen (my $IPTABLES, "/var/lib/csf/stats/iptables_log", O_WRONLY | O_APPEND | O_CREAT);
				flock ($IPTABLES, LOCK_EX);
				print $IPTABLES "$text|$line\n";
				close ($IPTABLES);

				if ((stat("/var/lib/csf/stats/iptables_log"))[7] > (2048 * $config{ST_IPTABLES})) {
					my $lockstr = "ST_IPTABLES";
					sysopen (my $THISLOCK, "/var/lib/csf/lock/$lockstr.lock", O_RDWR | O_CREAT) or &shutdown_child("*Error* Unable to open /var/lib/csf/lock/$lockstr.lock");
					unless (flock ($THISLOCK, LOCK_EX | LOCK_NB)) {
						if ($config{DEBUG} >= 1) {
							&shutdown_child("debug: *Lock Error* [$lockstr] still active - section skipped");
						} else {
							&shutdown_child;
						}
					}

					print $THISLOCK time;
					sysopen (my $IPTABLES, "/var/lib/csf/stats/iptables_log", O_RDWR | O_CREAT);
					flock ($IPTABLES, LOCK_EX);

					my @iptables = <$IPTABLES>;
					chomp @iptables;
					my @last = @iptables[-$config{ST_IPTABLES}..-1];

					seek ($IPTABLES, 0, 0);
					truncate ($IPTABLES, 0);

					foreach my $line (@last) {
						print $IPTABLES "$line\n"
					}
					close ($IPTABLES);
				}

				if ( $config{DEBUG} >= 2 )
                {
                    logfile( "debug: STATS added iptables [ $src => $dst ] log line" );
                }
			}
			alarm(0);
		};

		alarm(0);

		if ( $@ )
		{
			logfile("STATS: 15 sec. timeout performing iptables_log")
		}

		if ($config{DEBUG} >= 3) {$timer = &timer("stop","stats",$timer)}
		$0 = "lfd - (child) closing";
		exit;
	}
	return;
}

sub systemstats
{
	$SIG{CHLD} = 'IGNORE';
	unless (defined ($childpid = fork)) {
		&shutdown(__LINE__,"*Error* cannot fork: $!");
	} 
	$forks{$childpid} = 1;
	unless ($childpid) {
		my $timer = time;
		if ($config{DEBUG} >= 3) {$timer = &timer("start","systemstats",$timer)}
		$0 = "lfd - (child) System Statistics...";

		my $lockstr = "ST_SYSTEM";
		sysopen (my $THISLOCK, "/var/lib/csf/lock/$lockstr.lock", O_RDWR | O_CREAT) or &shutdown_child("*Error* Unable to open /var/lib/csf/lock/$lockstr.lock");
		flock ($THISLOCK, LOCK_EX | LOCK_NB) or &shutdown_child("*Lock Error* [$lockstr] still active - section skipped");
		print $THISLOCK time;
		
		local $SIG{__DIE__} = undef;
		
		my $time = time;
		my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime($time);
		my $cputotal;
		my $cpuidle;
		my $cpuiowait;
		my $memtotal;
		my $memfree;
		my $memswaptotal;
		my $memswapfree;
		my $netin;
		my $netout;
		my $diskread;
		my $diskwrite;
		my $mailin;
		my $mailout;
		my $cputemp;
		my $mysqlin;
		my $mysqlout;
		my $mysqlq;
		my $mysqlsq;
		my $mysqlcn;
		my $mysqlth;
		my $apachecpu;
		my $apacheacc;
		my $apachebwork;
		my $apacheiwork;
		my $diskw;
		my $memcached;

		open (my $STAT, "<", "/proc/stat");
		flock ($STAT, LOCK_SH);
		my $line = <$STAT>;
		close ($STAT);
		chomp $line;
		my @cpu = split(/\s+/,$line);
		shift @cpu;
		foreach (@cpu) {$cputotal += $_}
		$cpuidle = $cpu[3];
		$cpuiowait = $cpu[4];

		open (my $MEMINFO, "<", "/proc/meminfo");
		flock ($MEMINFO, LOCK_SH);
		my @memdata = <$MEMINFO>;
		close ($MEMINFO);
		chomp @memdata;
		foreach my $line (@memdata) {
			if ($line =~ /^MemTotal:\s+(\d+)\s+/) {$memtotal = $1}
			if ($line =~ /^MemFree:\s+(\d+)\s+/) {$memfree = $1}
			if ($line =~ /^SwapTotal:\s+(\d+)\s+/) {$memswaptotal = $1}
			if ($line =~ /^SwapFree:\s+(\d+)\s+/) {$memswapfree = $1}
			if ($line =~ /^Cached:\s+(\d+)\s+/) {$memcached = $1}
		}

		open (my $LOADAVG, "<", "/proc/loadavg");
		flock ($LOADAVG, LOCK_SH);
		my $loadavg = <$LOADAVG>;
		close ($LOADAVG);
		chomp $loadavg;
		my @load = split(/\s+/,$loadavg);

		opendir (DIR, "/sys/class/net");
		while (my $dir = readdir(DIR)) {
			if ($dir eq "." or $dir eq ".." or $dir eq "lo") { next }
			open (my $IN, "<", "/sys/class/net/$dir/operstate");
			flock ($IN, LOCK_SH);
			my $state = <$IN>;
			close ($IN);
			chomp $state;
			if ($state ne "down") {
				open (my $RX_BYTES, "<", "/sys/class/net/$dir/statistics/rx_bytes");
				flock ($RX_BYTES, LOCK_SH);
				my $datain = <$RX_BYTES>;
				close ($RX_BYTES);
				chomp $datain;
				$netin += $datain;

				open (my $TX_BYTES, "<", "/sys/class/net/$dir/statistics/tx_bytes");
				flock ($TX_BYTES, LOCK_SH);
				my $dataout = <$TX_BYTES>;
				close ($TX_BYTES);
				chomp $dataout;
				$netout += $dataout;
			}
		}
		closedir (DIR);

		if (-e "/proc/diskstats") {
			open (my $IN, "<", "/proc/diskstats");
			flock ($IN, LOCK_SH);
			my @diskdata = <$IN>;
			close ($IN);
			chomp @diskdata;
			foreach my $line (@diskdata) {
				my @item = split(/\s+/,$line);
				if ($item[3] =~ /^[[:alpha:]]+$/) {
					$diskread += $item[4];
					$diskwrite += $item[8];
				}
			}
			if ($diskread < 1) {
				foreach my $line (@diskdata) {
					my @item = split(/\s+/,$line);
					if ($item[3] =~ /^[[:alpha:]]+\d+$/) {
						$diskread += $item[4];
						$diskwrite += $item[8];
					}
				}
			}
		}

		my $dotemp = 0;
		if (-e "/sys/devices/platform/coretemp.0/temp3_input") {$dotemp = 3}
		if (-e "/sys/devices/platform/coretemp.0/temp2_input") {$dotemp = 2}
		if (-e "/sys/devices/platform/coretemp.0/temp1_input") {$dotemp = 1}
		if ($dotemp) {
			opendir (DIR, "/sys/devices/platform");
			while (my $dir = readdir(DIR)) {
				unless ($dir =~ /^coretemp/) { next }
				open (my $IN, "<", "/sys/devices/platform/$dir/temp".$dotemp."_input");
				flock ($IN, LOCK_SH);
				my $temp = <$IN>;
				close ($IN);
				chomp $temp;
				if ($temp > $cputemp) {$cputemp = $temp}
			}
			closedir (DIR);
			$cputemp = sprintf("%.2f",$cputemp/1000)
		}

		sysopen (my $EMAIL, "/var/lib/csf/stats/email", O_RDWR | O_CREAT);
		flock ($EMAIL, LOCK_EX);
		my $stats = <$EMAIL>;
		chomp $stats;
		($mailout,$mailin) = split(/\:/,$stats);
		seek ($EMAIL, 0, 0);
		truncate ($EMAIL, 0);
		print $EMAIL "0:0";
		close ($EMAIL);

		# # 
		#   If ST_SYSTEM is enabled, then these options can collect MySQL statistical
		#   data. To use this option the server must have the perl modules DBI and
		#   DBD::mysql installed.
		#   
		#   Set this option to "0" to disable MySQL data collection
		# # 

		if ( $config{ST_MYSQL} )
		{
			eval( 'use DBI;' ); ##no critic
			if ( $@ )
			{
				sysopen ( my $TEMPCONF, "/var/lib/csf/csf.tempconf", O_WRONLY | O_APPEND | O_CREAT ) or &shutdown_child( __LINE__, "*Error* Cannot append out file: $!" );
				flock ( $TEMPCONF, LOCK_EX );
				print $TEMPCONF "ST_MYSQL = \"0\"\n";
				close ( $TEMPCONF );

				logfile( "STATS: DBI Perl Module missing - ST_MYSQL has been temporarily disabled. You should disable ST_MYSQL and restart lfd if you do not use this feature" );
			}
			else
			{
				eval
				{
					local $SIG{__DIE__} = undef;
					local $SIG{'ALRM'} 	= sub {die};
					alarm(15);

					my $dbuser = $config{ST_MYSQL_USER};
					my $dbpass = $config{ST_MYSQL_PASS};
					my $dbhost = $config{ST_MYSQL_HOST};

					if ( $dbpass eq "" and $dbuser eq "root" )
					{
						open ( my $DBS, "<", "/root/.my.cnf" );
						flock ( $DBS, LOCK_SH );
						while (<$DBS>)
						{
							chomp;
							if (/^pass(word)?=(\S+)/)
							{
								$dbpass = $2;
								$dbpass =~ s/^\"|\"$//g;
							}

							if (/^host=(\S+)/)
							{
								$dbhost = $1;
								$dbhost =~ s/^\"|\"$//g;
							}
						}
						close ($DBS);
					}
					my $status;
					my $dbh = DBI->connect("DBI:mysql:hostname=".$dbhost,$dbuser,$dbpass,{PrintError=>0}) or $status = $DBI::errstr;
					if ($status) {
						logfile("STATS: Unable to connect to MySQL: [$DBI::errstr] - You should disable ST_MYSQL and restart lfd if you do not use this feature");
					} else {
						my $sth = $dbh->prepare('SHOW /*!50002 GLOBAL */ STATUS');
						$sth->execute();
						while(my ($key, $val) = $sth->fetchrow_array()) {
							if ($key eq "Bytes_received") {$mysqlin = $val}
							if ($key eq "Bytes_sent") {$mysqlout = $val}
							if ($key eq "Queries") {$mysqlq = $val}
							if ($key eq "Slow_queries") {$mysqlsq = $val}
							if ($key eq "Connections") {$mysqlcn = $val}
							if ($key eq "Threads_connected") {$mysqlth = $val}
						}
					}
					alarm(0);
				};
				alarm(0);
				if ($@) {logfile("STATS: 15 sec. timeout performing ST_MYSQL")}
			}
		}

		# # 
		#   If ST_SYSTEM is enabled, then this option can collect Apache statistical data
		#   The value for PT_APACHESTATUS must be correctly set
		# # 

		if ( $config{ST_APACHE} )
		{

			eval
			{
				local $SIG{ __DIE__ }	= undef;
				local $SIG{'ALRM'} 		= sub { die };

				alarm( 15 );

				# #
				#	@ref			https://docs.cpanel.net/whm/server-status/apache-status/
				#					https://docs.cpanel.net/knowledge-base/cpanel-product/the-cpanel-log-files/
				#					http://127.0.0.1/whm-server-status?auto
				# #

				my ( $url, $log_url ) 		= _get_apache_status_url( $config{PT_APACHESTATUS} . "?auto" );
				my ( $status, $apache ) 	= $urlget->urlget( $url );
		
				if ( $status )
				{
					logfile( "STATS: Unable to retrieve Apache Server Status | [$log_url] - $apache" );
				}
				else
				{
					foreach my $line ( split( /\n/,$apache ) )
					{
						my ( $item, $val ) 				= split( /:\s*/, $line );
						if ( $item eq "CPULoad") 		{ $apachecpu = $val }
						if ( $item eq "Total Accesses") { $apacheacc = $val }
						if ( $item eq "BusyWorkers") 	{ $apachebwork = $val }
						if ( $item eq "IdleWorkers") 	{ $apacheiwork = $val }
					}
				}

				alarm(0);
			};

			alarm(0);

			if ( $@ ) { logfile( "STATS: 15 sec. timeout performing ST_APACHE" ) }
		}

		# # 
		#   The following options measure disk write performance using dd (location set
		#   via the DD setting). It creates a 64MB file called /var/lib/dd_write_test and
		#   the statistics will plot the MB/s response time of the disk. As this is an IO
		#   intensive operation, it may not be prudent to run this test too often, so by
		#   default it is only run every 5 minutes and the result duplicated for each
		#   intervening minute for the statistics
		#   
		#   This is not necessrily a good measure of disk performance, primarily because
		#   the measurements are for relatively small amounts of data over a small amount
		#   of time. To properly test disk performance there are a variety of tools
		#   available that should be run for extended periods of time to obtain an
		#   accurate measurement. This metric is provided to give an idea of how the disk
		#   is performing over time
		#   
		#   Note: There is a 15 second timeout performing the check
		#   
		#   Set to 0 to disable, 1 to enable
		# # 

		if ( $config{ST_DISKW} )
		{
			my $skip = 0;
			if ( -e "/var/lib/csf/csf.tempdisk" )
			{
				open (my $ST_DISKW, "<", "/var/lib/csf/csf.tempdisk");
				flock ($ST_DISKW, LOCK_SH);
				my $line = <$ST_DISKW>;
				chomp $line;
				close ($ST_DISKW);

				my ( $time, $rate ) 				= split ( /\:/, $line );
				if ( $config{ST_DISKW_FREQ} < 1 ) 	{ $config{ST_DISKW_FREQ} = 1 }

				if ( time - $time < ( 60 * $config{ST_DISKW_FREQ} ) )
				{
					$skip 	= 1;
					$diskw 	= $rate;
				}
			}
			unless ($skip) {
				eval {
					local $SIG{__DIE__} = undef;
					local $SIG{'ALRM'} = sub {die};
					alarm(15);
					my @dddata = &syscommand(__LINE__,"$config{DD} $config{ST_DISKW_DD}");
					chomp @dddata;
					foreach my $line (@dddata) {
						if ($line =~ / (\d+(\.\d*)?) MB\/s$/) {
							$diskw = $1;
							last;
						}
						if ($line =~ / (\d+(\.\d*)?) GB\/s$/) {
							$diskw = $1 * 1024;
							last;
						}
					}
					alarm(0);
				};
				alarm(0);
				if ($@) {
					$diskw = 0;
					logfile("STATS: 15 sec. timeout performing ST_DISKW");
				}
				sysopen (my $ST_DISKW, "/var/lib/csf/csf.tempdisk", O_WRONLY | O_CREAT);
				flock ($ST_DISKW, LOCK_EX);
				print $ST_DISKW time.":$diskw\n";
				close ($ST_DISKW);
			}
		}

		sysopen (my $SYSSTAT,"/var/lib/csf/stats/system", O_WRONLY | O_APPEND | O_CREAT);
		flock ($SYSSTAT, LOCK_EX);
		print $SYSSTAT "$time,$cputotal,$cpuidle,$cpuiowait,$memtotal,$memfree,$memswaptotal,$memswapfree,$load[0],$load[1],$load[2],$netin,$netout,$diskread,$diskwrite,$mailin,$mailout,$cputemp,$mysqlin,$mysqlout,$mysqlq,$mysqlsq,$mysqlcn,$mysqlth,$apachecpu,$apacheacc,$apachebwork,$apacheiwork,$diskw,$memcached\n";
		close ( $SYSSTAT );

		close ($THISLOCK );

		if ($config{DEBUG} >= 3) {$timer = &timer("stop","systemstats",$timer)}
		$0 = "lfd - (child) closing";
		exit;
	}
	return;
}
# end systemstats
###############################################################################
# start allowip
sub allowip {
	my $ipmatch = shift;

	my @allow = slurp("/etc/csf/csf.allow");
	foreach my $line (@allow) {
		if ( $line =~ /^Include\s*(.*)$/ ) {
			my @incfile = slurp( $1 );
			push @allow,@incfile;
		}
	}
	foreach my $line (@allow) {
        $line =~ s/$cleanreg//g;
		if ( $line eq "" ) { next }
		if ( $line =~ /^\s*\#|Include/ ) { next }
		my ($ipd,$commentd) = split (/\s/,$line,2);
		if ($ipd eq $ipmatch) {
			return 1;
		}
		elsif ($ipd =~ /(\S+\/\d+)/) {
			my $cidrhit = $1;
			if (checkip(\$cidrhit)) {
				my $dcidr = Net::CIDR::Lite->new;
				eval {local $SIG{__DIE__} = undef; $dcidr->add($cidrhit)};
				if ($@) {logfile("Invalid CIDR in csf.allow: $cidrhit")}
				if ($dcidr->find($ipmatch)) {
					return 1;
				}
			}
		}
	}

	if ($config{GLOBAL_ALLOW} and -e "/var/lib/csf/csf.gallow") {
		open (my $IN, "<", "/var/lib/csf/csf.gallow");
		flock ($IN, LOCK_SH);
		my @allow = <$IN>;
		close ($IN);
		chomp @allow;
		foreach my $line (@allow) {
			if ( $line eq "" ) { next }
			if ($line =~ /^\s*\#/) { next }
			my ($ipd,$commentd) = split (/\s/,$line,2);
			if ($ipd eq $ipmatch) {
				return 2;
			}
			elsif ($ipd =~ /(\S+\/\d+)/) {
				my $cidrhit = $1;
				if (checkip(\$cidrhit)) {
					my $dcidr = Net::CIDR::Lite->new;
					eval {local $SIG{__DIE__} = undef; $dcidr->add($cidrhit)};
					if ($@) {logfile("Invalid CIDR in csf.gallow: $cidrhit")}
					if ($dcidr->find($ipmatch)) {
						return 2;
					}
				}
			}
		}
	}
	return;
}
# end allowip
###############################################################################
# start testregex
sub testregex {
	my $match = shift;
	eval {
		local $SIG{__DIE__} = undef;
		my $test =~ /$match/;
	};
	if ($@) {return 0}
	return 1;
}
# end testregex
###############################################################################
# start faststart
sub faststart {
	my $text = shift;
	$faststart = 0;
	my $verbose = 1;
	if ($text =~ /^Blocklist \[CXS_/) {$verbose = 0}
	if (@faststart4) {
		if ($config{DEBUG} >= 1 and $verbose) {logfile("FASTSTART loading $text (IPv4)")};
		my $status;
		if ($config{VPS}) {$status = &fastvps(scalar @faststart4)}
		if ($status) {
			logfile($status);
		} else {
			&iptableslock("lock");
			my ($childin, $childout);
			my $cmdpid = open3($childin, $childout, $childout, "$config{IPTABLES_RESTORE} $config{IPTABLESWAIT} -n");
			print $childin "*filter\n".join("\n",@faststart4)."\nCOMMIT\n";
			close $childin;
			my @results = <$childout>;
			waitpid ($cmdpid, 0);
			chomp @results;
			if ($results[0] =~ /# Warning: iptables-legacy tables present/) {shift @results}
			if ($results[0] =~ /^(iptables|ip6tables|xtables|Bad|Another)/) {
				my $cmd;
				if ($results[1] =~ /^Error occurred at line: (\d+)$/) {$cmd = $faststart4[$1 - 1]}
				logfile("*Error* FASTSTART: ($text IPv4) [$cmd] [$results[0]]");
			}
			&iptableslock("unlock",1);
		}
	}
	if (@faststart4nat) {
		if ($config{DEBUG} >= 1 and $verbose) {logfile("FASTSTART loading $text (IPv4 nat)")};
		my $status;
		if ($config{VPS}) {$status = &fastvps(scalar @faststart4nat)}
		if ($status) {
			logfile($status);
		} else {
			&iptableslock("lock");
			my ($childin, $childout);
			my $cmdpid = open3($childin, $childout, $childout, "$config{IPTABLES_RESTORE} $config{IPTABLESWAIT} -n");
			print $childin "*nat\n".join("\n",@faststart4nat)."\nCOMMIT\n";
			close $childin;
			my @results = <$childout>;
			waitpid ($cmdpid, 0);
			chomp @results;
			if ($results[0] =~ /# Warning: iptables-legacy tables present/) {shift @results}
			if ($results[0] =~ /^(iptables|ip6tables|xtables|Bad|Another)/) {
				my $cmd;
				if ($results[1] =~ /^Error occurred at line: (\d+)$/) {$cmd = $faststart4[$1 - 1]}
				logfile("*Error* FASTSTART: ($text IPv4nat) [$cmd] [$results[0]]");
			}
			&iptableslock("unlock",1);
		}
	}
	if (@faststart6) {
		if ($config{DEBUG} >= 1 and $verbose) {logfile("FASTSTART loading $text (IPv6)")};
		my $status;
		if ($config{VPS}) {$status = &fastvps(scalar @faststart6)}
		if ($status) {
			logfile($status);
		} else {
			&iptableslock("lock");
			my ($childin, $childout);
			my $cmdpid = open3($childin, $childout, $childout, "$config{IP6TABLES_RESTORE} $config{IPTABLESWAIT} -n");
			print $childin "*filter\n".join("\n",@faststart6)."\nCOMMIT\n";
			close $childin;
			my @results = <$childout>;
			waitpid ($cmdpid, 0);
			chomp @results;
			if ($results[0] =~ /# Warning: iptables-legacy tables present/) {shift @results}
			if ($results[0] =~ /^(iptables|ip6tables|xtables|Bad|Another)/) {
				my $cmd;
				if ($results[1] =~ /^Error occurred at line: (\d+)$/) {$cmd = $faststart4[$1 - 1]}
				logfile("*Error* FASTSTART: ($text IPv6) [$cmd] [$results[0]]");
			}
			&iptableslock("unlock",1);
		}
	}
	if (@faststart6nat) {
		if ($config{DEBUG} >= 1 and $verbose) {logfile("FASTSTART loading $text (IPv6 nat)")};
		my $status;
		if ($config{VPS}) {$status = &fastvps(scalar @faststart6nat)}
		if ($status) {
			logfile($status);
		} else {
			&iptableslock("lock");
			my ($childin, $childout);
			my $cmdpid = open3($childin, $childout, $childout, "$config{IP6TABLES_RESTORE} $config{IPTABLESWAIT} -n");
			print $childin "*nat\n".join("\n",@faststart6nat)."\nCOMMIT\n";
			close $childin;
			my @results = <$childout>;
			waitpid ($cmdpid, 0);
			chomp @results;
			if ($results[0] =~ /# Warning: iptables-legacy tables present/) {shift @results}
			if ($results[0] =~ /^(iptables|ip6tables|xtables|Bad|Another)/) {
				my $cmd;
				if ($results[1] =~ /^Error occurred at line: (\d+)$/) {$cmd = $faststart6[$1 - 1]}
				logfile("*Error* FASTSTART: ($text IPv6nat) [$cmd] [$results[0]]");
			}
			&iptableslock("unlock",1);
		}
	}
	if (@faststartipset) {
		if ($config{DEBUG} >= 1 and $verbose) {logfile("FASTSTART loading $text (IPSET)")};
		my ($childin, $childout);
		my $cmdpid = open3($childin, $childout, $childout, $config{IPSET},"restore");
		print $childin join("\n",@faststartipset)."\n";
		close $childin;
		my @results = <$childout>;
		waitpid ($cmdpid, 0);
		chomp @results;
		if ($results[0] =~ /^ipset/) {
			logfile("FASTSTART: (IPSET) Error:[$results[0]]");
		}
	}
	undef @faststart4;
	undef @faststart4nat;
	undef @faststart6;
	undef @faststart6nat;
	undef @faststartipset;
	return;
}
# end faststart
###############################################################################
# start fastvps
sub fastvps {
	my $size = shift;
	if (-e "/proc/user_beancounters" and !(-e "/proc/vz/version")) {
		open (my $INVPS, "<", "/proc/user_beancounters");
		flock ($INVPS, LOCK_SH);
		my @data = <$INVPS>;
		close ($INVPS);
		chomp @data;

		foreach my $line ( @data ) {
			if ($line =~ /^\s*numiptent\s+(\d*)\s+(\d*)\s+(\d*)\s+(\d*)/) {
				if ($1 > $4 - ($size + 10)) {return "The VPS iptables rule limit (numiptent) is too low to add $size rules ($1/$4) - *IPs not added*"}
			}
		}
	}
	return 0;
}
# end fastvps
###############################################################################
# start ipsetcreate
sub ipsetcreate {
	my $set = shift;
	my $family = "inet";
	if ($set =~ /_6/) {$family = "inet6"}
	my ($childin, $childout);
	my $cmdpid = open3($childin, $childout, $childout, $config{IPSET},"create","-exist",$set,"hash:net","family",$family,"hashsize",$config{LF_IPSET_HASHSIZE},"maxelem",$config{LF_IPSET_MAXELEM});
	close $childin;
	my @results = <$childout>;
	waitpid ($cmdpid, 0);
	chomp @results;
	if ($results[0] =~ /^ipset/) {
		logfile("*Error* IPSET: [$results[0]]");
	}
	return;
}
# end ipsetcreate
###############################################################################
# start ipsetrestore
sub ipsetrestore {
	my $set = shift;
	my $verbose = 1;
	if ($set =~ /^new_(6_)?CXS_/) {$verbose = 0}
	my $family = "inet";
	if ($set =~ /_6/) {$family = "inet6"}
	if ($verbose) {logfile("IPSET: loading set $set with ".scalar(@ipset)." entries")}

	my ($childin, $childout);
	my $cmdpid = open3($childin, $childout, $childout, $config{IPSET},"restore");
	print $childin "create -exist $set hash:net family $family hashsize $config{LF_IPSET_HASHSIZE} maxelem $config{LF_IPSET_MAXELEM}\n".join("\n",@ipset)."\n";
	close $childin;
	my @results = <$childout>;
	waitpid ($cmdpid, 0);
	chomp @results;
	if ($results[0] =~ /^ipset/) {
		logfile("*Error* [$set] IPSET: [$results[0]]");
	}
	undef @ipset;
	return;
}
# end ipsetrestore
###############################################################################
# start ipsetswap
sub ipsetswap {
	my $from = shift;
	my $to = shift;
	my $verbose = 1;
	if ($from =~ /^new_(6_)?CXS_/) {$verbose = 0}
	if ($verbose) {logfile("IPSET: switching set $from to $to")}

	my ($childin, $childout);
	my $cmdpid = open3($childin, $childout, $childout, $config{IPSET},"swap",$from,$to);
	close $childin;
	my @results = <$childout>;
	waitpid ($cmdpid, 0);
	chomp @results;
	if ($results[0] =~ /^ipset/) {
		logfile("*Error* IPSET: [$results[0]]");
	}

	$cmdpid = open3($childin, $childout, $childout, $config{IPSET},"flush",$from);
	close $childin;
	@results = <$childout>;
	waitpid ($cmdpid, 0);
	chomp @results;
	if ($results[0] =~ /^ipset/) {
		logfile("*Error* IPSET: [$results[0]]");
	}

	$cmdpid = open3($childin, $childout, $childout, $config{IPSET},"destroy",$from);
	close $childin;
	@results = <$childout>;
	waitpid ($cmdpid, 0);
	chomp @results;
	if ($results[0] =~ /^ipset/) {
		logfile("*Error* [$from] [$to] IPSET: [$results[0]]");
	}
	return;
}

sub ipsetadd
{
	my $set = shift;
	my $ip = shift;
	if ($set =~ /GDENY/ or $set =~ /GALLOW/) {
		if ($set =~ /^(\w+)(IN|OUT)$/) {$set = $1}
	} else {
		if ($set =~ /^chain(_6)?_NEW(\w+)$/) {$set = "chain".$1."_".$2}
		if ($set =~ /^bl(_6)?_NEW(\w+)$/) {$set = "bl".$1."_".$2}
		if ($set =~ /^(\w+)(IN|OUT)$/) {$set = $1}
	}
	if ($set eq "" or $ip eq "") {return}
	if ($faststart) {
		push @faststartipset, "add -exist $set $ip";
		return;
	}
	if ($config{DEBUG} >= 1) {logfile("debug: IPSET adding [$ip] to set [$set]")}
	my ($childin, $childout);
	my $cmdpid = open3($childin, $childout, $childout, $config{IPSET},"add","-exist",$set,$ip);
	close $childin;
	my @results = <$childout>;
	waitpid ($cmdpid, 0);
	chomp @results;
	if ($results[0] =~ /^ipset/) {
		logfile("*Error* [$set] IPSET: [$results[0]]");
	}
	return;
}

sub ipsetdel
{
	my $set = shift;
	my $ip = shift;
	if ($set =~ /^chain(_6)?_NEW(\w+)$/) {$set = "chain".$1."_".$2}
	if ($set =~ /^bl(_6)?_NEW(\w+)$/) {$set = "bl".$1."_".$2}
	if ($set =~ /^(\w+)(IN|OUT)$/) {$set = $1}
	if ($set eq "" or $ip eq "") {return}
	if ($config{DEBUG} >= 1) {logfile("debug: IPSET deleting [$ip] from set [$set]")}
	my ($childin, $childout);
	my $cmdpid = open3($childin, $childout, $childout, $config{IPSET},"del",$set,$ip);
	close $childin;
	my @results = <$childout>;
	waitpid ($cmdpid, 0);
	chomp @results;
	if ($results[0] =~ /^ipset/)
	{
		logfile("*Error* [$set] IPSET: [$results[0]]");
	}
	return;
}


sub ipsetflush
{
	my $set = shift;
	logfile("IPSET: flushing set $set");

	my ($childin, $childout);
	my $cmdpid = open3($childin, $childout, $childout, $config{IPSET},"flush",$set);
	close $childin;
	my @results = <$childout>;
	waitpid ($cmdpid, 0);
	chomp @results;
	if ($results[0] =~ /^ipset/) {
		logfile("*Error* IPSET: [$results[0]]");
	}
	return;
}
