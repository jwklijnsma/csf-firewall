# #
#   @app                ConfigServer Security & Firewall (CSF)
#                       Login Failure Daemon (LFD)
#   @website            https://configserver.dev
#   @docs               https://docs.configserver.dev
#   @download           https://download.configserver.dev
#   @repo               https://github.com/Aetherinox/csf-firewall
#   @copyright          Copyright (C) 2025-2026 Aetherinox
#                       Copyright (C) 2006-2025 Jonathan Michaelson
#                       Copyright (C) 2006-2025 Way to the Web Ltd.
#   @license            GPLv3
#   @updated            11.05.2026
#   
#   This program is free software; you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation; either version 3 of the License, or (at
#   your option) any later version.
#   
#   This program is distributed in the hope that it will be useful, but
#   WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
#   General Public License for more details.
#   
#   You should have received a copy of the GNU General Public License
#   along with this program; if not, see <https://www.gnu.org/licenses>.
#   
#   @commands       Load module directly:
#                       sudo perl -I. ConfigServer/Config.pm
#   
#                   Check module for syntax errors:
#                       sudo  perl -I. -c ConfigServer/Config.pm
#   
#                   Module docs:
#                       perldoc -T ConfigServer/Config.pm
#   
#                   Run test suite:
#                       sudo prove -I. -v tests/Config.t
# #

# #
#   Declare › Package
# #

package ConfigServer::Config;

# #
#   Declare › Use
# #

use strict;
use lib '/usr/local/csf/lib';
use version;
use Fcntl qw( :DEFAULT :flock );
use Carp;
use IPC::Open3;
use ConfigServer::Slurp qw( slurp );
use ConfigServer::JSON qw( decode_json );
use ConfigServer::Perl::URI qw( uri_escape );

# #
#	Config › Declare › Export
# #

use Exporter 	qw( import );
our @EXPORT_OK	= qw( );

# # 
#	Declare › Version
# #

our $VERSION    = 15.11;

# #
#   Declare › License
# #

use constant LICENSE_URL => 'https://license.configserver.dev/';

# #
#   Declare › IP Regex
#   
#   Original ipv6 regex was one large expression which contained 
#   almost 74 numbered capture groups.
#   
#   An audit concluded that only capture group $1 returned the 
#   complete address. The remaining capture groups had repetitive 
#   fragments depending on the format.
#
#   New regex builds expressions from named v4 and v6 parts.
#   
#   Created the sub _test_ipreg() to test ipv4 and ipv6 regex.
#   
#   @since      15.11
#   @todo       Migrate to new regex module
# #

our $ipv4octet   = qr/(?:25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9]?[0-9])/;
our $ipv4address = qr/$ipv4octet(?:\.$ipv4octet){3}/;
our $ipv4reg     = qr/(?<![A-Za-z0-9_.-])$ipv4address(?![A-Za-z0-9_.-])/;
our $ipv6group   = qr/[0-9A-Fa-f]{1,4}/;
our $ipv6ending  = qr/(?:$ipv6group:$ipv6group|$ipv4address)/;
our $ipv6address = qr/
	(?:
		(?:$ipv6group:){6}$ipv6ending
		|
		::(?:$ipv6group:){5}$ipv6ending
		|
		(?:$ipv6group)?::(?:$ipv6group:){4}$ipv6ending
		|
		(?:(?:$ipv6group:){0,1}$ipv6group)?::(?:$ipv6group:){3}$ipv6ending
		|
		(?:(?:$ipv6group:){0,2}$ipv6group)?::(?:$ipv6group:){2}$ipv6ending
		|
		(?:(?:$ipv6group:){0,3}$ipv6group)?::$ipv6group:$ipv6ending
		|
		(?:(?:$ipv6group:){0,4}$ipv6group)?::$ipv6ending
		|
		(?:(?:$ipv6group:){0,5}$ipv6group)?::$ipv6group
		|
		(?:(?:$ipv6group:){0,6}$ipv6group)?::
	)
/x;
our $ipv6reg     = qr/(?<![A-Za-z0-9_.:%-])($ipv6address)(?![A-Za-z0-9_.:%-])/;

# #
#   Declare › Vars
# #

my %config;
my %configsetting;
my $configfile  = "/etc/csf/csf.conf";
my $warning;
my $version;
my $slurpreg 	= ConfigServer::Slurp->slurpreg;
my $cleanreg 	= ConfigServer::Slurp->cleanreg;
my %defaults;
my $defaultsfile = "/usr/local/csf/lib/defaults.txt";

# #
#   Config › Trim
#	
#	Certain CSF features will append spaces or underscores_ to the end
#	of a config item.
#	
#	Remove trailing spaces and underscore_
#   
#   @test       Note:           Test a bunch of words to trim
#               Command:        sudo env DEBUG=4 perl -I. -MConfigServer::Config -e 'my $failed = 0; for my $test ([q{Plain word},q{csf},0,q{csf}],[q{Leading spaces},q{  csf},0,q{csf}],[q{Trailing spaces},q{csf  },0,q{csf}],[q{Spaces on both sides},q{  csf security  },0,q{csf security}],[q{Trailing underscore kept},q{csf_},0,q{csf_}],[q{Trailing underscore removed},q{csf_},1,q{csf}],[q{Spaces then underscore removed},q{  csf_  },1,q{csf}],[q{Multiple trailing underscores},q{csf___},1,q{csf__}],[q{Leading underscore},q{_csf},1,q{_csf}],[q{Internal underscore},q{csf_security},1,q{csf_security}],[q{Empty string},q{},0,q{}],[q{Spaces only},q{   },0,q{}],[q{Undefined input},undef,1,undef]) { my ($description,$input,$strip,$expected) = @{$test}; my $res = ConfigServer::Config::_trim($input,$strip); my $shown = defined($input) ? qq{[$input]} : q{<undef>}; my $got = defined($res) ? qq{[$res]} : q{<undef>}; my $expected_value = defined($expected) ? qq{[$expected]} : q{<undef>}; my $status = $got eq $expected_value ? q{OK} : q{FAILED}; printf "%-31s %-24s strip=%-3s => %-20s %s\n",$description,$shown,$strip,$got,$status; $failed++ if $status eq q{FAILED}; } die qq{$failed trim tests failed\n} if $failed;'
# #

sub _trim
{
	my ( $s, $strip_underscore ) = @_;
	return undef unless defined $s;

	$s =~ s/^\s+|\s+$//g;
	if ( $strip_underscore )
	{
		$s =~ s/_\z//;
	}

	return $s;
}

# #
#   Config › Load
# #

sub loadconfig
{
	my $class 	= shift;
	my $self    = {};

	bless $self, $class;

	if ( %config )
	{
		$self->{warning} = $warning;
		return $self;
	}

	undef %configsetting;
	undef %config;
	undef $warning;

	my @file = slurp( $configfile );
	foreach my $line ( @file )
	{
		$line =~ s/$cleanreg//g;
		if ( $line =~ /^(\s|\#|$)/ )
        {
            next
        }

		if ( $line !~ /=/ )
        {
            next
        }

		my ( $name,$value ) = split ( /=/, $line, 2 );
		$name =~ s/\s//g;

		if ( $value =~ /\"(.*)\"/ )
		{
			$value = $1;
		}
		else
		{
			croak "*Error* Invalid configuration line [$line] in $configfile";
		}
	
		if ( $configsetting{$name} )
		{
			croak "*Error* Setting $name is repeated in $configfile - you must remove the duplicates and then restart csf and lfd";
		}
	
		$config{$name}          = $value;
		$configsetting{$name}   = 1;
	}

	if ( $config{LF_IPSET} )
	{
		if ( !$config{LF_IPSET_HASHSIZE} )
		{
			$config{LF_IPSET_HASHSIZE} 			= "1024";
			$configsetting{LF_IPSET_HASHSIZE} 	= 1;
		}
		if ( !$config{LF_IPSET_MAXELEM} )
		{
			$config{LF_IPSET_MAXELEM} 			= "65536";
			$configsetting{LF_IPSET_MAXELEM}    = 1;
		}
	}

	if ( $config{USE_FTPHELPER} eq "1" )
	{
		$warning .= "USE_FTPHELPER should be set to your FTP server port (21), not 1. USE_FTPHELPER has been disabled\n";
		$config{USE_FTPHELPER} = 0;
	}

	if ( $config{IPTABLES} eq "" or !( -x $config{IPTABLES} ) )
	{
		croak "*Error* The path to iptables is either not set or incorrect for IPTABLES [$config{IPTABLES}] in /etc/csf/csf.conf";
	}

	if ( -e "/proc/sys/net/netfilter/nf_conntrack_helper" and !$config{USE_FTPHELPER} )
	{
		my $setting = slurp( "/proc/sys/net/netfilter/nf_conntrack_helper" );
		chomp $setting;

		if ( $setting == 0 )
		{
			open ( my $PROC, ">", "/proc/sys/net/netfilter/nf_conntrack_helper" );
			print $PROC "1\n";
			close $PROC;
		}
	}

	if ( $config{WAITLOCK} )
	{
		$config{IPTABLESWAIT} = "--wait";
	}

	my @results = &systemcmd( "$config{IPTABLES} $config{IPTABLESWAIT} --version" );
	if ( $results[0] =~ /iptables v(\d+\.\d+\.\d+)/ )
	{
		$version = $1;

		$config{IPTABLESWAIT} = "";
		if ( $config{WAITLOCK} )
		{
			my @ipdata;
			eval
			{
				local $SIG{__DIE__} 	= undef;
				local $SIG{'ALRM'}      = sub { die "alarm\n" };
	
				alarm( $config{WAITLOCK_TIMEOUT} );
	
				my ( $childin, $childout );
				my $cmdpid  = open3( $childin, $childout, $childout, "$config{IPTABLES} --wait -L OUTPUT -nv" );
				@ipdata     = <$childout>;

				waitpid     ( $cmdpid, 0 );
				chomp       @ipdata;

				if ( $ipdata[ 0 ] =~ /# Warning: iptables-legacy tables present/ )
				{
					shift @ipdata
				}
				alarm(0);
			};
	
			alarm( 0 );
			if ( $@ eq "alarm\n" )
			{
				croak "*ERROR* Timeout after $config{WAITLOCK_TIMEOUT} seconds for iptables --wait - WAITLOCK\n";
			}

			if ( $ipdata[ 0 ] =~ /^Chain OUTPUT/ )
			{
				$config{IPTABLESWAIT} = "--wait";
			}
			else
			{
				$warning            .= "*WARNING* This version of iptables does not support the --wait option - disabling WAITLOCK\n";
				$config{WAITLOCK}   = 0;
			}
		}
	}
	else
	{
		$warning .= "*WARNING* Unable to detect iptables version [$results[0]]\n";
	}

	if ( $config{CC_LOOKUPS} and $config{CC_LOOKUPS} != 4 and $config{CC_SRC} eq "1" )
	{
		if ( $config{MM_LICENSE_KEY} eq "" )
		{
			$warning .= "*ERROR*: Country Code Lookups setting MM_LICENSE_KEY must be set in /etc/csf/csf.conf to continue using the MaxMind databases\n";
		}
	}

	foreach my $cclist ( "CC_DENY","CC_ALLOW","CC_ALLOW_FILTER","CC_ALLOW_PORTS","CC_DENY_PORTS","CC_ALLOW_SMTPAUTH" )
	{
		$config{$cclist} =~ s/\s//g;
		my $newcclist;
		foreach my $cc ( split( /\,/,$config{$cclist} ) )
		{
			if ( $cc ne "" and ( ( length( $cc ) == 2 and $cc =~ /^[a-zA-Z][a-zA-Z]$/i) or ( length( $cc ) > 2 and $cc =~ /^AS\d+$/i ) ) )
			{
				$cc = lc $cc;
				if ( $newcclist eq "" )
				{
					$newcclist = "$cc"
				}
				else
				{
					$newcclist .= ",$cc"
				}
			}
			else
			{
				$warning .= "*WARNING* $cclist contains an invalid entry [$cc]\n";
			}
		}
		$config{$cclist} = $newcclist;
	}

	if ($config{CC_DENY} or $config{CC_ALLOW} or $config{CC_ALLOW_FILTER} or $config{CC_ALLOW_PORTS} or $config{CC_DENY_PORTS} or $config{CC_ALLOW_SMTPAUTH})
	{
		if ($config{MM_LICENSE_KEY} eq "" and $config{CC_SRC} eq "1")
		{
			$warning .= "*ERROR*: Country Code Filters setting MM_LICENSE_KEY must be set in /etc/csf/csf.conf to continue updating the MaxMind databases\n";
		}
	}

	if ($config{DROP_OUT} ne "DROP")
	{
		my @data = &systemcmd("$config{IPTABLES} $config{IPTABLESWAIT} -N TESTDENY");
		unless ($data[0] =~ /^iptables/)
		{
			my @ipdata = &systemcmd("$config{IPTABLES} $config{IPTABLESWAIT} -I TESTDENY -j $config{DROP_OUT}");
			if ($ipdata[0] =~ /^iptables/)
			{
				$warning .= "*WARNING* Cannot use DROP_OUT value of [$config{DROP_OUT}] on this server, set to DROP\n";
				$config{DROP_OUT} = "DROP";
			}

			&systemcmd("$config{IPTABLES} $config{IPTABLESWAIT} -F TESTDENY");
			&systemcmd("$config{IPTABLES} $config{IPTABLESWAIT} -X TESTDENY");
		}
	}

    # #
    #   iptables › Table › RAW
    #   
    #   Check whether the iptables raw table is available.
    #   Set RAW to 1 when the PREROUTING chain can be read.
    # #

	my @raw = &systemcmd( "$config{IPTABLES} $config{IPTABLESWAIT} -L PREROUTING -t raw" );
	if ( $raw[ 0 ] =~ /^Chain PREROUTING/ )
    {
        $config{RAW} = 1
    }
    else
    {
        $config{RAW} = 0 
    }

    # #
    #   iptables › Table › MANGLE
    #   
    #   Check whether the iptables mangle table is available.
    #   Set MANGLE to 1 when the PREROUTING chain can be read.
    # #

	my @mangle = &systemcmd( "$config{IPTABLES} $config{IPTABLESWAIT} -L PREROUTING -t mangle" );
	if ( $mangle[0] =~ /^Chain PREROUTING/ )
    {
        $config{MANGLE} = 1
    }
    else
    {
        $config{MANGLE} = 0 
    }

    # #
    #   iptables › Version
    #   
    #   IPv6-specific checks only if IPv6 is enabled.
    #   
    #   Configured ip6tables binary is executable, and an iptables 
    #   version was successfully detected.
    # #

	if ( $config{IPV6} and -x $config{IP6TABLES} and $version )
	{
        # #
        #   iptables › Version › < 1.3.5
        #   
        #   Disable USE_CONNTRACK if detected iptables version is 1.3.5 or
        #   older.
        #   
        #   USE_CONNTRACK       This option should be enabled unless the kernel
        #                       does not support the "conntrack" module.
        #   
        #                       To use the deprecated iptables "state" module,
        #                       change this to 0
        # #

		if ( $config{USE_CONNTRACK} and version->parse( $version ) <= version->parse( "1.3.5" ) )
        {
            $config{USE_CONNTRACK} = 0
        }

        # #
        #   iptables › Version › >= 1.4.3
        #   
        #   Enable PORTFLOOD6 if detected iptables version is 1.4.3 or
        #   newer.
        #   
        #   PORTFLOOD           limits how many new connections can be made to
        #                       specific ports within a set time period.
        #   
        #                       Enable IPv6 PORTFLOOD support when PORTFLOOD is
        #                       enabled and the required iptables version is
        #                       available.
        # #

		if ( $config{PORTFLOOD} and version->parse( $version ) >= version->parse( "1.4.3" ) )
        {
            $config{PORTFLOOD6} = 1
        }

		if ( $config{CONNLIMIT} and version->parse($version) >= version->parse("1.4.3")) {$config{CONNLIMIT6} = 1}
		if ( $config{MESSENGER} and version->parse($version) >= version->parse("1.4.17")) {$config{MESSENGER6} = 1}
		if ( $config{SMTP_REDIRECT} and version->parse($version) >= version->parse("1.4.17")) {$config{SMTP_REDIRECT6} = 1}
		my @ipdata = &systemcmd("$config{IP6TABLES} $config{IPTABLESWAIT} -t nat -L POSTROUTING -nv");

		if ($ipdata[0] =~ /^Chain POSTROUTING/)
		{
			$config{NAT6} = 1;
		}
		elsif (version->parse($version) >= version->parse("1.4.17"))
		{
			if ($config{SMTP_REDIRECT})
			{
				$warning .= "*WARNING* ip6tables nat table not present - disabling SMTP_REDIRECT for IPv6\n";
				$config{SMTP_REDIRECT6} = 0;
			}
			if ($config{MESSENGER})
			{
				$warning .= "*WARNING* ip6tables nat table not present - disabling MESSENGER Service for IPv6\n";
				$config{MESSENGER6} = 0;
			}
			if ($config{DOCKER} and $config{DOCKER_NETWORK6} ne "")
			{
				$warning .= "*WARNING* ip6tables nat table not present - disabling DOCKER for IPv6\n";
			}
		}

		my @raw = &systemcmd("$config{IP6TABLES} $config{IPTABLESWAIT} -L PREROUTING -t raw");
		if ($raw[0] =~ /^Chain PREROUTING/) {$config{RAW6} = 1} else {$config{RAW6} = 0}
		my @mangle = &systemcmd("$config{IP6TABLES} $config{IPTABLESWAIT} -L PREROUTING -t mangle");
		if ($mangle[0] =~ /^Chain PREROUTING/) {$config{MANGLE6} = 1} else {$config{MANGLE6} = 0}
	}
	elsif ($config{IPV6})
	{
		$warning .= "*WARNING* incorrect ip6tables binary location [$config{IP6TABLES}] - IPV6 disabled\n";
		$config{IPV6} = 0;
	}
	
	if (!$config{GENERIC} and -e "/var/cpanel/dnsonly")
	{
		$config{DNSONLY} = 1
	}

	if (-e "/var/cpanel/smtpgidonlytweak" and !$config{GENERIC}) {
		if ($config{DNSONLY})
		{
			$warning .= "*WARNING* The cPanel option to 'Restrict outgoing SMTP to root, exim, and mailman' is incompatible with this firewall. The option must be disabled using \"/usr/local/cpanel/scripts/smtpmailgidonly off\" and the SMTP_BLOCK alternative in csf used instead\n";
		}
		else
		{
			$warning .= "*WARNING* The option \"WHM > Tweak Settings > Restrict outgoing SMTP to root, exim, and mailman (FKA SMTP Tweak)\" is incompatible with this firewall. The option must be disabled in WHM and the SMTP_BLOCK alternative in csf used instead\n";
		}
	}

	if (-e "/proc/vz/veinfo")
	{
		$config{VPS} = 1
	}
	else
	{
		foreach my $line (slurp("/proc/self/status"))
		{
			$line =~ s/$cleanreg//g;
			if ($line =~ /^envID:\s*(\d+)\s*$/)
			{
				if ($1 > 0)
				{
					$config{VPS} = 1;
					last;
				}
			}
		}
	}

	if ($config{DROP_IP_LOGGING} and $config{PS_INTERVAL})
	{
		$warning .= "*WARNING* Cannot use PS_INTERVAL with DROP_IP_LOGGING enabled. DROP_IP_LOGGING disabled\n";
		$config{DROP_IP_LOGGING} = 0;
	}

	if ( $config{FASTSTART} )
	{
		unless ( -x $config{IPTABLES_RESTORE} )
		{
			$warning .= "*WARNING* Unable to use FASTSTART as [$config{IPTABLES_RESTORE}] is not executable or does not exist\n";
			$config{FASTSTART} = 0;
		}

		if ($config{IPV6})
		{
			unless (-x $config{IP6TABLES_RESTORE})
			{
				$warning .= "*WARNING* Unable to use FASTSTART as (IPv6) [$config{IP6TABLES_RESTORE}] is not executable or does not exist\n";
				$config{FASTSTART} = 0;
			}
		}
	}

	if ( $config{MESSENGER} )
	{
		if ( $config{MESSENGERV2} )
		{
			if ( !-e "/etc/cpanel/ea4/is_ea4" )
			{
				$warning .= "*WARNING* EA4 is not in use - disabling MESSENGERV2 and MESSENGER HTTPS Service\n";
				$config{MESSENGERV2} = "0";
				$config{MESSENGER_HTTPS_IN} = "";
				$config{MESSENGER_HTTPS_DISABLED} = "*WARNING* EA4 is not in use - disabling MESSENGERV2 and MESSENGER HTTPS Service";
			}
		}

		if ($config{MESSENGER_HTTPS_IN} and (!$config{MESSENGERV2} or $config{MESSENGER_HTTPS_DISABLED}))
		{
			eval
			{
				local $SIG{__DIE__} = undef;
				require IO::Socket::SSL;
			};
	
			if ( $@ )
			{
				$warning .= "*WARNING* Perl module IO::Socket::SSL missing - disabling MESSENGER HTTPS Service\n";
				$config{MESSENGER_HTTPS_IN} = "";
				$config{MESSENGER_HTTPS_DISABLED} = "*WARNING* Perl module IO::Socket::SSL missing - disabling MESSENGER HTTPS Service";
			}
			elsif (version->parse($IO::Socket::SSL::VERSION) < version->parse("1.83")) {
				$warning .= "*WARNING* Perl module IO::Socket::SSL v$IO::Socket::SSL::VERSION does not support SNI - disabling MESSENGER HTTPS Service\n";
				$config{MESSENGER_HTTPS_IN} = "";
				$config{MESSENGER_HTTPS_DISABLED} = "*WARNING* Perl module IO::Socket::SSL v$IO::Socket::SSL::VERSION does not support SNI - disabling MESSENGER HTTPS Service";
			}
		}

		my $pcnt = 0;
		foreach my $port ( split(/\,/,$config{MESSENGER_HTML_IN} ) )
		{
			$pcnt++;
		}

		if ( $pcnt > 15 )
		{
			$warning .= "*WARNING* MESSENGER_HTML_IN contains more than 15 ports - disabling MESSENGER Service\n";
			$config{MESSENGER} = 0;
		}
		else
		{
			$pcnt = 0;
			foreach my $port ( split(/\,/,$config{MESSENGER_TEXT_IN} ) )
			{
				$pcnt++;
			}

			if ( $pcnt > 15 )
			{
				$warning .= "*WARNING* MESSENGER_TEXT_IN contains more than 15 ports - disabling MESSENGER Service\n";
				$config{MESSENGER} = 0;
			}
			else
			{
				$pcnt = 0;
				foreach my $port ( split( /\,/,$config{MESSENGER_HTTPS_IN} ) )
				{
					$pcnt++;
				}

				if ($pcnt > 15)
				{
					$warning .= "*WARNING* MESSENGER_HTTPS_IN contains more than 15 ports - disabling MESSENGER Service\n";
					$config{MESSENGER} = 0;
				}
			}
		}
	}

	if ( $config{IPV6} and $config{IPV6_SPI} )
	{
		open (my $FH, "<", "/proc/sys/kernel/osrelease");
		flock ($FH, LOCK_SH);
		my @data = <$FH>;
		close ($FH);
		chomp @data;

		if ( $data[0] =~ /^(\d+)\.(\d+)\.(\d+)/ )
		{
			my $maj = $1;
			my $mid = $2;
			my $min = $3;
			if ( ( $maj > 2 ) or ( ( $maj > 1 ) and ( $mid > 6 ) ) or ( ( $maj > 1 ) and ( $mid > 5 ) and ( $min > 19 ) ) )
			{
			}
			else
			{
				$warning .=  "*WARNING* Kernel $data[0] may not support an ip6tables SPI firewall. You should set IPV6_SPI to \"0\" in /etc/csf/csf.conf\n\n";
			}
		}
	}

	if ( ( $config{CLUSTER_SENDTO} or $config{CLUSTER_RECVFROM} ) )
	{
		if ( -f $config{CLUSTER_SENDTO} )
		{
			if ( $config{DEBUG} >= 1 ) 		{ $warning .= "*DEBUG* CLUSTER_SENDTO retrieved from $config{CLUSTER_SENDTO} and set to: " }
			$config{CLUSTER_SENDTO} 		= join(",", slurp($config{CLUSTER_SENDTO}));
			if ( $config{DEBUG} >= 1 )		{ $warning .= "[$config{CLUSTER_SENDTO}]\n" }
			}

		if ( -f $config{CLUSTER_RECVFROM} )
		{
			if ( $config{DEBUG} >= 1 ) 		{ $warning .= "*DEBUG* CLUSTER_RECVFROM retrieved from $config{CLUSTER_RECVFROM} and set to: " }
			$config{CLUSTER_RECVFROM} 		= join(",", slurp($config{CLUSTER_RECVFROM}));
			if ( $config{DEBUG} >= 1 ) 		{ $warning .= "[$config{CLUSTER_RECVFROM}]\n" }
		}
	}

	my @ipdata = &systemcmd( "$config{IPTABLES} $config{IPTABLESWAIT} -t nat -L POSTROUTING -nv" );
	if ( $ipdata[0] =~ /^Chain POSTROUTING/ )
	{
		$config{NAT} = 1;
	}
	else
	{
		if ( $config{MESSENGER} )
		{
			$warning .= "*WARNING* iptables nat table not present - disabling MESSENGER Service\n";
			$config{MESSENGER} = 0;
		}
	}

	if ( $config{PT_USERKILL} )
	{
		$warning .= "*WARNING* PT_USERKILL should not normally be enabled as it can easily lead to legitimate processes being terminated, use csf.pignore instead\n";
	}

	$config{cc_src} 			= "MaxMind";
	$config{asn_src} 			= "MaxMind";
	$config{cc_country} 		= "https://download.maxmind.com/app/geoip_download?edition_id=GeoLite2-Country-CSV&suffix=zip&license_key=$config{MM_LICENSE_KEY}";
	$config{cc_city} 			= "https://download.maxmind.com/app/geoip_download?edition_id=GeoLite2-City-CSV&suffix=zip&license_key=$config{MM_LICENSE_KEY}";
	$config{cc_asn} 			= "https://download.maxmind.com/app/geoip_download?edition_id=GeoLite2-ASN-CSV&suffix=zip&license_key=$config{MM_LICENSE_KEY}";

	if ( $config{CC_SRC} eq "2" )
	{
		$config{cc_src} 		= "DB-IP";
		$config{asn_src} 		= "iptoasn.com";
		$config{ccl_src} 		= "ipdeny.com";
		my ($month,$year) 		= sub{ 1+shift, 1900+shift }->((localtime time)[4,5]);
		$month 					= sprintf("%02d", $month);
		$config{cc_country} 	= "http://download.db-ip.com/free/dbip-country-lite-$year-$month.csv.gz";
		$config{cc_city} 		= "http://download.db-ip.com/free/dbip-city-lite-$year-$month.csv.gz";
		$config{cc_asn} 		= "http://iptoasn.com/data/ip2asn-combined.tsv.gz";
		$config{cc_cc} 			= "http://download.geonames.org/export/dump/countryInfo.txt";
	}

	$config{DOWNLOADSERVER} 	= &getdownloadserver;
	$self->{warning} 			= $warning;

	return $self;
}

# #
#   Config › Get Loaded Config
#   
#   Return all currently loaded CSF config settings.
# #

sub config
{
    return %config;
}

# #
#   Config › Reset Loaded Config
#   
#   Clear cached config, setting map, and warnings.
# #

sub resetconfig
{
	undef %config;
	undef %configsetting;
	undef $warning;

	return;
}

# #
#   Config › Get Config Settings
#   
#   Return map of config settings that are loaded.
# #

sub configsetting
{
	return %configsetting;
}

# #
#	Config › Get › Single Value
#	
#	Read a single setting in csf.conf without needing to load the
#	entire CSF configuration.
#	
#	This does not call loadconfig() or perform any of its config
#	validation or system checks.
#	
#	@usage			ConfigServer::Config->getsingle( "DEBUG" );
#	
#	@param			item			str			setting to get
#	@return							str			setting value
# #

sub getsingle
{
	my ( $class, $item ) = @_;

	$item = _trim( $item, 1 );
	return undef if !defined $item || $item eq "";

	open    ( my $IN, "<", $configfile ) or return undef;
	flock   ( $IN, LOCK_SH );

	my $value;
	my $found = 0;

	while ( my $line = <$IN> )
	{
		$line =~ s/$cleanreg//g;

        # #
        #   /^(\s|\#|$)/        Skip lines starting with whitespace, # chars,
        #                       or empty.
        #   
        #   /=/                 Skip lines without equal = sign.
        #   
        #   s/\s//g             Remove all whitespace from setting name.
        # #

		next if $line =~ /^(\s|\#|$)/;
		next if $line !~ /=/;

		my ( $name, $setting ) = split( /=/, $line, 2 );
		$name =~ s/\s//g;

		next if $name ne $item;

        # #
        #   Checks if $setting contains a value inside double quotes.
        #   If so, capture setting between the quotes.
        # #

		if ( $setting =~ /\"(.*)\"/ )
		{
			$setting = $1;
		}
		else
		{
			close( $IN );
			croak "*Error* Invalid configuration line [$line] in $configfile";
		}

		if ( $found )
		{
			close( $IN );
			croak "*Error* Setting $item is repeated in $configfile - you must remove the duplicates and then restart csf and lfd";
		}

		$value  = $setting;
		$found  = 1;
	}

	close( $IN );

	return $value if $found;
	return undef;
}

# #
#	Config › Get › Default
# #

sub getdefault
{
	my $item = _trim( shift, 1 );

	if ( -e $defaultsfile )
	{
		open        ( my $IN, "<", $defaultsfile ) or die "Cannot open $defaultsfile: $!";
		flock       ( $IN, LOCK_SH );
		my @data    = <$IN>;
		close       ( $IN );
		chomp       @data;

		foreach my $line ( @data )
		{
			next if $line =~ /^(\s|\#|$)/;
			my ( $name, $value ) = split( /\=/, $line, 2 );

			$name   = _trim( $name, 1 );
			$value 	= _trim( $value );
			$value 	= undef if !defined $value || $value eq '';

			$defaults{$name} = $value;
		}
	}

	return $defaults{$item} if defined $defaults{$item};
	return undef;
}

# #
#   Config › IPv4 Address
#   
#   Return base IPv4 address regex.
#   Use with \A and \z to validate a var with only an IPv4 addr.
#   
#   @usage      my $ipv4regex   = ConfigServer::Config->ipv4address;
#               my $ipv4test    = "192.0.2.10" =~ /\A(?:$ipv4regex)\z/ ? 1 : 0;
#               print "IPv4: $ipv4test\n";  # Returns "IPv4: 1"
#   
#   @test       Note:           Return regex string
#               Command:        sudo env DEBUG=4 perl -I. -MConfigServer::Config -e 'my $regex = ConfigServer::Config->ipv4address; print qq{Type: },ref($regex),qq{\nRegex: $regex\n};'
#   
#               Note:           Test all 4 subs
#                               ipv4address, ipv6address, ipv4reg, ipv6reg
#               Command:        sudo env DEBUG=4 perl -I. -MConfigServer::Config -e 'my $failed = 0; for my $test ([q{IPv4 complete value},q{ipv4address},q{validate},q{192.0.2.10},q{192.0.2.10}],[q{IPv6 complete value},q{ipv6address},q{validate},q{2001:db8::10},q{2001:db8::10}],[q{IPv4 command output},q{ipv4reg},q{extract},q{2: eth0    inet 192.0.2.10/24 brd 192.0.2.255 scope global eth0},q{192.0.2.10}],[q{IPv6 command output},q{ipv6reg},q{extract},q{2: eth0    inet6 2001:db8::10/64 scope global},q{2001:db8::10}]) { my ($description,$method,$operation,$input,$expected) = @{$test}; my $regex = ConfigServer::Config->$method(); my $res; if ($operation eq q{validate}) { ($res) = $input =~ /\A($regex)\z/; } else { ($res) = $input =~ /($regex)/; } my $got = defined($res) ? $res : q{undef}; my $status = $got eq $expected ? q{OK} : q{FAILED}; printf "%-22s %-13s %-76s => %-39s type=%-7s %s\n",$description,$method,$input,$got,ref($regex),$status; $failed++ if $status eq q{FAILED}; } die qq{$failed regex tests failed\n} if $failed;'
#   
#   @params     void
#   @return     ipv4address     Regexp      IPv4 addr regex
# #

sub ipv4address
{
	return $ipv4address;
}

# #
#   Config › IPv6 Address
#   
#   Return base IPv6 address regex.
#   Use with \A and \z to validate a var with only an IPv6 addr.
#   
#   @usage      my $ipv6regex   = ConfigServer::Config->ipv6address;
#               my $ipv6test    = "2001:db8::10" =~ /\A(?:$ipv6regex)\z/ ? 1 : 0;
#               print "IPv6: $ipv6test\n";  # Returns "IPv6: 1"
#   
#   @test       Note:           Return regex string
#               Command:        sudo env DEBUG=4 perl -I. -MConfigServer::Config -e 'my $regex = ConfigServer::Config->ipv6address; print qq{Type: },ref($regex),qq{\nRegex: $regex\n};'
#   
#   @params     void
#   @return     ipv6address     Regexp      IPv6 addr regex
# #

sub ipv6address
{
	return $ipv6address;
}

# #
#   Config › IPv4 Regex
#   
#   Returns IPv4 extraction regex.
#   Extract IPv4 addr from longer lines (config or log).
#   
#   @usage      my $ipv4regex       = ConfigServer::Config->ipv4reg;
#               my $ipv4line        = "2: eth0 inet 192.0.2.10/24 brd 192.0.2.255";
#               my ( $ipv4test )    = $ipv4line =~ /($ipv4regex)/;
#               print "$ipv4test\n";  # Returns "192.0.2.10"
#   
#   @test       Note:           Return regex string
#               Command:        sudo env DEBUG=4 perl -I. -MConfigServer::Config -e 'my $regex = ConfigServer::Config->ipv4reg; print qq{Type: },ref($regex),qq{\nRegex: $regex\n};'
#   
#   @params     void
#   @return     ipv4reg         Regexp      IPv4 addr extraction regex
# #

sub ipv4reg
{
	return $ipv4reg;
}

# #
#   Config › IPv6 Regex
#   
#   Returns IPv6 extraction regex.
#   Extract IPv6 addr from longer lines (config or log).
#   
#   @usage      my $ipv6regex       = ConfigServer::Config->ipv6reg;
#               my $ipv6line        = "2: eth0 inet6 2001:db8::10/64 scope global";
#               my ( $ipv6test )    = $ipv6line =~ /($ipv6regex)/;
#               print "$ipv6test\n";  # Returns "2001:db8::10"
#   
#   @test       Note:           Return regex string
#               Command:        sudo env DEBUG=4 perl -I. -MConfigServer::Config -e 'my $regex = ConfigServer::Config->ipv6reg; print qq{Type: },ref($regex),qq{\nRegex: $regex\n};'
#   
#   @params     void
#   @return     ipv6reg         Regexp      IPv6 addr extraction regex
# #

sub ipv6reg
{
	return $ipv6reg;
}

# #
#   Config › System Command
#   
#   Run system command, get output, wait for command to finish.
#   Remove the iptables legacy warning from the returned output when present.
# #

sub systemcmd
{
	my @command = @_;
	my @result;

	eval
	{
		my ( $childin, $childout );
		my $pid     = open3( $childin, $childout, $childout, @command );
		@result     = <$childout>;
		waitpid     ( $pid, 0 );
		chomp       @result;

		if ( $result[0] =~ /# Warning: iptables-legacy tables present/ )
		{
			shift @result
		}
	};

	return @result;
}

# #
#	Config › Get › License Key
#	
#	Returns the sponsor license key from config.
#	Uses internal %config hash; call after loadconfig().
#	
#	@return			str
# #

sub getLicense
{
	return $config{SPONSOR_LICENSE};
}

# #
#	Config › Get › License Status
#	
#	Returns both the license status of a user, as well as any errors that
#	may return from the validation process.
#	
#	License fetching utilizes URLGET, which can be changed in csf.conf.
#	Three options available:
#   	1.  Perl module HTTP::Tiny
#   	2.  Perl module LWP::UserAgent
#   	3.  CURL/WGET (set location at the bottom of csf.conf if installed)
#	
#	If URLGET = "2"; requires LWP
#		yum install perl-libwww-perl.noarch perl-LWP-Protocol-https.noarch
#		apt-get install libwww-perl liblwp-protocol-https-perl
#	
#	Without these packages, license response only understands 200 and non-200 codes.
#	Will not return message.response from json.
#	
#	@return			int			isValid		0,1
#					str			errorMsg
# #

sub getLicenseStatus
{
	my $timeout 	= 3;
	my $license 	= getLicense();	
	if ( !$license )
	{
		return ( 0, 'No license configured' );
	}

    # #
    #   avoid circular dependency
    # #

	require ConfigServer::URLGet;

	my $urlget = ConfigServer::URLGet->new( $config{URLGET}, "csf/$VERSION", $config{URLPROXY} );
	if ( !defined $urlget )
	{
		$urlget = ConfigServer::URLGet->new( 1, "csf/$VERSION", $config{URLPROXY} );
	}

	if ( !$urlget )
	{
		return ( 0, 'Unable to initialize URL fetcher' );
	}

	my $licenseEnc = uri_escape( $license );
	my ( $statusCode, $resp );

	eval
	{
		local $SIG{__DIE__} 	= undef;
		local $SIG{'ALRM'} 		= sub { die "timeout\n" };
		alarm( $timeout );
	
		( $statusCode, $resp )  = $urlget->urlget( LICENSE_URL . "?license=$licenseEnc" );
		alarm( 0 );
	};
	alarm( 0 );

	# #
	#	Add timeout in case something goes wrong, 
	#	the user should not be stuck waiting.
	# #

	if ( $@ )
	{
		if ( $@ eq "timeout\n" )
		{
			return ( 0, 'License server timeout' );
		}
		return ( 0, 'License check failed' );
	}

	return ( 0, 'Invalid license key' ) if $statusCode;

	my $data = decode_json( $resp );
	if ( !defined $data )
	{
		return ( 0, 'Invalid response from license server' );
	}

	my $valid 	= $data->{message}{valid} ? 1 : 0;
	my $msg 	= $data->{message}{response} // 'Unknown error';
	$msg        = "$msg";
	$msg        =~ s/[\x00-\x1F\x7F]//g;
	$msg        =~ s/\s+/ /g;
	$msg        = substr( $msg, 0, 200 );

	return ( $valid, $msg );
}

# #
#	Config › Get › Codename
#	
#	Returns the codename based on which control panel a user is running.
#	Uses internal %config hash; call after loadconfig().
#	
#	@return			str
# #

sub getCodename
{
	my $cname = "cpanel";
	if ( $config{GENERIC} )         { $cname = "generic"        }
	if ( $config{DIRECTADMIN} )     { $cname = "directadmin"    }
	if ( $config{INTERWORX} )       { $cname = "interworx"      }
	if ( $config{CYBERPANEL} )      { $cname = "cyberpanel"     }
	if ( $config{CWP} )             { $cname = "cwp"            }
	if ( $config{VESTA} )           { $cname = "vestacp"        }

    # #
    #   Check for Webmin binaries
    # #

	if ( -e "/usr/share/webmin/miniserv.pl" || -e "/usr/libexec/webmin/bin/webmin" || -e "/usr/bin/webmin" )
	{
		$cname = "webmin";
	}

	return $cname;
}

# #
#	Config › Get › Download Server
#   
#	fetches a list of csf download server endpoints
# #

sub getdownloadserver
{
	my @servers;
	my $downloadservers = "/etc/csf/downloadservers";
	my $chosen;

    # #
    #   /etc/csf/downloadservers exists; run the code inside the block.
    # #

	if ( -e $downloadservers )
	{
		open        ( my $DOWNLOAD, "<", $downloadservers );
		flock       ( $DOWNLOAD, LOCK_SH );
		my @data    = <$DOWNLOAD>;
		close       ( $DOWNLOAD );
		chomp       @data;
	
		foreach my $line ( @data ) 
		{
			# #
			#	whitelist of acceptable subdomains
			#		raw.github.com
			#		download.configserver.dev
			#		cdn.configserver.dev
			# #

			if ( $line =~ /^(?:raw|download|cdn)\./ ) 
			{
				push @servers, $line;
			}
		}

		foreach my $line ( slurp( $downloadservers ) ) 
		{
			$line =~ s/$cleanreg//g;
			if ( $line =~ /^(?:raw|download|cdn)\./ ) 
			{
				push @servers, $line;
			}
		}
	
		$chosen = $servers[ rand @servers ];
	}

	# #
	#	fallback
	# #

	if ($chosen eq "")
	{
		# Fork: fall back to this fork's releases so updates never replace it with upstream
		$chosen = "raw.githubusercontent.com/jwklijnsma/csf-firewall/dist"
	}

	return $chosen;
}

# #
#	Config › Test › Regex IPs
#   
#   Test sub used to extract ipv4 / ipv6 from longer strings.
#
#   @test       Note:           Test IP regex boundaries and addr validation
#               Command:        sudo env DEBUG=4 perl -I. -MConfigServer::Config -MConfigServer::CheckIP -e 'my $failed = 0; for my $test ([q{IPv4 valid},q{192.0.2.10},q{192.0.2.10},q{4}],[q{IPv4 maximum},q{255.255.255.255},q{255.255.255.255},q{4}],[q{IPv4 leading zero},q{192.168.001.1},q{undef},q{DENIED}],[q{IPv4 octet too large},q{256.0.0.1},q{undef},q{DENIED}],[q{IPv4 zero CIDR},q{192.0.2.10/0},q{192.0.2.10/0},q{DENIED}],[q{IPv4 maximum CIDR},q{192.0.2.10/32},q{192.0.2.10/32},q{4}],[q{IPv4 CIDR too large},q{192.0.2.10/33},q{192.0.2.10/33},q{DENIED}],[q{IPv4 CIDR text},q{192.0.2.10/abc},q{192.0.2.10},q{DENIED}],[q{IPv6 valid},q{2001:db8::1},q{2001:db8::1},q{6}],[q{IPv6 full},q{2001:0db8:0000:0000:0000:ff00:0042:8329},q{2001:0db8:0000:0000:0000:ff00:0042:8329},q{6}],[q{IPv6 zero CIDR},q{2001:db8::1/0},q{2001:db8::1/0},q{DENIED}],[q{IPv6 maximum CIDR},q{2001:db8::1/128},q{2001:db8::1/128},q{6}],[q{IPv6 CIDR too large},q{2001:db8::1/129},q{2001:db8::1/129},q{DENIED}],[q{IPv6 CIDR text},q{2001:db8::1/abc},q{2001:db8::1},q{DENIED}],[q{IPv6 scope ID},q{fe80::1%eth0},q{undef},q{DENIED}],[q{IPv6 leading text},q{x2001:db8::1},q{undef},q{DENIED}],[q{IPv6 too few groups},q{1:2:3:4:5:6:7},q{undef},q{DENIED}]) { my ($description,$input,$regex_expected,$parse_expected) = @{$test}; my $res = ConfigServer::Config::_test_ipreg($input); my $regex_got = defined($res) ? $res : q{undef}; my $parsed = ConfigServer::CheckIP::addr_parse($input); my $parse_got = defined($parsed) ? $parsed->{family} : q{DENIED}; my $status = $regex_got eq $regex_expected && $parse_got eq $parse_expected ? q{OK} : q{FAILED}; printf "%-27s %-47s => regex=%-42s parse=%-6s %s\n",$description,$input,$regex_got,$parse_got,$status; $failed++ if $status eq q{FAILED}; } die qq{$failed IP tests failed\n} if $failed;'
#
#               Note:           Test IP regex, sim real config entries mixed with ips
#               Command:        sudo env DEBUG=4 perl -I. -MConfigServer::Config -MConfigServer::CheckIP -e 'my $failed = 0; for my $test ([q{ip inet},q{2: eth0    inet 192.0.2.10/24 brd 192.0.2.255 scope global eth0},q{192.0.2.10},q{4}],[q{ip brd segment},q{brd 192.0.2.255 scope global eth0},q{192.0.2.255},q{4}],[q{ip inet6},q{2: eth0    inet6 2001:db8::10/64 scope global},q{2001:db8::10},q{6}],[q{ifconfig inet},q{inet addr:192.0.2.10  Bcast:192.0.2.255  Mask:255.255.255.0},q{192.0.2.10},q{4}],[q{ifconfig Bcast segment},q{Bcast:192.0.2.255  Mask:255.255.255.0},q{192.0.2.255},q{4}],[q{ifconfig inet6},q{inet6 addr: 2001:db8::10/64 Scope:Global},q{2001:db8::10},q{6}],[q{resolv IPv4},q{nameserver 1.1.1.1},q{1.1.1.1},q{4}],[q{resolv IPv6},q{nameserver 2606:4700:4700::1111},q{2606:4700:4700::1111},q{6}],[q{csf.deny IPv4},q{192.0.2.10 # temporary deny},q{192.0.2.10},q{4}],[q{csf.allow IPv6},q{2001:db8::1/128 # temporary allow},q{2001:db8::1},q{6}],[q{host IPv4},q{example.com has address 192.0.2.10},q{192.0.2.10},q{4}],[q{host IPv6},q{example.com has IPv6 address 2001:db8::10},q{2001:db8::10},q{6}]) { my ($description,$input,$expected,$family_expected) = @{$test}; my $res = ConfigServer::Config::_test_ipreg($input); my $got = defined($res) ? $res : q{undef}; my $parsed = defined($res) ? ConfigServer::CheckIP::addr_parse($res) : undef; my $family_got = defined($parsed) ? $parsed->{family} : q{DENIED}; my $status = $got eq $expected && $family_got eq $family_expected ? q{OK} : q{FAILED}; printf "%-24s %-92s => %-39s parse=%-6s %s\n",$description,$input,$got,$family_got,$status; $failed++ if $status eq q{FAILED}; } die qq{$failed caller-format tests failed\n} if $failed;'
#   
#   @usage      my $res = ConfigServer::Config::_test_ipreg( "csf.dev has address 192.0.2.10" );
#               print defined( $res ) ? "$res\n" : "undef\n";   # Return 192.0.2.10
#   
#   @todo       Migrate to new Regex module
#   
#   @params     input           str         Str to search
#   @return     res             str|undef   Matched IP value or no match
# #

sub _test_ipreg
{
	my ( $input ) = @_;

	return
		if !defined( $input ) or ref( $input );

	my ( $res ) = $input =~ /($ipv4reg|$ipv6reg)/;
	return
		if !defined( $res );

	if ( $input =~ /(\/\d+)$/ )
	{
		$res .= $1
	}

	return $res;
}

1;
